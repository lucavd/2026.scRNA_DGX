import re, json, sys, importlib.util
K = "/root/.claude/skills/synced/8ef7b99f-0db6-4f39-9db4-aa2bf2f215a5_4247652b-7a1c-4f7e-b618-83c36434b2dd/revisione-e-piano-implementazione/kernel.py"
spec = importlib.util.spec_from_file_location("rk", K); rk = importlib.util.module_from_spec(spec); spec.loader.exec_module(rk)
lines = open("full_paper_LNBI.md", encoding="utf-8").read().split("\n")
# section tracking
sec = []; cur = {1: "", 2: "", 3: ""}
for i, ln in enumerate(lines):
    m = re.match(r"^(#{1,3}) (.*)", ln)
    if m:
        lvl = len(m.group(1)); cur[lvl] = m.group(2).strip()
        for l in range(lvl + 1, 4): cur[l] = ""
    sec.append(" > ".join(x for x in (cur[1], cur[2], cur[3]) if x))
inv = []; nid = 0
def add(kind, i, **kw):
    global nid; nid += 1
    inv.append(dict(id=f"A{nid:04d}", kind=kind, line=i + 1, section=sec[i], **kw))
in_table = None
for i, ln in enumerate(lines):
    s = ln.strip()
    if s.startswith(": **Table"):
        in_table = re.search(r"Table (\d+)", s).group(1); add("table_caption", i, table=in_table, text=s); continue
    if s.startswith("|"):
        cells = [c.strip() for c in s.strip("|").split("|")]
        if all(re.fullmatch(r":?-+:?", c) for c in cells if c): continue
        add("table_row", i, table=in_table, cells=cells); continue
    if s.startswith("!["):
        cap = re.match(r"!\[(.*)\]\((.*?)\)", s); add("figure", i, file=cap.group(2) if cap else "", caption=cap.group(1) if cap else s); continue
    if not s or s.startswith("#") or s.startswith("---") or s.startswith(":"):
        continue
    # prose: split sentences
    for sent in re.split(r"(?<=[.!?])\s+(?=[A-Z(\[])", s):
        nums = [n["token"] if isinstance(n, dict) and "token" in n else n for n in rk.find_numbers(sent)] if hasattr(rk, "find_numbers") else []
        cites = re.findall(r"@([A-Za-z0-9_]+)", sent)
        disc = sec[i].startswith(("Discussion", "Conclusions"))
        if nums or cites or disc:
            add("sentence", i, text=sent, numbers=[n["value_raw"] for n in rk.find_numbers(sent)], citations=cites, discussion_claim=disc)
json.dump(inv, open("inventario.json", "w"), indent=1, ensure_ascii=False)
from collections import Counter
print(Counter(x["kind"] for x in inv))
print("sentences with numbers:", sum(1 for x in inv if x["kind"]=="sentence" and x["numbers"]))
print("sentences with citations:", sum(1 for x in inv if x["kind"]=="sentence" and x["citations"]))
print("discussion/conclusion sentences:", sum(1 for x in inv if x["kind"]=="sentence" and x["discussion_claim"]))
print("total numeric tokens in prose:", sum(len(x.get("numbers",[])) for x in inv))
print("distinct cite keys:", len({c for x in inv for c in x.get("citations",[])}))
