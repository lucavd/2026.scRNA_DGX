"""Track A: speedup per step (Fig. 1 / testo righe 217, 223, 416) e speedup end-to-end (righe 183-185).
Convenzione del repo (generate_figures.py fig_speedup_heatmap): rapporto delle medie su r1..r5,
CPU_mean / GPU_mean. Testo anche: media dei rapporti e rapporti su r2..r5 come sensibilita'."""
import json, glob, statistics as st
R = "/tmp/repo/results"
STEPS = ["data_loading","qc_filtering","normalization","hvg_selection","pca","neighbors",
         "leiden_0.5","leiden_1.0","leiden_1.5","umap","de_testing","total"]
def load(p, n):
    return [json.load(open(f)) for f in sorted(glob.glob(f"{R}/{p}_{n}_r*_results.json"))]
res = {}
for n in (10000, 50000, 100000):
    c, g = load("cpu", n), load("gpu", n)
    print(f"== {n}")
    for s in STEPS:
        cm = st.mean(d["timings"][s] for d in c); gm = st.mean(d["timings"][s] for d in g)
        cm25 = st.mean(d["timings"][s] for d in c[1:]); gm25 = st.mean(d["timings"][s] for d in g[1:])
        mr = st.mean(a["timings"][s]/b["timings"][s] for a, b in zip(c, g))
        res[f"{s}@{n}"] = dict(cpu_mean=cm, gpu_mean=gm, ratio=cm/gm, ratio_r2_5=cm25/gm25, mean_of_ratios=mr)
        print(f"  {s:14s} cpu={cm:10.4f} gpu={gm:9.4f} ratio={cm/gm:8.2f}  r2-5={cm25/gm25:8.2f}  mean-of-ratios={mr:8.2f}")
    # leiden aggregated
    cl = st.mean(sum(d["timings"][k] for k in ("leiden_0.5","leiden_1.0","leiden_1.5")) for d in c)
    gl = st.mean(sum(d["timings"][k] for k in ("leiden_0.5","leiden_1.0","leiden_1.5")) for d in g)
    print(f"  leiden(sum3)   cpu={cl:10.4f} gpu={gl:9.4f} ratio={cl/gl:8.2f}")
    # data loading diff
    dl = st.mean(d["timings"]["data_loading"] for d in g) - st.mean(d["timings"]["data_loading"] for d in c)
    print(f"  data_loading GPU-CPU diff = {dl:.4f} s")
print()
print("ranges over 10k/50k/100k (ratio of means):")
for s in STEPS:
    v = [res[f"{s}@{n}"]["ratio"] for n in (10000,50000,100000)]
    print(f"  {s:14s} min={min(v):7.2f} max={max(v):7.2f}  values={[round(x,2) for x in v]}")
json.dump(res, open("perstep_recomputed.json","w"), indent=1)

# end-to-end speedups
def mean_total(p, n): return st.mean(d["timings"]["total"] for d in load(p, n))
print("\nend-to-end:")
for p, n in [("gpu",10000),("gpu",50000),("gpu",100000),("gpu2",500000),("gpu4",500000),("gpu8",500000),
             ("gpu2",1300000),("gpu4",1300000),("gpu8",1300000),("gpu2",10000),("gpu8",10000)]:
    c = mean_total("cpu", n); g = mean_total(p, n)
    print(f"  {p:5s} {n:>8d} cpu={c:10.3f} gpu={g:8.3f} speedup={c/g:8.3f}  from rounded: {round(c,1)/round(g,1):8.3f}")
c = mean_total("cpu",1300000); g = mean_total("gpu8",1300000)
print(f"  hours CPU 1.3M = {c/3600:.3f} h, minutes GPU8 = {g/60:.3f} min")
