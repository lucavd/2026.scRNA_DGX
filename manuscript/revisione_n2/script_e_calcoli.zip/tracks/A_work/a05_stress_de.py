"""Track A: stress test (Tabella 5, testo righe 260-267, Tabella 6) e DE a 3.4M (Tabella 7).
Valori in GiB come registrati (psutil RSS / 1024**3, NVML used / 1024**3); tempi in s -> min = /60."""
import json, glob
R = "/tmp/repo/results"
print("== Tabella 5 / maxpower")
for f in sorted(glob.glob(f"{R}/maxpower_*_8gpu_results.json"), key=lambda x: (len(x), x)):
    d = json.load(open(f)); m = d["metadata"]; t = d["timings"]; mem = d["memory"]; rs = d["results_summary"]
    alg = m["configuration"].get("clustering_algorithm", "leiden" if m["configuration"].get("leiden_backend") else "?")
    print(f"{f.split('/')[-1]:45s} target={m.get('target_cells', m['n_cells_input']):>9} src={m.get('n_cells_source_file')} "
          f"alg={alg:7s} total={t['total']:9.2f}s = {t['total']/60:7.2f} min  RAM={mem['peak_ram_gb']:7.2f}  VRAM={mem['peak_vram_gb']:6.2f} "
          f"({100*mem['peak_vram_gb']/640:.2f}% di 640)  DE={t.get('de_testing')}  rmm={m['configuration'].get('dask_cluster',{}).get('rmm_pool_size')}  "
          f"nclust={rs['n_clusters_0.5']},{rs['n_clusters_1.0']},{rs['n_clusters_1.5']}  cells_qc={rs['n_cells_after_qc']} genes_qc={rs['n_genes_after_qc']}  ts={m['timestamp'][:10]}")
print(json.load(open(f"{R}/maxpower_limit_8gpu.json")))
d = json.load(open(f"{R}/maxpower_11900000_8gpu_results.json")); det = d["memory"]["detailed"]
print("\n== traccia 11.9M")
print(" fine data loading:", det["data_loading_ram_after_gb"], " inizio QC:", det["qc_filtering_ram_before_gb"],
      " salto:", round(det["qc_filtering_ram_before_gb"] - det["data_loading_ram_after_gb"], 2))
print(" delta normalizzazione:", round(det["normalization_ram_after_gb"] - det["normalization_ram_before_gb"], 2),
      " delta HVG:", round(det["hvg_selection_ram_after_gb"] - det["hvg_selection_ram_before_gb"], 2))
print(" delta scale (netto):", round(det["scale_ram_after_gb"] - det["scale_ram_before_gb"], 2))
print(" max post-step RAM:", max(v for k, v in det.items() if k.endswith("_ram_after_gb")),
      [k for k, v in det.items() if k.endswith("_ram_after_gb") and v == max(w for kk, w in det.items() if kk.endswith("_ram_after_gb"))])
print(" Leiden RAM: da", det["leiden_0.5_ram_before_gb"], "a", det["leiden_1.5_ram_after_gb"], "delta",
      round(det["leiden_1.5_ram_after_gb"] - det["leiden_0.5_ram_before_gb"], 2))
print(" VRAM: neighbors_after", det["neighbors_vram_after_gb"], " leiden_0.5_before", det["leiden_0.5_vram_before_gb"],
      " leiden_1.5_after", det["leiden_1.5_vram_after_gb"], " delta dentro Leiden",
      round(det["leiden_1.5_vram_after_gb"] - det["leiden_0.5_vram_before_gb"], 2))
print(" 535/2048 =", round(100*534.55/2048, 1), "%  535/1800 =", round(100*534.55/1800, 1), "%")
src = json.load(open(f"{R}/maxpower_3436470_8gpu_results.json"))["memory"]["detailed"]
print(" RSS caricamento 3.44M (fonte):", round(det["data_loading_ram_after_gb"] - det["data_loading_ram_before_gb"], 2),
      " x 11.9/3.43647 =", round((det["data_loading_ram_after_gb"] - det["data_loading_ram_before_gb"]) * 11.9e6 / 3436470, 1))
print(" componenti Tab.6 baseline: 190+190+96+60 =", 190+190+96+60, "; densa 11.9M x 2000 x 4 B =", 11.9e6*2000*4/1e9, "GB =", round(11.9e6*2000*4/2**30, 1), "GiB")
c = json.load(open(f"{R}/maxpower_chunked_12000000_8gpu_results.json"))
print("\n== chunked 12M: total", c["timings"]["total"], "s =", round(c["timings"]["total"]/60, 2), "min; RAM", c["memory"]["peak_ram_gb"],
      "; VRAM", c["memory"]["peak_vram_gb"], "; 48.84/9.6 =", round(48.84/9.6, 2), "; nclust", c["results_summary"]["n_clusters_0.5"])
cd = c["memory"]["detailed"]; print(" chunked: normalization_after", cd["normalization_ram_after_gb"], "-> hvg_chunked_before", cd["hvg_selection_chunked_ram_before_gb"])
print("\n== DE 3.4M (Tabella 7)")
base = json.load(open(f"{R}/de_benchmark_ttest_cpu.json"))["results"]["ttest_cpu"]["time"]
for f in sorted(glob.glob(f"{R}/de_benchmark_*.json")):
    d = json.load(open(f))
    for k, v in d["results"].items():
        tt = v.get("time")
        extra = {kk: v[kk] for kk in ("n_pseudobulk_samples", "n_donors", "n_clusters") if kk in v}
        print(f"  {f.split('/')[-1]:38s} {k:22s} time={tt:10.2f}  round={round(tt) if tt and tt > 0 else tt}  speedup vs ttest_cpu={base/tt if tt and tt > 0 else None}  {extra}"
              f"  n_cells={d['n_cells']} genes={d['n_genes_raw']} clusters={d['n_clusters']}")
pb = json.load(open(f"{R}/de_benchmark_pseudobulk.json"))["results"]["pseudobulk"]
print("  pseudo-campioni per cluster:", pb["n_pseudobulk_samples"] / pb["n_clusters"], "; t-test CPU in min:", base/60, "; pseudobulk in min:", pb["time"]/60)
print("  da arrotondati: 5598/128 =", 5598/128, "; 5598/127 =", 5598/127)
