"""Track A: scaling multi-GPU (righe 228-232, 418, 432, 438).
Fasi come in generate_figures.py/fig_multigpu_breakdown e metadata.configuration:
CPU = data_loading+qc_filtering+normalization+hvg_selection; multi-GPU = pca+neighbors;
single-GPU = gpu_transfer+scale+leiden*3+umap+de_testing. Media su r1..r5, SD ddof=1."""
import json, glob, statistics as st
R = "/tmp/repo/results"
CPU = ["data_loading","qc_filtering","normalization","hvg_selection"]
MG = ["pca","neighbors"]
SG = ["gpu_transfer","scale","leiden_0.5","leiden_1.0","leiden_1.5","umap","de_testing"]
def load(p, n):
    fs = sorted(glob.glob(f"{R}/{p}_{n}_r*_results.json"))
    return [json.load(open(f)) for f in fs], fs
for n in (10000, 100000, 500000, 1300000):
    print(f"===== {n}")
    for g in (2, 4, 8):
        ds, fs = load(f"gpu{g}", n)
        for d, f in zip(ds, fs):
            t = d["timings"]
            c = sum(t[k] for k in CPU); m = sum(t[k] for k in MG); s = sum(t[k] for k in SG)
            if n == 1300000:
                print(f"  gpu{g} r{d['metadata']['repeat_id']} total={t['total']:8.2f} CPU={c:7.2f} ({100*c/t['total']:.1f}%) MG={m:6.2f} ({100*m/t['total']:.1f}%) SG={s:6.2f} ({100*s/t['total']:.1f}%) "
                      f"load={t['data_loading']:.1f} qc={t['qc_filtering']:.1f} norm={t['normalization']:.1f} hvg={t['hvg_selection']:.1f} pca={t['pca']:.2f} nn={t['neighbors']:.2f} de={t['de_testing']:.1f} ts={d['metadata']['timestamp'][:19]} drv={d['metadata']['gpu_info']['driver_version']}")
        mc = st.mean(sum(d['timings'][k] for k in CPU) for d in ds)
        sc_ = st.stdev(sum(d['timings'][k] for k in CPU) for d in ds)
        mm = st.mean(sum(d['timings'][k] for k in MG) for d in ds)
        ms = st.mean(sum(d['timings'][k] for k in SG) for d in ds)
        mt = st.mean(d['timings']['total'] for d in ds)
        per = {k: st.mean(d['timings'][k] for d in ds) for k in CPU+MG+SG}
        print(f" gpu{g} MEAN total={mt:8.2f} CPU={mc:7.2f}+/-{sc_:5.2f} ({100*mc/mt:.1f}%) MG={mm:6.2f} ({100*mm/mt:.1f}%) SG={ms:6.2f} ({100*ms/mt:.1f}%)")
        print("        per-step means:", {k: round(v,2) for k,v in per.items()})
# 12% claim
a = st.mean(d['timings']['total'] for d in load('gpu2',1300000)[0]); b = st.mean(d['timings']['total'] for d in load('gpu8',1300000)[0])
print(f"\n(2GPU-8GPU)/2GPU = {100*(a-b)/a:.2f}%  ; 2GPU/8GPU = {a/b:.4f}; diff = {a-b:.2f} s")
# decomposition of the 2->8 difference into phases
d2, _ = load('gpu2',1300000); d8, _ = load('gpu8',1300000)
for name, keys in (("CPU",CPU),("MG",MG),("SG",SG)):
    x = st.mean(sum(d['timings'][k] for k in keys) for d in d2) - st.mean(sum(d['timings'][k] for k in keys) for d in d8)
    print(f"  delta {name} (2GPU - 8GPU) = {x:.2f} s ({100*x/(a-b):.1f}% of the gap)")
# representative run
for d, f in zip(*load('gpu8',1300000)):
    if abs(d['timings']['total']-463.4) < 0.1:
        t = d['timings']; c = sum(t[k] for k in CPU); m = sum(t[k] for k in MG); s = sum(t[k] for k in SG)
        print(f"\nrepresentative = {f}: total={t['total']} CPU={c:.4f} ({100*c/t['total']:.2f}%), MG={m:.4f} ({100*m/t['total']:.2f}%), SG={s:.4f} ({100*s/t['total']:.2f}%); rank by total among 5 = slowest? ")
# CPU-pipeline preprocessing times for comparison
for n in (500000, 1300000):
    ds,_ = load('cpu', n)
    print(f"cpu {n}: mean CPU-prep (load+qc+norm+hvg) = {st.mean(sum(d['timings'][k] for k in CPU) for d in ds):.2f}; per-step:", {k: round(st.mean(d['timings'][k] for d in ds),2) for k in d['timings']})
