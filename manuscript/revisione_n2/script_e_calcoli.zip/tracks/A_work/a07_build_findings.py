"""Track A: costruisce tracks/A_findings.json (una voce per riga di inv_A.json + finding nuovi).
I valori 'recomputed' vengono dagli script a01-a06 di questa cartella (output riportati nelle note)."""
import json, os, re

BASE = "/tmp/claude-0/-home-claude/e2229d1f-65c5-5244-af74-f9741477965d/scratchpad/review"
inv = json.load(open(f"{BASE}/tracks/inv_A.json"))
W = "tracks/A_work/"
T4 = W + "a01_table4.py: results/<cfg>_<N>_r1..r5_results.json, timings.total, memory.peak_ram_gb/peak_vram_gb; media r1-r5, SD campionaria ddof=1, picchi = media dei picchi per ripetizione"
PS = W + "a02_perstep.py: rapporto delle medie r1-r5 CPU/GPU per step (stessa convenzione di scripts/generate_figures.py fig_speedup_heatmap)"
MG = W + "a03_multigpu.py: gpu{2,4,8}_<N>_r1..r5, fasi come metadata.configuration (CPU=load+qc+norm+hvg; multi-GPU=pca+neighbors; single-GPU=gpu_transfer+scale+leiden*3+umap+de)"
CC = W + "a04_concordance.py: results/concordance_10000_r1.json + results_summary dei JSON a 10k"
SD = W + "a05_stress_de.py: results/maxpower_*_8gpu_results.json, maxpower_limit_8gpu.json, maxpower_chunked_12000000_8gpu_results.json, de_benchmark_*.json"
SP = W + "a06_spatial_discussion.py: SPATIAL/results/spatial_{cpu,gpu}_<platform>_r2..r5_results.json e spatial_concordance_<platform>.json"
NA = "nessuna quantita da ricalcolare"

F = {}
def f(i, status, severity, claimed, recomputed, source, note):
    F[i] = dict(status=status, severity=severity, claimed=claimed, recomputed=recomputed, source=source, note=note)

def na(i, note="Riga senza quantita verificabili (marcatori di affiliazione, anni di citazione o metadati YAML). Contenuto bibliografico fuori dal perimetro del track A."):
    f(i, "UNVERIFIABLE", "info", "n.a.", NA, "n.a.", note)

# ---------------- front matter / abstract ----------------
f("A0001", "MISMATCH", "major", "Titolo: single-cell AND spatial transcriptomics 'on NVIDIA DGX H100'",
  "Spatial eseguito su RTX 4090 locale (SPATIAL/results metadata.gpu_info.gpu_name = 'NVIDIA GeForce RTX 4090'); nessun run spatial su DGX",
  "SPATIAL/results/spatial_gpu_*_r*_results.json metadata.gpu_info", "Il titolo attribuisce al DGX H100 anche la parte spatial, che il testo stesso (righe 159-163) dichiara eseguita in locale su RTX 4090.")
for i in ("A0002", "A0003", "A0004", "A0005", "A0006"):
    na(i)
f("A0007", "MISMATCH", "major", "benchmark 'on the 1.3-million mouse brain cell dataset', 5 taglie 10k-1.3M, 5 ripetizioni",
  "5 taglie x 5 ripetizioni confermate (115 JSON). Ma il dataset non e il 10x 1.3M E18: geni dopo QC a 1.3M = 39,182 (>27,998 geni totali del dataset 10x); scripts/download_data.py scarica 1.3M cellule casuali da CELLxGENE Census 2025-11-08",
  "results/*_1300000_r*_results.json results_summary.n_genes_after_qc; scripts/download_data.py download_from_census; TENxBrainData manual (27,998 geni, 1,306,127 cellule, 2 topi) letto in sessione",
  "Vedi A0024. Il numero di geni dopo il filtro supera quello del dataset 10x originale: impossibile se il dato fosse quello citato.")
f("A0008", "PASS", "info", "120-fold; 435 s vs 52,056 s; 14.5 h -> 7.3 min",
  "52,056.21 / 435.18 = 119.62x; 52,056.21 s = 14.46 h; 435.18 s = 7.25 min", T4,
  "Media r1-r5. Il valore GPU e la configurazione 8 GPU (job con 200 core CPU); vedi finding nuovi sul fatto che PCA/neighbours non erano distribuiti.")
f("A0009", "PASS", "info", "HVG Jaccard 1.0; PCA |rho| 1.0; ARI 0.908-0.963",
  "jaccard 1.0; mean_abs_spearman_rho 1.0; ARI 0.907733 (r=1.0) - 0.963095 (r=1.5)", CC,
  "Valori corretti, ma calcolati su un run dell'11 marzo diverso dalle ripetizioni del benchmark (vedi finding nuovo sulla provenienza della concordanza).")
f("A0010", "PASS", "info", "11.9M cellule; GPU VRAM al 7.6%",
  "maxpower_11900000: 11,899,623 cellule dopo QC; VRAM aggregata 48.84 GiB = 7.63% di 640", SD,
  "Numeri corretti. Pero le cellule oltre 3,436,470 sono copie replicate (resize_dataset): vedi finding nuovo.")
f("A0011", "PASS", "info", "pseudo-bulk 44x piu veloce del t-test a 3.4M",
  "5,597.79 / 127.47 = 43.91x -> 44x", SD, "Il 44x e corretto; la Tabella 7 riporta invece 43.7x (vedi A0210).")
f("A0012", "PASS", "info", "51.6x (HD 8 um); 3,272x co-occurrence; rho >= 0.9995",
  "51.64x; 3,573.201/1.0922 = 3,271.6x; rho minimo Moran/Geary = 0.999526", SP, "Convenzione dichiarata: media ripetizioni 2-5.")

# ---------------- introduction ----------------
for i in ("A0013", "A0014", "A0015", "A0018", "A0019", "A0020"):
    na(i, "Frase con sole citazioni: nessun numero da ricalcolare nel track A; contenuto delle fonti non letto in questa sessione (track citazioni).")
f("A0016", "PASS", "info", "analisi di 1M cellule richiede 'hours to days' su CPU",
  "CPU 1.3M: 52,056.21 s = 14.46 h (media r1-r5)", T4, "Coerente con i dati del benchmark (ore).")
f("A0017", "PASS", "info", "Visium HD fino a 6.3 milioni di bin da 2 um per sezione",
  "n_spots_input = 6,296,688 (Visium HD 2 um)", "SPATIAL/results/spatial_cpu_visium_hd_square_002um_r1_results.json metadata.n_spots_input",
  "Verificato per la sezione usata; 'up to' come affermazione generale sulla piattaforma non verificabile dai JSON.")
f("A0021", "PASS", "info", "scaling da 1 a 8 GPU", "configurazioni 1, 2, 4, 8 GPU presenti (gpu_, gpu2_, gpu4_, gpu8_)", T4,
  "Le configurazioni esistono; che le GPU aggiuntive siano state usate e contestato in A0047.")
na("A0022", "Domanda di ricerca: nessun numero.")
f("A0023", "PASS", "info", "DGX H100 e RTX 4090", "gpu_name 'NVIDIA H100 80GB HBM3' (scRNA) e 'NVIDIA GeForce RTX 4090' (spatial)",
  "results/gpu*_results.json e SPATIAL/results metadata.gpu_info", "")

# ---------------- methods scRNA ----------------
f("A0024", "MISMATCH", "critical", "'10x Genomics 1.3-million mouse brain cell dataset (E18) [@Zheng2017], obtained as a pre-processed AnnData h5ad file from the RAPIDS single-cell examples repository'",
  "Il codice del repo scarica da CELLxGENE Census (census_version 2025-11-08; filtro tissue_general=='brain', is_primary_data, assay 10x 3' v1-v3) 1,300,000 cellule casuali (seed 42) su ~3.44M; geni dopo QC 26,228 (10k) ... 39,182 (1.3M), oltre i 27,998 geni del dataset 10x; il set da 3.4M ha 202 donatori (de_benchmark_pseudobulk.json n_donors) contro i 2 topi del dataset 10x",
  "scripts/download_data.py (MAX_CELLS, CENSUS_VERSION, download_from_census); slurm/download.sh; results_summary.n_genes_after_qc; de_benchmark_pseudobulk.json; manuale Bioconductor TENxBrainData (27,998 geni, 1,306,127 cellule, two E18 mice) letto via WebFetch",
  "Identita del dataset errata: i dati sono un campione Census multi-donatore, non il dataset 10x E18 citato. Va corretto in Methods, abstract, limitazioni e citazione.")
f("A0025", "MISMATCH", "major", "'canonical large-scale single-cell benchmark ... approximately 1.3 million cells ... 10x Chromium'",
  "Input = 1,300,000 cellule (1,299,956 dopo QC) campionate da Census, assay 10x 3' v1-v3; non il dataset canonico 10x (1,306,127 cellule)",
  "results/cpu_1300000_r1_results.json; scripts/download_data.py", "Conseguenza di A0024.")
f("A0026", "MISMATCH", "minor", "sottocampioni 10k/50k/100k/500k con numpy.random.choice seed 42, 'in addition to the full 1.3M cell dataset'",
  "Sottocampionamento confermato nel codice (np.random.seed(42); choice senza reinserimento); ma il file da 1.3M e esso stesso un campione casuale di 1.3M cellule dal set Census da 3,436,470, non un dataset 'full'",
  "scripts/download_data.py create_subsamples e download_from_census", "")
na("A0027", "Frase con sole citazioni (track citazioni).")
f("A0028", "PASS", "info", "Scanpy 1.12, NumPy 2.2.6, igraph 1.0.0, rapids-singlecell 0.14.1, CuPy 13.6.0, RMM 26.2.0",
  "metadata.software_versions: scanpy 1.12, numpy 2.2.6, igraph 1.0.0, rapids_singlecell 0.14.1, cupy 13.6.0, rmm 26.2.0", "results/cpu_10000_r1 e gpu_10000_r1 metadata.software_versions", "")
na("A0029", "Frase con sola citazione.")
f("A0030", "MISMATCH", "minor", "'ten steps, each timed independently'",
  "Nelle pipeline CPU e 1-GPU lo scaling non ha un timer proprio: e dentro il timer 'pca' (toarray + scale + PCA su CPU; scale + PCA su GPU). Timer registrati: 9 step con Leiden su 3 timer. Nella pipeline multi-GPU esistono invece 'gpu_transfer' e 'scale' separati",
  "scripts/benchmark_cpu.py run_pca (righe 213-218); scripts/benchmark_gpu.py run_pca (righe 287-291); chiavi di timings nei JSON", "Lo 'PCA speedup' 4.8x-36.5x include quindi lo scaling.")
f("A0031", "PASS", "info", "Didascalia Tabella 1: parametri identici CPU/GPU salvo dove indicato", "Vedi righe della tabella; unica asimmetria non dichiarata: n_iterations di Leiden (A0040)", "scripts/benchmark_cpu.py; scripts/benchmark_gpu.py", "")
f("A0032", "PASS", "info", "Intestazione Tabella 1", NA, "n.a.", "")
f("A0033", "PASS", "info", "Step 1 Data loading, read_h5ad() da disco", "CPU: sc.read_h5ad; 1-GPU: sc.read_h5ad + rsc.get.anndata_to_GPU nello stesso timer", "scripts/benchmark_gpu.py load_and_transfer", "Il timer GPU include il trasferimento host-device: utile per interpretare A0133.")
f("A0034", "PASS", "info", "min_genes 200, min_cells 3, prefisso mt-", "filter_cells(min_genes=200), filter_genes(min_cells=3), startswith(('MT-','mt-'))", "scripts/benchmark_cpu.py qc_filter", "")
f("A0035", "PASS", "info", "target_sum 10,000 + log1p", "normalize_total(target_sum=1e4); log1p", "scripts/benchmark_cpu.py normalize", "")
f("A0036", "PASS", "info", "n_top_genes 2,000, Seurat v1", "highly_variable_genes(n_top_genes=2000) flavor di default 'seurat'; n_hvgs = 2000 in tutti i JSON", "scripts/benchmark_cpu.py; results_summary.n_hvgs", "")
f("A0037", "PASS", "info", "Scaling max_value 10, sparse to dense float32", "sc.pp.scale(max_value=10) dopo toarray (CPU); rsc.pp.scale(max_value=10) (GPU)", "scripts/benchmark_cpu.py run_pca", "Parametri corretti; lo step non e cronometrato separatamente (A0030).")
f("A0038", "PASS", "info", "PCA 50 componenti, seed 42", "n_comps=50, random_state=42", "scripts/benchmark_cpu.py; scripts/benchmark_gpu.py", "")
f("A0039", "PASS", "info", "k = 15, 50 PC, seed 42", "neighbors(n_neighbors=15, n_pcs=50, random_state=42)", "scripts/benchmark_cpu.py", "")
f("A0040", "MISMATCH", "minor", "Leiden r in {0.5,1.0,1.5}, seed 42, parametri identici",
  "CPU: sc.tl.leiden(flavor='igraph', n_iterations=2); GPU: rsc.tl.leiden con default n_iterations=100 (rapids-singlecell 0.14.1 tools/_clustering.py riga 130)",
  "scripts/benchmark_cpu.py righe 236-240; sorgente wheel rapids_singlecell-0.14.1 scaricato in scratchpad/rsc_src", "Asimmetria di parametri non dichiarata: incide su tempi e concordanza di Leiden.")
f("A0041", "PASS", "info", "UMAP 2 componenti, seed 42", "tl.umap(random_state=42) (2D di default)", "scripts/benchmark_cpu.py", "")
f("A0042", "PASS", "info", "DE Wilcoxon one-vs-rest, use_raw=True, Leiden r=1.0", "rank_genes_groups(groupby='leiden_1.0', method='wilcoxon', use_raw=True)", "scripts/benchmark_cpu.py run_de", "")
f("A0043", "PASS", "info", "OMP/MKL/OPENBLAS/NUMBA_NUM_THREADS = 100", "metadata.configuration.threading_vars = 100 per tutte le variabili; SLURM --cpus-per-task=100",
  "results/cpu_*_results.json; slurm/cpu_benchmark.sh", "Il backend 'OpenBLAS' non e registrato: numpy_blas_backend = 'blas' (non verificabile).")
f("A0044", "UNVERIFIABLE", "minor", "multi-GPU usato per i dataset oltre la VRAM di una GPU (500k e 1.3M)",
  "Nessun JSON o log di un tentativo 1-GPU fallito a 500k/1.3M; inoltre il multi-GPU e stato eseguito anche a 10k, 50k, 100k", "results/ (assenza di gpu_500000*, gpu_1300000*)", "")
f("A0045", "UNSUPPORTED", "major", "'within that path only PCA and neighbour graph construction had distributed GPU implementations usable'",
  "rapids-singlecell 0.14.1 accetta Dask array in QC (_qc.py), normalize/log1p (_normalize.py), scale (_scale.py) e HVG seurat (_hvg/_seurat_cellranger.py); e nel benchmark nemmeno PCA e neighbours erano distribuiti (A0047). OOM a 1 GPU non documentato",
  "sorgente rapids_singlecell-0.14.1 (grep DaskArray); scripts/benchmark_multigpu.py", "La giustificazione aggiunta il 2 settembre non regge contro la libreria usata.")
f("A0046", "PASS", "info", "normalizzazione 329x piu veloce su singola GPU", "0.4281 / 0.0013 = 329.3x a 10k", PS,
  "Valore dominato dalla ripetizione 1 della CPU (1.749 s contro 0.098 s in r2-r5): su r2-r5 il rapporto e 115x (vedi finding nuovo sulla convenzione).")
f("A0047", "MISMATCH", "critical", "'PCA and neighbour graph construction were distributed across N GPUs (N in {2, 4, 8}) via Dask workers'",
  "Il codice passa a rsc.pp.pca / rsc.pp.neighbors una matrice CuPy densa su GPU 0, non un Dask array: in rapids-singlecell 0.14.1 PCA va su Dask solo se X e DaskArray (_pca.py riga 202) e neighbours usa di default 'brute' su una GPU (mg_ivfflat/mg_ivfpq non usati). Dati coerenti: PCA+neighbours a 1.3M = 17.23 / 16.99 / 17.01 s con 2 / 4 / 8 GPU; a 500k 2.98 / 2.97 / 3.00 s",
  MG + "; scripts/benchmark_multigpu.py run_pca/neighbors; sorgente rapids_singlecell-0.14.1", "I worker Dask partono con 10 GB di pool RMM ciascuno ma restano inattivi. L'esperimento non misura lo scaling multi-GPU.")
f("A0048", "PASS", "info", "Scaling, Leiden, UMAP, DE su singola GPU (device 0)", "metadata.configuration.single_gpu_steps = gpu_transfer, scale, leiden, umap, de_testing",
  "results/gpu8_1300000_r1_results.json metadata.configuration", "Contraddice la frase precedente (riga 88) che mette lo scaling su CPU: vedi finding nuovo.")
f("A0049", "PASS", "info", "sei metriche di concordanza", "Tabella 2 elenca 6 metriche; concordance JSON contiene hvg, pca, knn, cluster (ARI/NMI), de", CC, "")
na("A0050", "Frase con sole citazioni (track citazioni).")
f("A0051", "PASS", "info", "Didascalia Tabella 2", NA, "n.a.", "")
f("A0052", "PASS", "info", "Intestazione Tabella 2", NA, "n.a.", "")
f("A0053", "PASS", "info", "HVG Jaccard su 2,000 HVG", "n_intersection 2000 / n_union 2000 = 1.0", CC + "; scripts/compare_results.py compare_hvgs", "")
f("A0054", "PASS", "info", "media |rho| di Spearman sui primi 10 loading, segno gestito", "compare_pca: abs(spearman) su PC1-PC10, n_genes 2000", "scripts/compare_results.py compare_pca", "")
f("A0055", "PASS", "info", "kNN Jaccard per cella, k = 15", "compare_knn: Jaccard per cella su row.indices della matrice distances", "scripts/compare_results.py compare_knn; scripts/benchmark_cpu.py save_results",
  "Definizione conforme al codice, ma la metrica ha un tetto strutturale a 0.9375 (vedi finding nuovo).")
f("A0056", "PASS", "info", "ARI", "cluster_concordance.*.ari presenti", CC, "")
f("A0057", "PASS", "info", "NMI", "cluster_concordance.*.nmi presenti", CC, "")
f("A0058", "PASS", "info", "Spearman dei logFC dei top 100 geni per cluster dopo matching ungherese", "compare_de: top 100 CPU, intersezione GPU, linear_sum_assignment", "scripts/compare_results.py", "")
f("A0059", "PASS", "info", "variante memory-optimised", "scripts/benchmark_maxpower.py (pipeline 'maxpower_8gpu')", SD, "")
f("A0060", "PASS", "info", "scale su CPU, PCA covarianza su 8 GPU (2,000 x 2,000), placeholder sparso, pool RMM 2 GB",
  "cpu_steps include 'scale'; pca_method 'covariance_distributed'; rmm_pool_size '2GB'; adata.X sostituita da csr vuota dopo PCA", "results/maxpower_11900000_8gpu_results.json metadata.configuration; scripts/benchmark_maxpower.py righe 622-660", "")
f("A0061", "PASS", "info", "ricerca binaria da 3.4M a 13.7M", "16 JSON da 1.7M a 11.9M + maxpower_limit_8gpu.json (max 11,900,000, first_oom_at 12,000,000, source_cells 3,436,470); 13.7M = 4 x 3,436,470 = 13,745,880, senza JSON",
  SD, "Il passo di 13.7M non ha JSON. Le taglie oltre 3,436,470 sono repliche del dataset sorgente (finding nuovo).")
f("A0062", "UNVERIFIABLE", "minor", "3.4M cellule, 41,000 geni, raw ~121 GB CSR",
  "n_cells 3,399,892 e n_genes_raw 41,321 confermati; 121 GB non presente in alcun JSON (solo nel diario CLAUDE.md)", "results/de_benchmark_*.json", "")
f("A0063", "MISMATCH", "minor", "sette strategie DE in disegno fattoriale",
  "Tabella 7 ne riporta 6; i JSON contengono 7 voci di cui una e il duplicato 'ttest_scatter_clean' (1,649.36 s); Wilcoxon CPU assente; pseudo-bulk solo su CPU", SD, "Il disegno non e fattoriale completo (3 test x 3 strategie = 9 celle).")
f("A0064", "PASS", "info", "500 x 3.4M x 4 byte ~ 6.8 GB", "500 x 3,399,892 x 4 = 6.80e9 byte", "calcolo diretto; n_cells da de_benchmark_*.json", "")
f("A0065", "PASS", "info", "pseudo-bulk: somma per donatore x cluster, CPM, log, Wilcoxon",
  "test_pseudobulk: somma raw per (donor_id, leiden_1.0), normalize_total(1e6), log1p, wilcoxon", "scripts/test_de_benchmark.py righe 619-720",
  "Non dichiarati: gruppi con <5 cellule scartati, cluster con <2 pseudo-campioni rimossi.")

# ---------------- hardware / environment ----------------
f("A0085", "PASS", "info", "8 x H100 80 GB, 112 core, 2 TB RAM", "8 GPU 'NVIDIA H100 80GB HBM3' (79.6 GiB); n_cpus 224 logici (= 112 core con HT); ram_total_gb 2048",
  "results/gpu8_*_results.json metadata.gpu_info; maxpower_*.json resource_utilization", "Modello CPU (8480C) e NVLink 4.0 non registrati nei JSON.")
f("A0086", "PASS", "info", "immagine base nvcr.io/nvidia/rapidsai/base:26.02-cuda12-py3.12", "Dockerfile: FROM nvcr.io/nvidia/rapidsai/base:26.02-cuda12-py3.12", "/tmp/repo/Dockerfile riga 3", "")
f("A0087", "PASS", "info", "Scanpy 1.12, rsc 0.14.1, CuPy 13.6.0, Dask 2026.1.1, Dask-CUDA 26.2.0, Python 3.12.12",
  "metadata.software_versions identici", "results/gpu8_1300000_r1_results.json metadata.software_versions", "")
f("A0088", "MISMATCH", "major", "'Jobs were submitted via SLURM on a dedicated DGX H100 node (poddgx02)'",
  "Due driver diversi nelle stesse ore: 535.247.01 (tutti i run 1, 2, 4 GPU) e 535.183.01 (tutti i run 8 GPU); gli script gpu_1/2/4/8.sh e cpu_benchmark.sh non hanno --nodelist; i job 1, 2 e 4 GPU girano in contemporanea sullo stesso nodo (timestamp intercalati, 15 marzo 21:53-23:03)",
  "metadata.gpu_info.driver_version e metadata.timestamp di results/gpu*_results.json; slurm/gpu_*.sh", "Il benchmark principale ha usato almeno due nodi e allocazioni condivise: confonde il confronto fra numeri di GPU.")
f("A0089", "MISMATCH", "minor", "RTX 4090, 100 core, 256 GB, driver 550.x",
  "driver_version 580.126.09; n_cpus 128 (logici) in tutti i JSON spatial", "SPATIAL/results/spatial_gpu_*_r*_results.json metadata", "Driver dichiarato errato; '100 CPU cores' non riscontrabile (128 logici).")
f("A0090", "PASS", "info", "Squidpy 1.8.1 e spatialdata sopra la stessa immagine", "metadata squidpy 1.8.1; requirements-squidpy.txt spatialdata==0.3.0",
  "SPATIAL/results/*metadata.software_versions; /tmp/repo/requirements-squidpy.txt", "")
f("A0091", "UNVERIFIABLE", "minor", "spatial GPU fallito sul driver 535.183.01 (CUDA 12.2)", "Nessun log o JSON del tentativo su DGX; il driver 535.183.01 compare nei run 8 GPU, ma i run 1/2/4 GPU riportano 535.247.01",
  "results/gpu*_results.json metadata.gpu_info", "")
f("A0092", "UNVERIFIABLE", "info", "tentativo di downgrade a RAPIDS 25.02", "Nessuna traccia nei file di risultati", "n.a.", "")
f("A0093", "PASS", "info", "spatial: r1 esclusa, media r2-r5", "5 ripetizioni per piattaforma; con media r2-r5: HD 8 um 4,068.40/78.79 = 51.64x come in Tabella 8", SP,
  "Convenzione diversa da quella scRNA (media r1-r5): vedi finding nuovo.")
f("A0094", "PASS", "info", "codice e JSON su github.com/lucavd/2026.scRNA_DGX", "/tmp/repo e il clone indicato nel brief (commit a4b9b9e) e contiene results/", "/tmp/repo", "")
f("A0095", "UNSUPPORTED", "major", "immagine 'lucavd/sc-benchmark:latest' che 'pins the full package environment'",
  "Il Dockerfile installa rapids-singlecell, scanpy, numpy ecc. senza versioni; constraints.txt fissa pacchetti RAPIDS 24.06 (numpy 1.26.4, dask 2024.5.1) incompatibili con quelli registrati (numpy 2.2.6, dask 2026.1.1) e non e usato dal Dockerfile; tag 'latest'",
  "/tmp/repo/Dockerfile; /tmp/repo/constraints.txt; metadata.software_versions", "Le versioni dichiarate coincidono con i JSON, ma l'ambiente non e fissato dal Dockerfile.")
f("A0096", "PASS", "info", "seed 42 per subsampling, PCA, Leiden, UMAP", "RANDOM_SEED = 42 in benchmark_cpu/gpu/multigpu e download_data; random_seed 42 in metadata", "scripts/*.py; metadata.random_seed", "")
na("A0097", "Frase con citazioni; nessun numero. Nota: a 10k le etichette GPU sono identiche nelle 5 ripetizioni; non determinismo osservato solo da 50k (finding nuovo).")

# ---------------- results: Table 4 and text ----------------
f("A0098", "PASS", "info", "23 configurazioni, 5 ripetizioni ciascuna", "5 CPU + 3 GPU1 + 15 multi-GPU = 23; n_files = 5 per ciascuna", T4, "")
f("A0099", "PASS", "info", "435.2 +/- 16.2 s (7.3 min) vs 52,056.2 +/- 392.0 s (14.5 h); 119.6x",
  "gpu8 1.3M: 435.18 +/- 16.22; CPU: 52,056.21 +/- 392.04; 119.62x; 7.25 min; 14.46 h", T4, "SD campionaria (ddof=1); con ddof=0 sarebbe 14.51 e 350.65.")
f("A0100", "PASS", "info", "12-fold a 10k (3.3 +/- 1.7 vs 39.5 +/- 10.2)", "39.476/3.2825 = 12.03x; 3.28 +/- 1.75; 39.48 +/- 10.19", T4,
  "Le SD sono dominate dalla ripetizione 1 (CPU r1 57.70 s contro 34.51-35.16 s; GPU r1 6.40 contro 2.40-2.62).")
f("A0101", "MISMATCH", "major", "'The speedup increased monotonically with dataset size: 33.6x at 50k, 43.7x at 100k, 34.9x at 500k (2 GPU), and 119.6x at 1.3M'",
  "Sequenza 12.03 -> 33.68 -> 43.78 -> 34.93 -> 119.62: non monotona (cala da 100k a 500k). Con medie non arrotondate 33.7x e 43.8x (33.6 e 43.7 vengono da rapporti di valori gia arrotondati)",
  PS + " (sezione end-to-end)", "Configurazioni miste (1, 2, 8 GPU) e calo a 500k: l'affermazione di monotonia e falsa.")
f("A0102", "PASS", "info", "Tabella 4: media +/- SD su cinque ripetizioni", "Riprodotta con media r1-r5, SD ddof=1, picchi = media dei picchi per ripetizione", T4,
  "Il motivo dell'assenza 1-GPU a 500k e 1.3M (OOM) non ha JSON o log. La colonna 'Peak' e una media di picchi, non un massimo: va dichiarato.")
f("A0103", "PASS", "info", "Intestazione Tabella 4", NA, "n.a.", "")
T4ROWS = {
    "A0104": ("CPU 10k: 39.5 / 10.2 / 1.2", "39.48 / 10.19 / 1.18"),
    "A0105": ("GPU1 10k: 3.3 / 1.7 / 2.4 / 40.7", "3.28 / 1.746 / 2.44 / 40.70"),
    "A0106": ("GPU2 10k: 4.9 / 2.6 / 2.3 / 52.4", "4.90 / 2.60 / 2.30 / 52.43"),
    "A0107": ("GPU4 10k: 4.9 / 2.6 / 2.3 / 65.0", "4.91 / 2.649 / 2.27 / 64.99"),
    "A0108": ("GPU8 10k: 4.9 / 2.3 / 2.3 / 106.5", "4.86 / 2.30 / 2.32 / 106.48"),
    "A0109": ("CPU 50k: 282.5 / 9.1 / 3.6", "282.46 / 9.13 / 3.56"),
    "A0110": ("GPU1 50k: 8.4 / 2.2 / 5.4 / 40.7", "8.39 / 2.23 / 5.41 / 40.70"),
    "A0111": ("GPU2 50k: 14.7 / 2.4 / 3.5 / 52.4", "14.69 / 2.38 / 3.52 / 52.44"),
    "A0112": ("GPU4 50k: 14.6 / 2.6 / 3.5 / 65.0", "14.60 / 2.63 / 3.452 / 65.03"),
    "A0113": ("GPU8 50k: 15.1 / 2.2 / 3.4 / 106.5", "15.13 / 2.2499 / 3.450 / 106.52"),
    "A0114": ("CPU 100k: 646.7 / 10.5 / 6.7", "646.69 / 10.548 / 6.654"),
    "A0115": ("GPU1 100k: 14.8 / 2.2 / 8.8 / 40.7", "14.77 / 2.22 / 8.79 / 40.70"),
    "A0116": ("GPU2 100k: 26.9 / 2.4 / 4.9 / 52.4", "26.852 / 2.38 / 4.87 / 52.448"),
    "A0117": ("GPU4 100k: 26.9 / 2.3 / 4.9 / 65.1", "26.94 / 2.29 / 4.89 / 65.09"),
    "A0118": ("GPU8 100k: 26.4 / 2.6 / 4.9 / 106.6", "26.44 / 2.61 / 4.94 / 106.57"),
    "A0119": ("CPU 500k: 4,346.7 / 40.3 / 29.7", "4,346.69 / 40.30 / 29.69"),
    "A0120": ("GPU2 500k: 124.5 / 2.9 / 15.6 / 52.7", "124.46 / 2.8525 / 15.57 / 52.66"),
    "A0121": ("GPU4 500k: 125.0 / 6.0 / 15.9 / 65.5", "124.96 / 6.03 / 15.90 / 65.50"),
    "A0122": ("GPU8 500k: 124.6 / 3.7 / 15.5 / 107.0", "124.60 / 3.72 / 15.548 / 106.98"),
    "A0123": ("CPU 1.3M: 52,056.2 / 392.0 / 107.4", "52,056.21 / 392.04 / 107.354"),
    "A0124": ("GPU2 1.3M: 493.3 / 10.3 / 60.7 / 74.9", "493.29 / 10.32 / 60.74 / 74.94"),
    "A0125": ("GPU4 1.3M: 486.6 / 20.2 / 60.7 / 92.7", "486.63 / 20.21 / 60.69 / 92.69"),
    "A0126": ("GPU8 1.3M: 435.2 / 16.2 / 52.3 / 134.2", "435.18 / 16.22 / 52.29 / 134.18"),
}
T4NOTES = {
    "A0105": "Il picco VRAM (40.7) e il pool RMM preallocato al 50% della GPU, non il working set.",
    "A0108": "VRAM aggregata 106.5 GB a 10k: sono i pool RMM dei worker Dask (circa 9.8 GiB ciascuno), non dati.",
    "A0113": "RAM media 3.450 esatta: 3.4 o 3.5 a seconda della regola di arrotondamento; accettato.",
    "A0124": "Picco RAM non rappresentativo: r1 = 94.05 GB, r2-r5 = 52.41-52.43 GB; la media 60.7 e trascinata da r1.",
    "A0125": "Come A0124: r1 = 94.06 GB, r2-r5 = 52.29-52.40 GB.",
    "A0126": "VRAM per ripetizione 93.71 / 135.31 / 144.23 / 150.92 / 146.71: cresce dopo r1 per residui di VRAM fra ripetizioni nello stesso processo (data_loading_vram_before 4.33 GB in r1, 39.6 GB in r2).",
}
for k, (cl, rc) in T4ROWS.items():
    f(k, "PASS", "info", cl, rc + " (tempo medio / SD / RAM media / VRAM media)", T4, T4NOTES.get(k, ""))

f("A0127", "PASS", "info", "speedup per step su quasi due ordini di grandezza", "da 0.36x (Leiden 0.5, 10k) a 329.3x (normalizzazione, 10k); escluso <1: 4.79x-329x", PS, "")
f("A0128", "PASS", "info", "normalizzazione 329x / 206x / 173x a 10k / 50k / 100k", "329.29x / 206.06x / 173.07x", PS,
  "Con r2-r5: 115x / 134x / 137x. Il primato a 10k dipende dalla ripetizione 1 della CPU (1.749 s contro 0.098 s).")
f("A0129", "PASS", "info", "HVG 24-94x, neighbours 44-88x, UMAP 27-45x, DE 16-88x", "HVG 23.64-94.22; neighbours 44.31-88.14; UMAP 26.92-45.29; DE 15.59-87.53", PS, "")
f("A0130", "PASS", "info", "PCA da 4.8x a 36.5x", "4.79x (10k), 20.50x (50k), 36.46x (100k)", PS,
  "Il timer 'pca' include lo scaling (e la densificazione su CPU): non e solo SVD, come implica il commento sull'intensita aritmetica.")
f("A0131", "PASS", "info", "Fig. 1: fino a 329x; data loading 0.76-0.85x", "329.29x; data loading 0.85 / 0.80 / 0.76", PS, "")
f("A0132", "MISMATCH", "minor", "'On CPU, DE testing and neighbour graph construction dominate'",
  "CPU medie: 10k DE 21.67 s, UMAP 9.70 s, neighbours 4.88 s; 50k DE 239.71, UMAP 22.34, neighbours 6.53; 100k DE 561.77, UMAP 48.33, neighbours 9.20", PS, "Dominano DE e UMAP, non neighbours.")
f("A0133", "MISMATCH", "major", "data loading piu veloce su CPU (0.76-0.85x) perche domina 'the fixed overhead of CUDA context initialisation and RMM pool allocation'; 'the transfer completes in milliseconds'",
  "Inizializzazione RMM e warmup CUDA avvengono prima del timer (benchmark_gpu.py righe 228-229); il timer GPU include read_h5ad + anndata_to_GPU. L'eccesso GPU cresce con la taglia: +0.096 s (10k), +0.552 s (50k), +1.377 s (100k), quindi non e un costo fisso e non e di millisecondi",
  PS + "; scripts/benchmark_gpu.py run_pipeline", "Meccanismo contraddetto da codice e dati; l'etichetta 'GPU/CPU' indica in realta CPU/GPU.")
f("A0134", "PASS", "info", "lettori h5py via RAM CPU, niente GDS", "sc.read_h5ad su host poi rsc.get.anndata_to_GPU", "scripts/benchmark_gpu.py load_and_transfer", "128 GB/s di PCIe Gen5 non verificabile dai JSON.")
f("A0135", "MISMATCH", "major", "Leiden: a 10k CPU piu veloce (0.36x) per overhead costante di cuGraph; 1.80x a 50k; 3.58x a 100k",
  "Valori riprodotti solo per la risoluzione 0.5 (0.36 / 1.80 / 3.58). A 10k le risoluzioni 1.0 e 1.5 sono gia a favore della GPU (1.36x, 1.60x); lo 0.36x nasce dalla prima chiamata cuGraph della ripetizione 1 (1.703 s contro 0.09 s in r2, r3, r5); con r2-r5 a 10k res 0.5 = 1.12x. Lo short paper riporta invece 8.8x a 100k (res 1.0)",
  PS, "Selezione della risoluzione non dichiarata e meccanismo non supportato; incoerente con lo short paper (8.8x).")
f("A0136", "UNSUPPORTED", "major", "'Adding GPUs beyond two provided diminishing returns'",
  "Fase PCA+neighbours: 17.23 / 16.99 / 17.01 s (1.3M, 2/4/8 GPU), 2.98 / 2.97 / 3.00 s (500k): rendimento nullo, non decrescente. La differenza di tempo totale sta nel caricamento dati su CPU", MG, "Vedi A0047 e A0140.")
f("A0137", "PASS", "info", "500k: 124.5, 125.0, 124.6 s", "124.46, 124.96, 124.60", T4, "")
f("A0138", "PASS", "info", "8 GPU (435.2 s) 12% piu veloci di 2 GPU (493.3 s)", "(493.29-435.18)/493.29 = 11.78%", T4,
  "Numero corretto; l'attribuzione al numero di GPU e falsa (A0140).")
f("A0139", "PASS", "info", "run rappresentativo 8 GPU a 1.3M: 463.4 s; CPU 348.7 s (75%); multi-GPU 17.5 s (4%); single-GPU 97.2 s (21%)",
  "results/gpu8_1300000_r1: total 463.43; CPU 348.68 (75.2%); PCA+neighbours 17.52 (3.8%); transfer+scale+Leiden*3+UMAP+DE 97.23 (21.0%)", MG,
  "Il run e r1, il piu lento dei 5 (gli altri 422.67-432.43 s). Media r1-r5: 78.0% / 3.9% / 18.1%.")
f("A0140", "MISMATCH", "critical", "'Since CPU preprocessing is constant regardless of GPU count ... only the PCA and neighbour steps benefit from additional GPUs'",
  "Preprocessing CPU a 1.3M: 399.53 +/- 16.85 s (2 GPU), 388.94 +/- 30.69 (4 GPU), 339.36 +/- 7.56 (8 GPU): non costante (data loading 148.99 / 135.07 / 90.61 s). PCA+neighbours 17.23 / 16.99 / 17.01 s: nessun beneficio. Il divario 2->8 GPU di 58.12 s e per il 103.5% nella fase CPU (+60.17 s), 0.4% nella fase multi-GPU (+0.21 s)",
  MG, "Il 12% e un artefatto di nodo e concorrenza (2 e 4 GPU sullo stesso nodo in parallelo, 8 GPU su un altro nodo con 200 core), non di Amdahl.")
f("A0141", "UNSUPPORTED", "major", "Fig. 3: 'Flat GPU curves demonstrate sublinear multi-GPU scaling'",
  "Le curve sono piatte perche PCA e neighbours non erano distribuiti (A0047); le differenze residue dipendono dal caricamento dati", MG, "")
f("A0142", "PASS", "info", "Fig. 4: preprocessing CPU dominante, fase multi-GPU piccola", "Medie r1-r5: CPU 69.8-71.3% (500k), 78.0-81.0% (1.3M); PCA+neighbours 2.4% e 3.5-3.9%", MG, "Vale come descrizione; la 'fase multi-GPU' non era multi-GPU (A0047).")

# ---------------- concordance ----------------
f("A0143", "PASS", "info", "concordanza su 10,000 cellule", "metadata.n_cells = 10000", CC, "")
f("A0144", "PASS", "info", "HVG 2,000 identici (Jaccard 1.000); PCA |rho| 1.000 su 10 PC", "n_intersection 2000 = n_union; mean_abs_spearman_rho 1.0, tutti i 10 PC rho = 1.0", CC,
  "Coerente anche con i run del benchmark: hvg_list_hash CPU = GPU a ogni taglia.")
f("A0145", "PASS", "info", "kNN Jaccard medio 0.930 (mediana 0.938)", "mean_jaccard 0.930422; median_jaccard 0.9375", CC,
  "Numeri corretti; l'interpretazione 'floating-point' non regge (finding nuovo sul tetto 0.9375).")
f("A0146", "PASS", "info", "ARI da 0.908 (r 1.0) a 0.963 (r 1.5); NMI 0.951-0.971", "ARI 0.907733 / 0.931675 / 0.963095; NMI 0.950564-0.970895", CC, "")
f("A0147", "MISMATCH", "major", "'at resolution 1.0, where both pipelines identified 40 clusters, reflects the inherent stochasticity of the Leiden algorithm'",
  "40/40 solo nel file di concordanza (run dell'11 marzo). Nei 5 run del benchmark (12 e 15 marzo) la CPU trova 41 cluster a r=1.0 e la GPU 40; etichette identiche (stesso hash) in tutte e 5 le ripetizioni per entrambe le pipeline a 10k, quindi nessuna stocasticita fra ripetizioni",
  CC, "La differenza CPU/GPU e di implementazione e parametri (n_iterations 2 contro 100), non di stocasticita.")
f("A0148", "MISMATCH", "major", "40 coppie, rho medio 0.946, '30 of the 40 pairs exceeding ... rho > 0.97'",
  "40 coppie; media 0.945536; coppie con rho > 0.97 = 34 (non 30); mediana 0.9995. Media trascinata da cpu17_gpu24 (rho -0.157, overlap 0.0) e cpu38_gpu5 (rho 0.448)", CC,
  "Il conteggio e sbagliato; una coppia del matching ungherese non condivide alcuna cellula.")
na("A0149", "Affermazione di confronto con la letteratura (track citazioni).")
f("A0150", "PASS", "info", "Fig. 5: HVG 1.000, PCA 1.000, kNN 0.930", "1.0 / 1.0 / 0.930422", CC, "")

# ---------------- memory ----------------
f("A0151", "PASS", "info", "nessun livello di memoria saturato 10k-1.3M", "RAM CPU max media 107.35 GiB su 2048; VRAM 1-GPU 40.70 su 79.6", T4, "")
f("A0152", "PASS", "info", "RAM CPU da 1.2 GB (10k) a 107.4 GB (1.3M), < 6% di 2 TB, circa lineare", "1.18 -> 107.35 GiB; 107.35/2048 = 5.24%; pendenza log-log 0.93", T4,
  "Contraddice la didascalia di Fig. 6 ('super-linearly'): vedi A0158. Le unita registrate sono GiB.")
f("A0153", "PASS", "info", "1.3M x 2,000 x 4 byte ~ 10.4 GB; raw 1.3M x 39,182 geni", "1.3e6 x 2000 x 4 = 1.04e10 byte; n_genes_after_qc = 39,182", "results/cpu_1300000_r1_results.json results_summary", "")
f("A0154", "PASS", "info", "VRAM 1-GPU costante a 40.7 GB", "40.70 a 10k, 50k, 100k (r1 40.93, r2-r5 40.64)", T4, "")
f("A0155", "PASS", "info", "8 GPU a 1.3M: picco aggregato 134.2 GB, media 16.8 GB per device, 21% di 80 GB",
  "134.18 / 8 = 16.77; 16.77/80 = 20.97%", T4,
  "Aritmetica corretta ma non e una misura per device: e la somma NVML su 8 GPU, fatta soprattutto dei pool RMM da 10 GB dei worker inattivi e di residui fra ripetizioni.")
f("A0156", "MISMATCH", "major", "'aggregate peak VRAM ... (134.2 GB) exceeds the 80 GB capacity ... so data must have been distributed'",
  "La VRAM aggregata sale di 78.62 GB all'avvio del cluster Dask sia a 10k (4.99 -> 83.61) sia a 1.3M (14.6 -> 93.22), indipendentemente dai dati: sono 8 pool RMM preallocati. A 10k (matrice HVG densa ~80 MB) il picco aggregato e gia 106.5 GB",
  T4 + "; memory.detailed scale_vram_after_gb / pca_vram_before_gb di gpu8_10000_r1 e gpu8_1300000_r1", "La prova della distribuzione non regge.")
f("A0157", "UNSUPPORTED", "major", "'Per-device VRAM traces (available in the benchmark result JSON files ...) show balanced usage across workers'",
  "I JSON contengono solo la somma su tutte le GPU (get_total_vram_used_gb) prima e dopo ogni step; nessuna traccia per device. Inoltre i JSON multi-GPU (15 marzo) non registrano actual_n_workers: il controllo via run_on_scheduler e stato aggiunto il 20 marzo (commit 07031f4)",
  "scripts/benchmark_multigpu.py time_step; git show 076a752:scripts/benchmark_multigpu.py; metadata.configuration.dask_cluster dei 75 JSON gpu2/4/8", "")
f("A0158", "MISMATCH", "major", "Fig. 6: 'right: GPU VRAM (per-device maximum)'; 'CPU RAM grows super-linearly'",
  "generate_figures.py fig_memory_profile traccia la media di peak_vram_gb, che per 2/4/8 GPU e la somma su tutti i device, confrontata con una linea a 80 GB per device; RAM CPU: pendenza log-log complessiva 0.93 e il testo (riga 250) dice 'approximately linearly'",
  "scripts/generate_figures.py righe 351-430; " + T4, "Didascalia errata due volte e in contrasto con il testo.")

# ---------------- stress test ----------------
f("A0159", "PASS", "info", "stress test con pipeline memory-optimised", "pipeline 'maxpower_8gpu' nei JSON", SD, "")
f("A0160", "PASS", "info", "scale su CPU, PCA covarianza su 8 GPU, placeholder sparso, solo embedding n x 50 su GPU", "codice righe 622-660 di benchmark_maxpower.py; cpu_steps include scale", SD, "")
f("A0161", "MISMATCH", "major", "successo a 11.9M (119 min); fallimento a 12.0M '(Leiden out-of-memory, SLURM signal 9)'",
  "11.9M: 7,150.62 s = 119.18 min; maxpower_limit first_oom_at = 12,000,000. Nessun JSON o log indica lo step del fallimento; la riga 262 e la didascalia di Tabella 6 dichiarano l'attribuzione 'unresolved' ed escludono Leiden come causa lato CPU",
  SD, "Incoerenza interna introdotta con le modifiche del 2 settembre: Tabella 5 e riga 260 attribuiscono ancora l'OOM a Leiden.")
f("A0162", "UNVERIFIABLE", "minor", "13.7M fallito nello scaling sparse-to-dense", "Nessun JSON per 13.7M (solo il diario)", "results/ (assente)", "Dovrebbe venire da un JSON o log SLURM del run 13,745,880.")
f("A0163", "PASS", "info", "535 GB (26% di 2 TB, 30% di 1.8 TB); VRAM 49 GB su 640 (7.6%)", "534.55 GiB; 26.1%; 29.7%; 48.84 GiB = 7.63%", SD, "Valori in GiB come registrati.")
f("A0164", "UNVERIFIABLE", "info", "nessuno dei due valori spiega il fallimento a 12M", "Nessun dato del run a 12M", "n.a.", "")
f("A0165", "PASS", "info", "535 GB = massimo RSS fra step del solo processo padre", "max dei *_ram_after_gb = 534.55 (pca_ram_after_gb)", SD, "")
f("A0166", "PASS", "info", "frase di raccordo", NA, "n.a.", "")
f("A0167", "MISMATCH", "major", "RAM da 124 GB (fine data loading) a 426 GB (inizio QC), +302 GB 'that belongs to no timed step'",
  "123.76 -> 426.10, +302.34 GiB (numeri corretti). Il salto e spiegato dal codice: resize_dataset() replica il file sorgente da 3,436,470 cellule fino a 11.9M fra data_loading e qc_filtering (benchmark_maxpower.py righe 580-582); 123.13 GiB x 11.9/3.43647 = 426.4 GiB",
  SD + "; scripts/benchmark_maxpower.py resize_dataset", "Non e un aumento non attribuibile: e la costruzione del dataset replicato, non cronometrata e non dichiarata.")
f("A0168", "PASS", "info", "normalizzazione e HVG con delta < 0.1 GB", "delta normalizzazione 0.06 GiB; HVG 0.00 GiB", SD, "")
f("A0169", "PASS", "info", "budget indicativo, attribuzione del fallimento irrisolta", NA, "n.a.", "In conflitto con Tabella 5 ('Fail (Leiden OOM)') e con la Discussione (A0297).")
f("A0170", "MISMATCH", "major", "Leiden < 1 GB di RAM host; 'aggregate VRAM rose from 28.8 GB to 48.8 GB across those calls'",
  "RAM durante le 3 chiamate Leiden: 453.33 -> 453.81 (+0.48 GiB, corretto). VRAM: 28.76 dopo neighbours, 48.76 gia prima della prima chiamata Leiden, 48.78 dopo l'ultima (+0.02 dentro Leiden). Il salto di 20 GB coincide con rmm.reinitialize(pool_allocator=True, devices=0) eseguito fra neighbours e Leiden (riga 678)",
  SD + "; scripts/benchmark_maxpower.py riga 678", "La VRAM non prova che Leiden lavori su GPU: il salto e un pool preallocato fuori dalle chiamate.")
f("A0171", "UNVERIFIABLE", "minor", "13.7M evento distinto nello scaling", "Nessun JSON per 13.7M", "results/ (assente)", "")
f("A0172", "UNVERIFIABLE", "minor", "KMeans: stesso fallimento a 13.7M", "Nessun JSON KMeans a 13.7M (i JSON KMeans sono 3.44M, 6.87M, 10.31M, tutti Pass)", SD, "")
f("A0173", "UNVERIFIABLE", "minor", "sparse-scatter a 14M fallito in HVG", "Nessun JSON del run a 14M", "results/ (assente)", "Il diario CLAUDE.md non vale come fonte di numeri.")
f("A0174", "PASS", "info", "variante chunked con batch da 100,000 cellule, senza matrice densa", "configuration.cell_batch_size 100000; dense_matrix_created false; pca_method chunked_covariance_distributed",
  "results/maxpower_chunked_12000000_8gpu_results.json", "")
f("A0175", "MISMATCH", "major", "chunked a 12.0M: 862 GB RAM, 10 GB VRAM, 156 min; fallito a 15.0M",
  "RAM 861.70 GiB (ok), VRAM 9.60 GiB (ok); tempo totale 7,891.25 s = 131.5 min, non 156; nessun JSON a 15.0M",
  SD, "156 min (9,363 s) compare solo nel diario CLAUDE.md, non nel JSON.")
f("A0176", "PASS", "info", "Tabella 5: tempi senza DE", "de_testing = 0.0 in tutti i run della ricerca binaria", SD, "Manca l'indicazione che le righe oltre 3.44M sono dati replicati.")
f("A0177", "PASS", "info", "Intestazione Tabella 5", NA, "n.a.", "")
f("A0178", "PASS", "info", "3.4M: 18 min, 155 GB, 49 GB, KMeans, Pass", "maxpower_3436470: 1,057.83 s = 17.63 min; 154.95; 48.54; kmeans", SD, "")
f("A0179", "PASS", "info", "6.9M: 38 min, 308 GB, 49 GB, KMeans", "maxpower_6872940: 2,304.85 s = 38.41 min; 308.10; 48.64; kmeans", SD, "")
f("A0180", "MISMATCH", "minor", "10.3M: 92 min, 465 GB, 49 GB, KMeans", "maxpower_10309410: 5,488.53 s = 91.48 min -> 91; 465.38; 48.76; kmeans", SD, "Arrotondamento errato del tempo.")
f("A0181", "PASS", "info", "11.5M: 114 min, 517 GB, 49 GB, Leiden", "6,850.85 s = 114.18 min; 517.16; 48.81; leiden", SD, "")
f("A0182", "PASS", "info", "11.9M: 119 min, 535 GB, 49 GB, Leiden, Pass (max)", "7,150.62 s = 119.18 min; 534.55; 48.84; max_cells 11,900,000", SD,
  "A 11.9M Leiden restituisce 135,710 / 142,959 / 147,154 cluster (contro 58 / 66 / 87 a 3.4M): risultato degenere su dati replicati.")
f("A0183", "UNVERIFIABLE", "major", "12.0M: Fail (Leiden OOM)", "first_oom_at 12,000,000 confermato; step del fallimento non registrato", "results/maxpower_limit_8gpu.json",
  "L'etichetta 'Leiden OOM' contraddice riga 262 e didascalia di Tabella 6 (attribuzione irrisolta, Leiden escluso lato CPU).")
f("A0184", "UNVERIFIABLE", "minor", "13.7M: Fail (scale OOM)", "Nessun JSON", "results/ (assente)", "")
f("A0185", "MISMATCH", "minor", "KMeans e Leiden con stesso footprint di RAM e di preprocessing CPU",
  "RAM coerente (Leiden 10.2M 460.50 GiB; KMeans 10.31M 465.38 GiB) ma tempi no: QC 2,217.9 s (Leiden 10.2M) contro 3,156.4 s (KMeans 10.31M); totale 69.2 contro 91.5 min. I run KMeans sono del 22 marzo, i Leiden del 17-20 marzo",
  SD, "Mescolare le due serie distorce la curva dei tempi di Tabella 5.")
f("A0186", "MISMATCH", "major", "Didascalia Tabella 6: componenti di base che 'sums to the 535 GB'",
  "190 + 190 + 96 + 60 = 536; e la scomposizione non corrisponde alla traccia: dopo il subset HVG adata.X e la matrice densa, esiste una sola copia sparsa completa (raw) di circa 420 GiB (123.13 GiB per 3.44M x 3.46)",
  SD, "Vedi A0189-A0190.")
f("A0187", "PASS", "info", "Intestazione Tabella 6", NA, "n.a.", "")
f("A0188", "PASS", "info", "sottotitolo: baseline misurata a 11.9M", "534.55 GiB a pca_ram_after_gb", SD, "")
f("A0189", "MISMATCH", "major", "matrice sparsa raw adata.X (CSR, ~5% densita) ~190 GB",
  "Al campione di 535 GiB adata.X e la matrice HVG densa (scale su CPU), non una sparsa raw; la sola matrice sparsa completa a 11.9M pesa circa 426 GiB (inizio QC), compatibile con 121 GB a 3.4M dichiarati alla riga 115 (x 3.5 = 424)",
  SD + "; scripts/benchmark_maxpower.py righe 611-627", "Componente inesistente in quel punto; densita ~5% non verificabile.")
f("A0190", "MISMATCH", "major", "copia raw adata.raw ~190 GB", "Stima dalla traccia: circa 420 GiB (una sola copia completa)", SD, "")
f("A0191", "PASS", "info", "matrice densa 12M x 2,000 float32 = 96 GB", "12e6 x 2000 x 4 = 96.0e9 byte (89.4 GiB); a 11.9M 95.2 GB = 88.7 GiB; delta netto dello step scale +81.71 GiB", SD,
  "Unita miste: le misure sono GiB, la stima e GB decimali.")
f("A0192", "UNVERIFIABLE", "minor", "metadati + runtime + overhead ~60 GB", "Residuo non misurato", "n.a.", "")
f("A0193", "MISMATCH", "minor", "subtotale misurato 535", "534.55 misurato (ok), ma le voci sopra sommano a 536", SD, "")
f("A0194", "PASS", "info", "sottotitolo", NA, "n.a.", "")
f("A0195", "MISMATCH", "major", "+302 'Unattributed rise ... not represented in that subtotal'",
  "+302.34 GiB misurato, ma e la replica del dataset (resize_dataset) e resta in memoria in tutti i campioni successivi: e gia dentro i 534.55", SD, "Doppio conteggio.")
f("A0196", "UNVERIFIABLE", "minor", "adata.raw = adata.copy() +400 (stima)", "Transitorio non campionato (fra hvg 426.89 e scale 433.93); ordine di grandezza compatibile con una copia da ~420 GiB", SD, "")
f("A0197", "UNVERIFIABLE", "minor", "sc.pp.scale +200 (stima)", "Delta netto misurato +81.71 GiB; il picco transitorio non e campionato", SD, "")
f("A0198", "UNVERIFIABLE", "minor", "conversione CSR->CSC +190 (stima)", "Nessuna misura", "n.a.", "")
f("A0199", "UNVERIFIABLE", "info", "temporanei HVG n.q.", "Dichiarato non quantificato", "n.a.", "")
f("A0200", "UNVERIFIABLE", "info", "worker Dask-CUDA n.q.", "Dichiarato non quantificato", "n.a.", "")
f("A0201", "UNSUPPORTED", "major", "strutture interne di Leiden ~50 GB (delta host < 1 GB)", "Delta host misurato +0.48 GiB; i ~50 GB non hanno fonte nei JSON", SD,
  "Voce in contraddizione con la misura riportata nella stessa riga.")
f("A0202", "PASS", "info", "allocazione SLURM 1,800", "#SBATCH --mem=1800G", "slurm/maxpower.sh riga 14", "")
f("A0203", "PASS", "info", "memoria fisica 2,048", "resource_utilization.ram_total_gb = 2048", "results/maxpower_11900000_8gpu_results.json", "")
f("A0204", "UNVERIFIABLE", "minor", "HVG OOM da baseline 629 GB a 14M, temporanei oltre 1,100 GB", "1800 - 629 = 1,171 (aritmetica ok); 629 GB senza JSON", "n.a.", "")

# ---------------- DE ----------------
f("A0205", "PASS", "info", "3.4 milioni di cellule, 41,000 geni, 81 cluster", "n_cells 3,399,892; n_genes_raw 41,321; n_clusters 81", SD, "")
f("A0206", "PASS", "info", "denominatore t-test CPU 5,598 s", "5,597.79 s", SD, "L'estrapolazione Wilcoxon CPU oltre 4 ore non ha JSON (UNVERIFIABLE per quella parte).")
f("A0207", "PASS", "info", "Didascalia Tabella 7: 3.4M x 41k x 81; riferimento 5,598 s", "3,399,892 x 41,321 x 81; 5,597.79 s", SD, "")
f("A0208", "PASS", "info", "Intestazione Tabella 7", NA, "n.a.", "")
f("A0209", "PASS", "info", "t-test CPU 5,598 s, 1.0x", "5,597.79", SD, "")
f("A0210", "MISMATCH", "minor", "pseudo-bulk 128 s, 43.7x", "127.47 s -> 127; 5,597.79/127.47 = 43.91x", SD, "43.7 deriva da 5,598/128 con 128 arrotondato male; l'abstract (44x) e corretto.")
f("A0211", "PASS", "info", "Wilcoxon scatter 8 GPU 826 s, 6.8x", "826.31 s; 6.77x", SD, "")
f("A0212", "PASS", "info", "Wilcoxon chunk 1 GPU 831 s, 6.7x", "830.58 s; 6.74x", SD, "")
f("A0213", "MISMATCH", "minor", "t-test scatter 8 GPU 1,656 s, 3.4x", "1,655.47 s -> 1,655 (ttest_scatter); rerun 'clean' 1,649.36; 3.38x", SD, "")
f("A0214", "MISMATCH", "minor", "t-test chunk 1 GPU 1,650 s, 3.4x", "1,649.46 s -> 1,649; 3.39x", SD, "")
f("A0215", "MISMATCH", "major", "'a few hundred pseudo-samples per cluster', 128 s (2.1 min), 43.7x, 5,598 s (93 min)",
  "n_pseudobulk_samples = 2,431 in totale su 81 cluster = 30.0 per cluster (202 donatori); 127.47 s = 2.12 min; 43.91x; 93.30 min", SD,
  "L'ordine di grandezza dei pseudo-campioni per cluster e sbagliato (decine, non centinaia).")
f("A0216", "MISMATCH", "minor", "Wilcoxon 826 s contro t-test 1,656 s; scatter 826 vs chunk 831", "826.31 contro 1,655.47 (1,655); 826.31 vs 830.58", SD, "")

# ---------------- discussion ----------------
f("A0270", "PASS", "info", "quasi 12 milioni di cellule su un nodo", "11,899,623 cellule dopo QC a 11.9M", SD, "Cellule replicate da 3,436,470 uniche (finding nuovo).")
f("A0274", "MISMATCH", "major", "normalizzazione 88-329x, neighbours 44-88x", "normalizzazione 173.07-329.29x; neighbours 44.31-88.14x", PS, "Il limite inferiore 88 della normalizzazione e copiato dai neighbours.")
f("A0276", "MISMATCH", "major", "data loading: domina l'overhead fisso di contesto CUDA e pool RMM; trasferimento in millisecondi",
  "Come A0133: RMM e warmup fuori dal timer; eccesso GPU +0.10 / +0.55 / +1.38 s crescente con la taglia", PS + "; scripts/benchmark_gpu.py righe 228-245", "")
f("A0277", "UNSUPPORTED", "major", "Leiden su grafi piccoli limitato da bassa intensita aritmetica, overhead costante di cuGraph",
  "A 10k lo svantaggio GPU esiste solo per la prima chiamata (res 0.5) e soprattutto in r1 (1.703 s); r2-r5 res 0.5 = 1.12x a favore GPU; res 1.0 e 1.5 a favore GPU (1.36x, 1.60x)", PS, "Effetto di prima chiamata (inizializzazione), non di roofline.")
f("A0280", "MISMATCH", "major", "miglioramento del 12% da 2 a 8 GPU dovuto alla struttura: solo PCA e neighbours distribuiti, il restante 95% sequenziale",
  "Il 12% sta per intero nella fase CPU (+60.17 s su 58.12 s di divario); PCA+neighbours non distribuiti e invariati (17.23 contro 17.01 s); quota non multi-GPU 96.2% (r1) o 96.1% (media), non 95%", MG, "")
na("A0281", "Frase con citazione (Amdahl); il presupposto quantitativo e contestato in A0280.")
f("A0283", "UNSUPPORTED", "major", "speedup marginale ~12%: meglio 8 worker indipendenti con throughput quasi lineare",
  "Throughput concorrente non misurato; i dati mostrano l'opposto: con job 1/2/4 GPU in parallelo sullo stesso nodo il data loading a 1.3M sale a 148.99 s (2 GPU) e 135.07 s (4 GPU) contro 90.61 s del job 8 GPU da solo", MG, "")
f("A0284", "UNSUPPORTED", "major", "DGX come cluster di otto workstation H100", "Nessuna misura di throughput con 8 job concorrenti", "n.a.", "Raccomandazione senza dati.")
f("A0286", "UNSUPPORTED", "major", "sotto 500k la pipeline sta su una GPU; la variante memory-optimised 'extends single-GPU feasibility to 1.3M cells and beyond'",
  "1 GPU misurata fino a 100k; la variante memory-optimised usa 8 GPU per la PCA (n_gpus 8 in tutti i JSON maxpower) e non e mai stata eseguita su una GPU", SD, "")
f("A0287", "UNSUPPORTED", "major", "120x a 1.3M con una H100 a noleggio: meno di un dollaro",
  "Il 120x e del job 8 GPU con 200 core CPU; 435.18 s = 0.121 h: USD 0.24-0.48 a 1 GPU, USD 1.93-3.87 a 8 GPU; nessun run 1-GPU a 1.3M", T4, "Il costo presuppone una configurazione non misurata.")
f("A0290", "PASS", "info", "HVG Jaccard 1.000; PCA rho 1.000", "1.0; 1.0", CC, "")
f("A0291", "PASS", "info", "ARI 0.908-0.963", "0.907733-0.963095", CC, "La spiegazione 'stochasticity' e contestata in A0147.")
f("A0296", "PASS", "info", "11.9M: VRAM piatta a 49 GB (7.6% di 640), RAM 535 GB", "48.54-48.84 GiB da 3.44M a 11.9M (pool RMM 2 GB); 7.63%; 534.55", SD, "")
f("A0297", "UNSUPPORTED", "major", "il fallimento a 12M 'occurred because transient memory spikes during individual preprocessing operations'",
  "Nessun dato del run a 12M; Results (riga 262) e Tabella 6 dichiarano l'attribuzione irrisolta; Tabella 5 la attribuisce a Leiden. 535/1800 = 29.7% (ok)", SD, "Causa affermata come fatto senza misura.")
f("A0300", "UNSUPPORTED", "major", "capacita funzione di celle x HVG: 20M a 1,000 HVG, 4M a 5,000 HVG",
  "Nella traccia a 11.9M la matrice densa HVG vale circa 82-89 GiB su 535; la copia sparsa completa circa 420 GiB. Dimezzare gli HVG riduce il costo per milione di cellule da circa 45 a circa 41 GiB (+9% di capacita), non lo raddoppia. Estrapolazione pura sul termine denso: 23.8M e 4.76M",
  SD, "Il termine dominante dipende dai geni totali, non dagli HVG.")
f("A0301", "MISMATCH", "minor", "chunked: VRAM ridotta di 5 volte (49 -> 10 GB) 'without improving the cell limit'",
  "48.84/9.60 = 5.09 (ok). Ma la variante chunked passa a 12.0M dove la standard fallisce; il limite fra 12.0M e 15.0M non e stato cercato", SD, "Lo short paper dice 'did not substantially increase' (12M vs 11.9M).")
f("A0303", "PASS", "info", "pseudo-bulk 44x rispetto al t-test", "43.91x", SD, "")
f("A0304", "UNSUPPORTED", "minor", "DE cellulare su GPU 3-7x, limitato dall'I/O della densificazione", "3.38-6.77x (ok); nessuna profilazione dell'I/O nei JSON", SD, "Numeri corretti, meccanismo non misurato.")
f("A0305", "MISMATCH", "minor", "Wilcoxon 826 contro t-test 1,656 s", "826.31 contro 1,655.47 (1,655)", SD, "Spiegazione su argsort CuPy non misurata.")
f("A0306", "UNVERIFIABLE", "minor", "a 3.4M quasi ogni gene e significativo", "p-value non salvati nei JSON DE", "results/de_benchmark_*.json", "")
na("A0307", "Affermazione con citazione (track citazioni).")
f("A0310", "PASS", "info", "co-occurrence 3,272x su HD 8 um", "3,573.201 / 1.0922 = 3,271.6x", SP, "Il 'largest ... reported' e un'affermazione di letteratura non verificata in questo track.")
f("A0311", "PASS", "info", "autocorrelazione 162-170x, rho >= 0.9995", "Moran/Geary: HD 8 um 162.3x/162.5x; HD 2 um 167.2x/169.7x; rho minimo 0.999526", SP, "Su Visium v1 lo speedup e 7.8x: il range vale solo per HD.")
f("A0314", "PASS", "info", "ARI HD 2 um = 0.080", "ARI per ripetizione 0.0843 (r1, r2, r4, r5), 0.0652 (r3); media r2-r5 = 0.0795", SP, "")
f("A0315", "PASS", "info", "389,492 bin, risoluzione 0.1", "n_common_spots 389,492; leiden_res = 0.1 sopra 100k spot", SP + "; SPATIAL/scripts/benchmark_spatial_cpu.py riga 327", "")
f("A0318", "MISMATCH", "major", "'single biological dataset (mouse brain E18)'", "Campione Census multi-studio (202 donatori nel set da 3.4M; geni dopo QC fino a 44,158)", "scripts/download_data.py; de_benchmark_pseudobulk.json n_donors", "Vedi A0024.")
f("A0319", "PASS", "info", "concordanza a 10,000 cellule", "unico file concordance_10000_r1.json", CC, "")
f("A0321", "PASS", "info", "HD 2 um completo = 6.3 milioni di bin", "n_spots_input 6,296,688", "SPATIAL/results/spatial_cpu_visium_hd_square_002um_r1_results.json", "")
f("A0322", "MISMATCH", "minor", "driver del cluster 535.183.01 (CUDA 12.2)", "535.183.01 solo nei run 8 GPU e maxpower; i run 1/2/4 GPU riportano 535.247.01", "metadata.gpu_info.driver_version", "Il cluster non ha un solo driver; il limite CUDA 12.2 non e verificabile dai JSON.")
f("A0324", "UNSUPPORTED", "minor", "tempo piatto 2->8 GPU indica collo di bottiglia in preprocessing CPU e operazioni single-GPU (Leiden, UMAP)",
  "A 1.3M Leiden*3 + UMAP = 8.0 s su 435 (1.8%); DE 70.45 s. La piattezza dipende dal fatto che nulla era distribuito (A0047)", MG, "")
f("A0326", "UNSUPPORTED", "major", "500k e 1.3M solo via ibrido Dask-CUDA perche il preprocessing non aveva una via GPU distribuita",
  "OOM 1-GPU non documentato; rapids-singlecell 0.14.1 supporta Dask array in QC, normalize, scale, HVG", "sorgente rapids_singlecell-0.14.1", "Vedi A0045.")
f("A0327", "MISMATCH", "minor", "frazione di preprocessing CPU del 75%", "75.2% nel solo r1; media r1-r5 78.0% (8 GPU), 81.0% (2 GPU), 79.9% (4 GPU)", MG, "")
f("A0328", "PASS", "info", "RAM campionata fra gli step e solo per il processo padre", "time_step: psutil.Process().memory_info().rss prima e dopo ogni step, dopo gc.collect()", "scripts/benchmark_maxpower.py time_step", "")
f("A0331", "PASS", "info", "14.5 ore -> 7.3 minuti a 1.3M", "14.46 h; 7.25 min", T4, "")
f("A0332", "PASS", "info", "11.9M con il 7.6% della memoria GPU", "48.84 / 640 = 7.63%", SD, "Dati replicati (finding nuovo).")
f("A0333", "MISMATCH", "critical", "'Multi-GPU scaling provides modest benefit (12% at 1.3M cells, 2 to 8 GPUs)'",
  "Il beneficio misurabile delle GPU aggiuntive e nullo (PCA+neighbours 17.23 -> 17.01 s); il 12% viene dal caricamento dati su nodi e allocazioni CPU diverse", MG, "Conclusione non sostenuta dai dati.")
f("A0334", "PASS", "info", "pseudo-bulk 44x contro t-test", "43.91x", SD, "")
f("A0335", "PASS", "info", "51.6x HD; 3,272x co-occurrence; concordanza > 0.9995", "51.64x; 3,271.6x; rho minimo 0.999526", SP, "")
na("A0336", "Frase con citazione.")
na("A0337", "Ringraziamenti: nessun numero.")
f("A0338", "MISMATCH", "major", "CUP B53C22006450001 (DARE, PNC0000002)",
  "Lo short paper camera-ready riporta B53C22006440001; due bandi UNIPD sul progetto DARE riportano 'CUP del progetto: B53C22006440001'",
  "WebFetch: dei.unipd.it/system/files/2023RUAPNRR_PNC_DARE_01_-_All._1_-_5271_e_5269_-_ING-INF_06_-_%282_posti%29.pdf; sdb.unipd.it/sites/sdb.unipd.it/files/2023RUAPNRR_PNC_DARE_01_-_All._4_-_5923_-_MED_38_0.pdf; manuscript_short_cameraready.md",
  "Codice CUP probabilmente errato nel full paper (un'unita in quinta posizione dalla fine).")
f("A0339", "PASS", "info", "URL del repository", "/tmp/repo e clone di github.com/lucavd/2026.scRNA_DGX", "BRIEF_COMUNE.md", "")

# ---------------- build ----------------
def locator(x):
    t = x.get("text")
    if not t:
        if x["kind"] == "table_row":
            t = " | ".join(x.get("cells", []))
        elif x["kind"] == "figure":
            t = x.get("caption", "")
        else:
            t = json.dumps(x)
    t = t.replace("&nbsp;", "").strip()
    return t[:200]

out = []
missing = []
for x in inv:
    i = x["id"]
    if i not in F:
        missing.append(i); continue
    r = F[i]
    out.append({"inv_id": i, "track": "A", "line": x["line"], "section": x.get("section", ""),
                "locator": locator(x), **{k: r[k] for k in ("claimed", "recomputed", "status", "severity", "source", "note")}})
assert not missing, missing
extra = set(F) - {x["id"] for x in inv}
assert not extra, extra

NEW = [
 dict(line=14, section="Abstract", locator="Multi-GPU scaling was sublinear due to CPU preprocessing dominance.",
      claimed="scaling multi-GPU sublineare per dominanza del preprocessing CPU", status="MISMATCH", severity="critical",
      recomputed="PCA e neighbours non distribuiti (CuPy su GPU 0, neighbours 'brute'); PCA+neighbours 17.23/16.99/17.01 s a 2/4/8 GPU; divario 2->8 GPU interamente nella fase CPU (+60.17 di 58.12 s)",
      source=MG + "; scripts/benchmark_multigpu.py; sorgente rapids_singlecell-0.14.1",
      note="L'esperimento multi-GPU non ha usato piu di una GPU per il calcolo: la frase dell'abstract (e la sezione Results relativa) va riformulata o l'esperimento rifatto con Dask array o algoritmi mg_*."),
 dict(line=88, section="Data and Methods > Multi-GPU pipeline", locator="In this hybrid pipeline, data loading, QC, normalisation, HVG selection and scaling executed on the host CPU.",
      claimed="scaling su CPU nella pipeline ibrida", status="MISMATCH", severity="major",
      recomputed="Nel codice e nei metadati lo scaling e rsc.pp.scale su GPU 0 (single_gpu_steps: gpu_transfer, scale, ...); la riga 90 dice infatti 'Scaling ... executed on a single GPU'",
      source="scripts/benchmark_multigpu.py righe 336-340; metadata.configuration di gpu{2,4,8}_*_results.json",
      note="Contraddizione interna introdotta con la modifica del 2 settembre."),
 dict(line=157, section="Data and Methods > Hardware", locator="Jobs were submitted via SLURM on a dedicated DGX H100 node (`poddgx02`).",
      claimed="configurazioni confrontabili sullo stesso nodo dedicato", status="MISMATCH", severity="major",
      recomputed="gpu_1.sh 16 core/256G, gpu_2.sh 32 core/512G, gpu_4.sh 56 core/1024G, gpu_8.sh 200 core/1800G; 1/2/4 GPU sullo stesso nodo (driver 535.247.01) in parallelo, 8 GPU su altro nodo (535.183.01). CPU 100 core su nodo non registrato (12-15 marzo)",
      source="slurm/gpu_*.sh, slurm/cpu_benchmark.sh; metadata.timestamp e gpu_info.driver_version",
      note="Allocazioni CPU e contesa I/O diverse per configurazione: confondono sia lo scaling multi-GPU sia i confronti di preprocessing."),
 dict(line=260, section="Results > Stress test", locator="A binary search for the maximum processable cell count (Table 5) showed that the pipeline succeeded at 11.9 million cells (119 min)",
      claimed="stress test su 3.4M-11.9M cellule", status="UNSUPPORTED", severity="major",
      recomputed="Tutte le taglie oltre 3,436,470 sono copie replicate del file sorgente (resize_dataset: n copie intere + resto campionato); a 11.9M Leiden produce 135,710/142,959/147,154 cluster (3.4M: 58/66/87); la replica (+302 GiB) avviene fuori dai timer",
      source=SD + "; scripts/benchmark_maxpower.py resize_dataset (righe 468-524, 580-582)",
      note="Replica non dichiarata nel manoscritto; il 'Pass' e solo computazionale (output di clustering degenere); i tempi escludono la costruzione del dataset."),
 dict(line=240, section="Results > Concordance", locator="Concordance analysis on the 10,000-cell dataset (Fig. 5) demonstrated that the two pipelines yield near-identical biological conclusions",
      claimed="concordanza sul benchmark a 10k", status="MISMATCH", severity="major",
      recomputed="concordance_10000_r1.json ha cpu_timestamp 2026-03-11T23:14 e gpu_timestamp 2026-03-11T23:15, mentre i run riportati in Tabella 4 sono del 12 (CPU) e 15 marzo (GPU); cluster CPU 31/40/45 nel file di concordanza contro 31/41/46 in tutte e 5 le ripetizioni del benchmark",
      source=CC, note="La concordanza e calcolata su un run precedente, non sulle ripetizioni pubblicate; va rifatta sui run del benchmark o dichiarata."),
 dict(line=240, section="Results > Concordance", locator="Neighbourhood graph construction achieved high overlap with mean Jaccard = 0.930 (median = 0.938), though some variation in the k-nearest neighbours across the graph was expected due to floating-point",
      claimed="kNN Jaccard 0.930 per differenze di floating point", status="UNSUPPORTED", severity="major",
      recomputed="max_jaccard = median_jaccard = 0.9375 = 15/16 e fraction_perfect = 0.0: nessuna cella raggiunge 1.0, la meta delle celle e esattamente al tetto. Indica un disallineamento strutturale delle dimensioni degli insiemi di vicini CPU/GPU (es. self incluso in uno solo), non rumore numerico",
      source=CC + "; scripts/compare_results.py compare_knn",
      note="La metrica va corretta (stessa definizione di vicinato) prima di interpretarla."),
 dict(line=165, section="Data and Methods > Hardware", locator="Each benchmark configuration was repeated five times; we report mean +/- standard deviation.",
      claimed="media +/- SD su 5 ripetizioni (scRNA); spatial su r2-r5", status="MISMATCH", severity="minor",
      recomputed="La ripetizione 1 scRNA e un cold start: CPU 10k r1 57.70 s contro 34.51-35.16; SD CPU 10k 10.19 (r1-r5) contro 0.30 (r2-r5); normalizzazione 329x -> 115x; Leiden 10k 0.36x -> 1.12x; speedup 10k 12.0x -> 14.0x",
      source=T4 + "; " + PS, note="Convenzione incoerente fra scRNA (r1 inclusa) e spatial (r1 esclusa come warm-up); le SD riflettono il cold start, non la variabilita fra ripetizioni."),
 dict(line=231, section="Results > Multi-GPU scaling", locator="in a representative 8-GPU run at 1.3M cells (total 463.4 s)",
      claimed="run rappresentativo", status="MISMATCH", severity="minor",
      recomputed="Il run e gpu8_1300000_r1, il piu lento dei cinque (463.43 contro 422.67-432.43 s); media r1-r5: CPU 78.0%, multi-GPU 3.9%, single-GPU 18.1%",
      source=MG, note="Usare la media o dichiarare la ripetizione."),
 dict(line=252, section="Results > Memory", locator="Second, we verified through direct scheduler queries (`client.run_on_scheduler()`) that all requested workers were in the `running` state throughout each benchmark",
      claimed="verifica dei worker durante ogni benchmark", status="UNSUPPORTED", severity="major",
      recomputed="Nessuno dei 75 JSON gpu2/4/8 (15 marzo) contiene actual_n_workers; la versione dello script a 076a752 usa client.scheduler_info(); run_on_scheduler entra il 20 marzo (commit 07031f4), dopo i run",
      source="git log/git show di scripts/benchmark_multigpu.py; metadata.configuration.dask_cluster", note="La verifica dichiarata non e documentata per i run pubblicati; in ogni caso i worker non ricevevano lavoro (A0047)."),
 dict(line=422, section="Discussion", locator="the dominant source of variation is the Leiden algorithm's non-deterministic vertex ordering",
      claimed="variazione dominata dal non determinismo di Leiden", status="UNSUPPORTED", severity="minor",
      recomputed="CPU: etichette identiche nelle 5 ripetizioni a tutte le taglie. GPU: identiche a 10k; variano da 50k in su (es. 1-GPU 100k r=1.0: 56-60 cluster). A 1.3M CPU 59/75/89 cluster contro GPU 8 50-55/67-70/79-84",
      source=W + "a08_determinism.py: results_summary.cluster_labels_hash_* e n_clusters_* per ripetizione",
      note="A 10k, dove si misura la concordanza, nessuna delle due pipeline mostra variabilita fra ripetizioni; il non determinismo GPU compare solo a taglie maggiori, non coperte dalla concordanza."),
 dict(line=267, section="Results > Stress test", locator="This variant succeeded at 12.0 million cells (862 GB peak RAM, 10 GB aggregate VRAM, 156 min)",
      claimed="la variante chunked evita intermedi densi su CPU", status="PASS", severity="info",
      recomputed="Pero il suo picco RAM registrato (861.70 GiB) supera quello della pipeline standard a 11.9M (534.55): RSS da 430.46 a 857.75 GiB fra normalizzazione e HVG chunked, fuori dai timer",
      source=SD, note="Osservazione: a 12M la chunked riesce con un RSS registrato molto piu alto di quello che la Tabella 6 usa per spiegare il fallimento della standard."),
 dict(line=262, section="Results > Stress test", locator="What the data do exclude is clustering as the CPU-side culprit",
      claimed="coerenza con lo short paper", status="MISMATCH", severity="minor",
      recomputed="Short paper 3.4: picchi transitori 'during sparse-to-dense conversion and Leiden graph construction'; short paper Fig. 1: Leiden 8.8x a 100k; full paper: Leiden escluso, 3.58x a 100k; CUP diversi",
      source="manuscript_short_cameraready.md sezioni 3.1, 3.4, Funding",
      note="Differenze rispetto al camera-ready non spiegate nel full paper (attribuzione dell'OOM, risoluzione Leiden citata, CUP)."),
 dict(line=111, section="Data and Methods > Stress test", locator="CPU memory was recorded as the resident set size of the parent Python process (`psutil.Process().memory_info().rss`)",
      claimed="valori di memoria in GB", status="MISMATCH", severity="minor",
      recomputed="Tutte le misure sono rss/1024**3 e NVML used/1024**3, cioe GiB; le stime di Tabella 6 (96 GB) e la riga 250 (10.4 GB) sono GB decimali",
      source="scripts/benchmark_*.py get_peak_ram_gb / get_vram_used_gb", note="Unita miste da uniformare (535 GiB = 574 GB)."),
]
for n in NEW:
    out.append({"inv_id": None, "track": "A", **{k: n[k] for k in ("line", "section", "locator", "claimed", "recomputed", "status", "severity", "source", "note")}})

for o in out:
    for k, v in o.items():
        if isinstance(v, str) and ("–" in v or "—" in v):
            raise SystemExit(f"dash in {o['inv_id']} {k}")
    o["locator"] = o["locator"][:200]
json.dump(out, open(f"{BASE}/tracks/A_findings.json", "w"), indent=1, ensure_ascii=False)
from collections import Counter
print(len(out), Counter(o["status"] for o in out), Counter((o["status"], o["severity"]) for o in out if o["status"] in ("MISMATCH", "UNSUPPORTED")))
