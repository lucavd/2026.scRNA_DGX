"""Track A: concordanza (righe 240-242, 422, Fig. 5) da concordance_10000_r1.json,
e confronto dei numeri di cluster con i JSON di benchmark a 10k (5 ripetizioni)."""
import json, glob, statistics as st
R = "/tmp/repo/results"
d = json.load(open(f"{R}/concordance_10000_r1.json"))
print("metadata", d["metadata"])
for r, v in d["cluster_concordance"].items():
    print(r, v)
print("hvg", d["hvg_concordance"])
print("pca mean_abs", d["pca_concordance"]["mean_abs_spearman_rho"], "n_genes", d["pca_concordance"]["n_genes_compared"],
      "per-PC rho (signed):", [d["pca_concordance"]["per_pc"][f"PC{i}"]["spearman_rho"] for i in range(1, 11)])
print("knn", d["knn_concordance"])
de = d["de_concordance"]; pp = de["per_pair"]
rhos = [v["spearman_rho"] for v in pp.values()]
print("DE mean (stored)", de["mean_spearman_rho"], "n_pairs", de["n_pairs_compared"], "recomputed mean", round(st.mean(rhos), 6), "n", len(rhos))
print("pairs > 0.97:", sum(r > 0.97 for r in rhos), " >=0.97:", sum(r >= 0.97 for r in rhos), " median", st.median(rhos))
print("min rho", min(rhos), [ (k, v) for k, v in pp.items() if v["spearman_rho"] < 0.9])
print("mean excl. pairs with overlap 0:", st.mean(v["spearman_rho"] for v in pp.values() if v["overlap_fraction"] > 0))
print("overlap fractions < 0.8:", {k: v["overlap_fraction"] for k, v in pp.items() if v["overlap_fraction"] < 0.8})
ari = [v["ari"] for v in d["cluster_concordance"].values()]; nmi = [v["nmi"] for v in d["cluster_concordance"].values()]
print("ARI range", min(ari), max(ari), "NMI range", min(nmi), max(nmi))
print("\nbenchmark JSON cluster counts at 10k (r1..r5):")
for p in ("cpu", "gpu"):
    for f in sorted(glob.glob(f"{R}/{p}_10000_r*_results.json")):
        x = json.load(open(f)); rs = x["results_summary"]
        print(" ", f.split('/')[-1], x["metadata"]["timestamp"][:19], [rs[f"n_clusters_{r}"] for r in ("0.5","1.0","1.5")],
              rs["hvg_list_hash"], [rs[f"cluster_labels_hash_{r}"] for r in ("0.5","1.0","1.5")])
