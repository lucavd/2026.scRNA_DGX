"""Track A: ricalcolo Tabella 4 dai JSON grezzi in /tmp/repo/results.
Convenzioni testate: media su r1..r5; SD campionaria (ddof=1) e di popolazione (ddof=0);
peak RAM / VRAM come media, mediana e massimo dei peak_*_gb per ripetizione."""
import json, glob, statistics as st, sys
R = "/tmp/repo/results"
cfgs = [("cpu", n) for n in (10000, 50000, 100000, 500000, 1300000)]
cfgs += [("gpu", n) for n in (10000, 50000, 100000)]
cfgs += [(f"gpu{g}", n) for g in (2, 4, 8) for n in (10000, 50000, 100000, 500000, 1300000)]
out = {}
def load(p, n):
    fs = sorted(glob.glob(f"{R}/{p}_{n}_r*_results.json"))
    return [json.load(open(f)) for f in fs], fs
for p, n in cfgs:
    ds, fs = load(p, n)
    tot = [d["timings"]["total"] for d in ds]
    ram = [d["memory"]["peak_ram_gb"] for d in ds]
    vram = [d["memory"]["peak_vram_gb"] for d in ds]
    sumsteps = [round(sum(v for k, v in d["timings"].items() if k != "total"), 4) for d in ds]
    rec = dict(n_files=len(ds), reps=[d["metadata"]["repeat_id"] for d in ds], totals=tot,
               mean=st.mean(tot), sd1=st.stdev(tot), sd0=st.pstdev(tot),
               ram_mean=st.mean(ram), ram_max=max(ram), ram_med=st.median(ram), rams=ram,
               vram_mean=st.mean(vram), vram_max=max(vram), vram_med=st.median(vram), vrams=vram,
               total_eq_sum=all(abs(a - b) < 1e-3 for a, b in zip(tot, sumsteps)),
               mean_r2_5=st.mean(tot[1:]), sd1_r2_5=st.stdev(tot[1:]))
    out[f"{p}_{n}"] = rec
    print(f"{p:5s} {n:>8d} n={len(ds)} mean={rec['mean']:10.2f} sd1={rec['sd1']:7.2f} sd0={rec['sd0']:7.2f} "
          f"| r2-5 mean={rec['mean_r2_5']:9.2f} sd1={rec['sd1_r2_5']:6.2f} | RAM mean={rec['ram_mean']:7.2f} max={rec['ram_max']:7.2f} "
          f"| VRAM mean={rec['vram_mean']:7.2f} max={rec['vram_max']:7.2f} | sum==total {rec['total_eq_sum']}")
    print("      totals", tot, " rams", ram, " vrams", vram)
json.dump(out, open(sys.argv[1] if len(sys.argv) > 1 else "/dev/null", "w"), indent=1)
