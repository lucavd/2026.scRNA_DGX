"""Track A: solo i numeri spatial presenti nelle righe della fetta A (abstract, discussione, conclusioni).
Convenzione dichiarata nel testo: media delle ripetizioni 2-5 (r1 = warm-up). Speedup = media CPU / media GPU."""
import json, glob, statistics as st
R = "/tmp/repo/SPATIAL/results"
plats = {"visium": "Visium v1", "visium_hd_square_008um": "HD 8 um", "visium_hd_square_002um": "HD 2 um"}
def load(pipe, p, reps):
    return [json.load(open(f"{R}/spatial_{pipe}_{p}_r{r}_results.json")) for r in reps]
for p, lab in plats.items():
    c, g = load("cpu", p, range(2, 6)), load("gpu", p, range(2, 6))
    ct = st.mean(d["timings"]["total"] for d in c); gt = st.mean(d["timings"]["total"] for d in g)
    out = [f"{lab}: total cpu={ct:.2f} gpu={gt:.2f} speedup={ct/gt:.2f}"]
    for s in ("co_occurrence", "spatial_autocorr_moran", "spatial_autocorr_geary"):
        cm = st.mean(d["timings"][s] for d in c); gm = st.mean(d["timings"][s] for d in g)
        out.append(f"{s}: {cm:.3f}/{gm:.4f}=" + (f"{cm/gm:.1f}" if gm > 0 else "NA"))
    print(" | ".join(out))
    conc = json.load(open(f"{R}/spatial_concordance_{p}.json"))
    for e in conc:
        print("   r", e["repeat_id"], "moran rho", e["moranI"]["I_spearman_rho"], "geary rho", e["gearyC"]["C_spearman_rho"],
              "ARI", e["clusters"]["ari"], "NMI", e["clusters"]["nmi"], "ncl", e["clusters"]["n_clusters_cpu"], e["clusters"]["n_clusters_gpu"],
              "spots", e["clusters"]["n_common_spots"])
    print("   n_spots_after_qc gpu r2:", g[0]["results_summary"].get("n_spots_after_qc"))
