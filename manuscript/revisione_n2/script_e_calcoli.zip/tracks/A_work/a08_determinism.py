"""Track A: riproducibilita degli output fra ripetizioni (results_summary: hash HVG, numero cluster)."""
import json, glob, collections
g = collections.defaultdict(list)
for f in sorted(glob.glob("/tmp/repo/results/*_r*_results.json")):
    rs = json.load(open(f))["results_summary"]
    g[f.split("/")[-1].split("_r")[0]].append((rs["n_cells_after_qc"], rs["n_genes_after_qc"], rs["hvg_list_hash"],
        tuple(rs[f"n_clusters_{r}"] for r in ("0.5", "1.0", "1.5")), tuple(rs[f"cluster_labels_hash_{r}"] for r in ("0.5", "1.0", "1.5"))))
for k, v in sorted(g.items(), key=lambda x: (int(x[0].split("_")[1]), x[0])):
    print(f"{k:14s} esiti distinti={len(set(v))} celle_qc={sorted({x[0] for x in v})} geni_qc={sorted({x[1] for x in v})} hvg_hash={sorted({x[2] for x in v})} ncluster={sorted({x[3] for x in v})}")
