"""F track: check of the Discussion claim (line 424) that capacity scales as cells x HVGs
('20M cells at 1,000 HVGs and 4M cells at 5,000 HVGs').
Data: /tmp/repo/results/maxpower_11900000_8gpu_results.json (peak_ram_gb) and the 12M failure point.
Two models (declared):
 M1 (the manuscript's implicit model): capacity proportional to 1/HVGs  -> n(h) = 11.9M * 2000 / h
 M2 (budget model consistent with Table 6): resting memory = n * (c + 4*h bytes); c = per-cell non-HVG bytes
     estimated from the 11.9M sample: c = (peak - n*2000*4)/n ; capacity at h keeps the same total.
Output: f04_capacity_hvg.csv
"""
import json, os
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open("/tmp/repo/results/maxpower_11900000_8gpu_results.json"))
peak = d["memory"]["peak_ram_gb"] * 1e9
n0, h0 = 11.9e6, 2000
dense0 = n0 * h0 * 4
c = (peak - dense0) / n0
rows = []
for h in (1000, 2000, 5000):
    m1 = n0 * h0 / h
    m2 = peak / (c + 4 * h)
    rows.append(dict(hvgs=h, M1_inverse_HVG_cells=m1, M2_budget_cells=m2))
R = pd.DataFrame(rows)
print(f"peak RAM at 11.9M = {peak/1e9:.2f} GB; dense HVG matrix = {dense0/1e9:.1f} GB ({dense0/peak:.1%} of peak); per-cell non-HVG bytes c = {c:.0f}")
print(R.round(0).to_string(index=False))
R.to_csv(os.path.join(HERE, "f04_capacity_hvg.csv"), index=False)
