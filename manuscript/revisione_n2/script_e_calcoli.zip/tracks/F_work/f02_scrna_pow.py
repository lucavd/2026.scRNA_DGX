"""F track, executed PoWs on the scRNA JSONs (read-only, /tmp/repo/results).

PoW-1 Amdahl: fit T(N) = a + b/N on the 15 runs (2/4/8 GPUs x 5 repeats) per dataset size,
      for the total and per step; parallel fraction p = (b/2)/(a+b/2) relative to the 2-GPU time.
      Also per-step 2->8 GPU differences, to locate where the 12% at 1.3M comes from.
PoW-2 Repeat 1: rep-1 vs mean(rep 2-5) per config; Table 4 means/SD and speedups with all 5 reps
      (paper convention, scRNA) vs reps 2-5 (paper convention, spatial).
PoW-3 Speedup vs N, with and without the DE step; DE share of CPU wall time.
PoW-4 Per-step single-GPU speedups at 10k/50k/100k (all reps and reps 2-5), incl. Leiden by resolution.
PoW-5 Determinism and concordance proxies at all N from stored hashes and cluster counts:
      unique cluster-label hashes over the 5 repeats (same seed), HVG hash CPU vs GPU, n_clusters CPU vs GPU.
PoW-6 Node / concurrency / CPU-allocation provenance: driver per config, overlapping timestamps.
PoW-7 Wall-clock per repeat from consecutive timestamps (upper bound incl. untimed steps and result saving).
Conventions: mean over the stated repeats; SD = sample SD (ddof=1); speedup = mean(CPU)/mean(GPU).
Outputs: f02_*.csv tables in this folder.
"""
import json, glob, os, re
import numpy as np
import pandas as pd

RES = "/tmp/repo/results"
HERE = os.path.dirname(os.path.abspath(__file__))
pat = re.compile(r"^(cpu|gpu|gpu2|gpu4|gpu8)_(\d+)_r(\d+)_results\.json$")
recs, steps = [], []
for f in sorted(glob.glob(os.path.join(RES, "*_results.json"))):
    m = pat.match(os.path.basename(f))
    if not m:
        continue
    kind, n, r = m.group(1), int(m.group(2)), int(m.group(3))
    ng = {"cpu": 0, "gpu": 1, "gpu2": 2, "gpu4": 4, "gpu8": 8}[kind]
    d = json.load(open(f)); md = d["metadata"]; rs = d["results_summary"]
    recs.append(dict(n=n, ngpu=ng, rep=r, ts=pd.Timestamp(md["timestamp"]),
                     driver=md.get("gpu_info", {}).get("driver_version"), n_cpus=md.get("n_cpus"),
                     total=d["timings"]["total"], hvg_hash=rs.get("hvg_list_hash"),
                     **{f"ncl_{k}": rs.get(f"n_clusters_{k}") for k in ("0.5", "1.0", "1.5")},
                     **{f"hash_{k}": rs.get(f"cluster_labels_hash_{k}") for k in ("0.5", "1.0", "1.5")}))
    for s, t in d["timings"].items():
        steps.append(dict(n=n, ngpu=ng, rep=r, step=s, sec=t))
R = pd.DataFrame(recs); S = pd.DataFrame(steps)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)

# ---------------- PoW-2 repeat 1 and conventions ----------------
def agg(df, reps):
    x = df[df.rep.isin(reps)].groupby(["ngpu", "n"]).total
    return x.mean(), x.std(ddof=1)
m15, s15 = agg(R, [1, 2, 3, 4, 5]); m25, s25 = agg(R, [2, 3, 4, 5])
r1 = R[R.rep == 1].set_index(["ngpu", "n"]).total
T4 = pd.DataFrame({"mean_r1_5": m15, "sd_r1_5": s15, "mean_r2_5": m25, "sd_r2_5": s25, "rep1": r1})
T4["rep1_over_mean_r2_5"] = T4.rep1 / T4.mean_r2_5
cpu15 = T4.loc[0, "mean_r1_5"]; cpu25 = T4.loc[0, "mean_r2_5"]
T4["speedup_r1_5"] = [cpu15[n] / v if g > 0 else np.nan for (g, n), v in T4.mean_r1_5.items()]
T4["speedup_r2_5"] = [cpu25[n] / v if g > 0 else np.nan for (g, n), v in T4.mean_r2_5.items()]
T4 = T4.round(3); T4.to_csv(os.path.join(HERE, "f02_table4_conventions.csv"))
print("PoW-2 Table 4 under two conventions\n", T4.to_string())

# ---------------- PoW-3 speedup with/without DE ----------------
P = S[S.step != "total"].pivot_table(index=["ngpu", "n", "rep"], columns="step", values="sec")
P["total_noDE"] = P.drop(columns=["de_testing"]).sum(axis=1)
P["total"] = P.drop(columns=["total_noDE"]).sum(axis=1)
G = P.groupby(["ngpu", "n"])[["total", "total_noDE", "de_testing"]].mean()
rows = []
for (g, n), v in G.iterrows():
    if g == 0:
        continue
    c = G.loc[(0, n)]
    rows.append(dict(ngpu=g, n=n, cpu_total=c.total, gpu_total=v.total, speedup_total=c.total / v.total,
                     cpu_noDE=c.total_noDE, gpu_noDE=v.total_noDE, speedup_noDE=c.total_noDE / v.total_noDE,
                     DE_share_cpu=c.de_testing / c.total, DE_share_gpu=v.de_testing / v.total,
                     speedup_DE_only=c.de_testing / v.de_testing))
T3 = pd.DataFrame(rows).round(3); T3.to_csv(os.path.join(HERE, "f02_speedup_with_without_DE.csv"), index=False)
print("\nPoW-3 speedup with/without DE (means over 5 reps)\n", T3.to_string())

# ---------------- PoW-1 Amdahl ----------------
amd = []
for n in [10000, 50000, 100000, 500000, 1300000]:
    for step in ["total", "data_loading", "qc_filtering", "pca", "neighbors", "de_testing", "pca+neighbors", "total_minus_loading"]:
        sub = S[(S.n == n) & (S.ngpu.isin([2, 4, 8]))]
        if step == "pca+neighbors":
            y = sub[sub.step.isin(["pca", "neighbors"])].groupby(["ngpu", "rep"]).sec.sum()
        elif step == "total_minus_loading":
            tot = sub[sub.step == "total"].set_index(["ngpu", "rep"]).sec
            ld = sub[sub.step == "data_loading"].set_index(["ngpu", "rep"]).sec
            y = tot - ld
        else:
            y = sub[sub.step == step].set_index(["ngpu", "rep"]).sec
        y = y.reset_index(); y.columns = ["ngpu", "rep", "sec"]
        X = np.column_stack([np.ones(len(y)), 1.0 / y.ngpu.values])
        coef, res, *_ = np.linalg.lstsq(X, y.sec.values, rcond=None)
        resid = y.sec.values - X @ coef; dof = len(y) - 2
        s2 = (resid ** 2).sum() / dof; cov = s2 * np.linalg.inv(X.T @ X)
        a, b = coef; se_b = np.sqrt(cov[1, 1])
        means = y.groupby("ngpu").sec.mean()
        p = (b / 2) / (a + b / 2) if (a + b / 2) != 0 else np.nan
        amd.append(dict(n=n, step=step, mean2=means[2], mean4=means[4], mean8=means[8],
                        diff_2_4=means[2] - means[4], diff_4_8=means[4] - means[8],
                        amdahl_a_serial=a, amdahl_b_parallel=b, se_b=se_b,
                        b_ci95_lo=b - 2.16 * se_b, b_ci95_hi=b + 2.16 * se_b,  # t(13)=2.16
                        parallel_fraction_at2=p, max_speedup_inf_vs_2=(a + b / 2) / a if a > 0 else np.nan))
A = pd.DataFrame(amd).round(4); A.to_csv(os.path.join(HERE, "f02_amdahl.csv"), index=False)
print("\nPoW-1 Amdahl fits (T = a + b/N on 2/4/8 GPUs, 5 reps each)\n", A.to_string())

# per-step 2 vs 8 at 1.3M and 500k
for n in [500000, 1300000]:
    x = S[(S.n == n) & (S.ngpu.isin([2, 8]))].pivot_table(index="step", columns="ngpu", values="sec", aggfunc="mean")
    x["diff_2_minus_8"] = x[2] - x[8]
    print(f"\nPer-step mean 2 vs 8 GPUs at {n}\n", x.round(2).sort_values("diff_2_minus_8", ascending=False).to_string())
    x.round(3).to_csv(os.path.join(HERE, f"f02_steps_2v8_{n}.csv"))

# ---------------- PoW-4 per-step single-GPU speedups ----------------
ps = []
for reps, lab in [([1, 2, 3, 4, 5], "r1_5"), ([2, 3, 4, 5], "r2_5")]:
    sub = S[S.rep.isin(reps) & S.ngpu.isin([0, 1]) & S.n.isin([10000, 50000, 100000])]
    mm = sub.pivot_table(index=["n", "step"], columns="ngpu", values="sec", aggfunc="mean")
    mm["speedup"] = mm[0] / mm[1]; mm["conv"] = lab
    ps.append(mm.reset_index())
PS = pd.concat(ps); PS.to_csv(os.path.join(HERE, "f02_perstep_speedup_1gpu.csv"), index=False)
print("\nPoW-4 per-step speedup single GPU\n",
      PS.pivot_table(index="step", columns=["conv", "n"], values="speedup").round(2).to_string())
# leiden total of three resolutions
for reps, lab in [([1, 2, 3, 4, 5], "r1_5"), ([2, 3, 4, 5], "r2_5")]:
    sub = S[S.rep.isin(reps) & S.ngpu.isin([0, 1]) & S.step.str.startswith("leiden")]
    lt = sub.groupby(["n", "ngpu", "rep"]).sec.sum().groupby(["n", "ngpu"]).mean().unstack()
    print(f"Leiden (sum of 3 resolutions) {lab}: speedup", (lt[0] / lt[1]).round(2).to_dict(), "CPU", lt[0].round(3).to_dict(), "GPU", lt[1].round(3).to_dict())

# ---------------- PoW-5 determinism and concordance proxies ----------------
det = []
for (g, n), x in R.groupby(["ngpu", "n"]):
    det.append(dict(ngpu=g, n=n, uniq_hash_0_5=x["hash_0.5"].nunique(), uniq_hash_1_0=x["hash_1.0"].nunique(),
                    uniq_hash_1_5=x["hash_1.5"].nunique(), uniq_hvg_hash=x.hvg_hash.nunique(),
                    ncl_0_5=sorted(set(x["ncl_0.5"])), ncl_1_0=sorted(set(x["ncl_1.0"])), ncl_1_5=sorted(set(x["ncl_1.5"])),
                    hvg_hash=sorted(set(x.hvg_hash))))
D = pd.DataFrame(det); D.to_csv(os.path.join(HERE, "f02_determinism.csv"), index=False)
print("\nPoW-5 determinism (unique cluster-label hashes over 5 repeats, same seed) and cluster counts\n", D.to_string())

# ---------------- PoW-6 provenance ----------------
prov = R.groupby(["ngpu"]).agg(driver=("driver", lambda s: sorted(set(map(str, s)))), n_cpus=("n_cpus", lambda s: sorted(set(s))),
                               first=("ts", "min"), last=("ts", "max"))
print("\nPoW-6 provenance\n", prov.to_string())
prov.to_csv(os.path.join(HERE, "f02_provenance.csv"))

# ---------------- PoW-7 inter-timestamp wall clock ----------------
w = []
for (g, n), x in R.sort_values("ts").groupby(["ngpu", "n"]):
    x = x.sort_values("rep")
    gaps = x.ts.diff().dt.total_seconds().values[1:]
    tots = x.total.values[1:]
    w.append(dict(ngpu=g, n=n, mean_gap_r2_5=gaps.mean(), mean_total_r2_5=tots.mean(), untimed_mean=(gaps - tots).mean(),
                  untimed_share=((gaps - tots) / gaps).mean()))
W = pd.DataFrame(w).round(2); W.to_csv(os.path.join(HERE, "f02_walltime_gaps.csv"), index=False)
print("\nPoW-7 inter-timestamp gaps (upper bound on per-repeat wall clock incl. untimed code and saving)\n", W.to_string())
