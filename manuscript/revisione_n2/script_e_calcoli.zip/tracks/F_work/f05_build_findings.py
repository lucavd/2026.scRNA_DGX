"""Builds tracks/F_findings.json from inv_F.json plus the verdicts of the F track.
Verdicts are written by hand from the analyses in f00-f04 (numbers quoted are those printed by those scripts)."""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
TR = os.path.dirname(HERE)
inv = json.load(open(os.path.join(TR, "inv_F.json")))
W = "tracks/F_work/"

def V(status, severity, claimed, recomputed, source, note):
    return dict(status=status, severity=severity, claimed=claimed, recomputed=recomputed, source=source, note=note)

meta_note = "Riga di metadati (titolo/autori/affiliazioni/bibliografia): nessuna affermazione dei Risultati da ricondurre; fuori perimetro del track F."
v = {}
v["A0001"] = V("MISMATCH", "major", "Titolo: single-cell e spatial 'on NVIDIA DGX H100'",
    "Lo spatial e' stato eseguito su RTX 4090 locale (Results l330 Table 8 'RTX 4090'; tutti i SPATIAL/results/spatial_gpu_*_results.json: gpu_name 'NVIDIA GeForce RTX 4090'). Il DGX riguarda solo lo scRNA.",
    "SPATIAL/results/spatial_gpu_*_results.json metadata.gpu_info.gpu_name; manoscritto l159, l330",
    "Il titolo attribuisce al DGX H100 anche lo spatial. 'Systematic' poggia su un solo dataset per la scala 10k-1.3M.")
for k in ["A0002", "A0003", "A0004", "A0005", "A0006"]:
    v[k] = V("UNVERIFIABLE", "info", "metadati", "n/a", "n/a", meta_note)
v["A0007"] = V("UNSUPPORTED", "major", "Scanpy (CPU, 100 cores) vs rapids-singlecell (1-8 H100), five independent repeats",
    "CPU: SLURM --cpus-per-task=100 (slurm/cpu_benchmark.sh) su nodo con 224 CPU logiche (metadata.n_cpus=224 nei run GPU; l154: 112 core fisici) -> probabilmente 100 CPU logiche, non 100 core. 1 GPU solo fino a 100k (Table 4 l187). 2/4/8 GPU: PCA e neighbours eseguiti tutti su GPU 0 (adata.X mai convertito in Dask array, scripts/benchmark_multigpu.py; rsc 0.14.1 _pca.py usa Dask solo se X e' DaskArray). Ripetizioni sequenziali nello stesso processo Python: rep1 GPU 10k = 6.40 s vs media rep2-5 2.50 s.",
    W + "f02_scrna_pow.py (PoW-1, PoW-2, PoW-6); slurm/*.sh; github scverse/rapids_singlecell v0.14.1 preprocessing/_pca.py",
    "Il disegno dichiarato nell'abstract e' piu' forte di quello eseguito: '1-8 GPU' non corrisponde a calcolo distribuito, '100 cores' va dichiarato come CPU logiche, le ripetizioni non sono indipendenti (stesso processo, effetto rep1).")
v["A0008"] = V("UNSUPPORTED", "major", "up to 120-fold end-to-end speedup at 1.3M (435 s vs 52,056 s), 14.5 h -> 7.3 min",
    "Numeri ricalcolati: 52,056.21/435.18 = 119.62x; 14.46 h; 7.25 min (Results l183). Con 2 GPU 105.5x, con 4 GPU 107.0x. La differenza 2->8 GPU (58.1 s) sta tutta in data_loading (149.0 vs 90.6 s, lettura h5ad su CPU, nodo diverso). Il DE Wilcoxon e' il 93.5% del tempo CPU a 1.3M; senza DE lo speedup e' 7.9x (2 GPU) - 9.2x (8 GPU).",
    W + "f02_speedup_with_without_DE.csv; " + W + "f02_steps_2v8_1300000.csv",
    "I numeri tornano, l'attribuzione no: '120x' dipende dal nodo/I-O del job a 8 GPU e quasi interamente dal DE su CPU. Cifra robusta: ~105x con 2 GPU, ~8-9x escludendo il DE.")
v["A0009"] = V("UNSUPPORTED", "major", "HVG Jaccard 1.0, PCA |rho| 1.0, ARI 0.908-0.963",
    "results/concordance_10000_r1.json: ARI 0.9077 (r=1.0), 0.9317 (0.5), 0.9631 (1.5); HVG J=1.0; PCA mean |rho|=1.0 (Results l240-242). Solo a 10k e da un run del 2026-03-11 precedente al benchmark (CPU 40/45 cluster a r=1.0/1.5 contro 41/46 nei 5 run CPU del benchmark, deterministici; tempo GPU 16.9 s contro 3.3 s).",
    "results/concordance_10000_r1.json (metadata, cluster_concordance, speedups); " + W + "f02_determinism.csv",
    "Numeri corretti, ma 'Biological concordance was high' e' presentato come proprieta' del benchmark mentre e' misurato a 10k su un run diverso da quello cronometrato. In letteratura ARI CPU-GPU ~0.5 su 50k-1.2M (Gardner 2025) e 0.54 a 1.3M (Nolet 2022).")
v["A0010"] = V("UNSUPPORTED", "major", "11.9M cells on single DGX node; CPU RAM binding; VRAM 7.6%",
    "maxpower_11900000_8gpu_results.json: peak_ram 534.55 GB, peak_vram 48.84 GB -> 48.84/640 = 7.63% (Results l260-262, Table 5). Ma: i dati sopra 3.44M sono copie esatte del dataset CELLxGENE da 3,436,470 cellule (scripts/benchmark_maxpower.py, resize per replica), non 11.9M cellule distinte; la VRAM misura pool RMM riservati, non il fabbisogno; Results l262 dichiara non risolta l'attribuzione del fallimento a 12M.",
    "results/maxpower_11900000_8gpu_results.json memory; scripts/benchmark_maxpower.py righe 470-520",
    "Il vincolo 'CPU RAM' e' della pipeline scelta (preprocessing Scanpy su CPU), non dell'hardware; va dichiarato che le cellule oltre 3.4M sono duplicate.")
v["A0011"] = V("PASS", "minor", "pseudo-bulk 44x faster than cell-level t-test at 3.4M",
    "de_benchmark_ttest_cpu.json time 5597.79 s / de_benchmark_pseudobulk.json time 127.47 s = 43.91x (Table 7 riporta 43.7x usando 128 s arrotondato). Results l321.",
    "results/de_benchmark_ttest_cpu.json, results/de_benchmark_pseudobulk.json",
    "Confronto tra test e unita' statistiche diverse (2,431 pseudo-campioni vs 3.4M cellule): e' un tempo, non un fattore di accelerazione; 43.9 vs 43.7 per arrotondamento.")
v["A0012"] = V("UNSUPPORTED", "critical", "51.6x end-to-end (HD 8 um), 3,272x co-occurrence, rho >= 0.9995",
    "Con la convenzione rep2-5: totale 4068.40/78.79 = 51.6x; co-occurrence 3573.20/1.092 = 3271.5x (Table 8-9). Ma la rep1 esclusa come 'JIT warmup' e' quella in cui la CPU e' stata PIU' VELOCE: co-occurrence CPU r1 = 73.47 s contro 3570-3574 s in r2-5, con output identico bit a bit (.npy, max diff 0). Con tutte le ripetizioni: 41.5x e 2088x; rep1 da sola: 6.4x e 29.2x; CPU r1 vs GPU r2-5: 67x. Inoltre CPU calcola la co-occurrence su 7 cluster e GPU su 3 (carico diverso); concordanza della co-occurrence 'shape_mismatch'. rho >= 0.9995 confermato (Geary HD 8um 0.9995).",
    W + "f01_spatial_repeats.py -> f01_spatial_speedup_conventions.csv; SPATIAL/results/spatial_cpu_visium_hd_square_008um_r*_co_occurrence.npy; spatial_concordance_visium_hd_square_008um.json",
    "Le due cifre di testa dello spatial dipendono da una ripetizione esclusa con una giustificazione (warmup) che i dati contraddicono. Va spiegata la variabilita' 49x della CPU o riportato l'intervallo.")
v["A0270"] = V("UNSUPPORTED", "major", "consistent, large-magnitude speedups ... scalability to nearly 12 million cells",
    "Speedup end-to-end 8-46x (1 GPU 10k-100k), 19-25x (ibrida 50k-100k), 35x (500k), 105-120x (1.3M) (Table 4, l182-213); senza DE 3.7-10x. La scala a 11.9M usa un'altra pipeline e dati replicati (l256-281).",
    W + "f02_table4_conventions.csv; " + W + "f02_speedup_with_without_DE.csv",
    "'Consistent' non regge: lo speedup dipende dalla pipeline (1 GPU vs ibrida) e dal peso del DE; '12 million cells' sono copie di 3.4M.")
v["A0271"] = V("UNSUPPORTED", "major", "GPU advantages even more pronounced for spatial-specific operations",
    "Spatial-specifiche HD 8um (rep2-5): co-occurrence 3272x (dipende dall'esclusione rep1), Moran/Geary 162x, spatial neighbours 1.0x, nhood enrichment 1.0x (Table 9 l351-366). In scRNA normalisation 173-329x (l217).",
    W + "f01_spatial_speedup_conventions.csv; Table 9",
    "Solo la co-occurrence supera l'scRNA, ed e' la cifra fragile; due delle quattro operazioni spatial-specifiche non hanno GPU.")
v["A0272"] = V("PASS", "info", "frase di raccordo", "nessuna affermazione verificabile", "n/a", "Raccordo.")
v["A0273"] = V("PASS", "info", "GPU speedup operation-specific",
    "Speedup per step 1 GPU (5 rip.): da 0.36x (leiden_0.5 a 10k) a 329x (normalisation a 10k) (Results l217-223, Fig. 1).",
    W + "f02_perstep_speedup_1gpu.csv", "Sostenuto, con le riserve sullo 0.36x (vedi A0277).")
v["A0274"] = V("MISMATCH", "major", "Normalisation 88-329x, neighbours 44-88x, because high arithmetic intensity",
    "Results l217: normalisation 329x/206x/173x -> range 173-329x (ricalcolato 173.1-329.3; con rep2-5 115-137x); neighbours 44.3-88.1x (ok). Results l217 descrive la normalisation come 'only element-wise division and logarithm', cioe' bassa intensita' aritmetica (memory-bound).",
    W + "f02_perstep_speedup_1gpu.csv",
    "Il limite inferiore 88x e' preso dai neighbours; il meccanismo invocato (alta intensita' aritmetica) e' l'opposto di quello di un'operazione element-wise. Il 329x dipende dalla rep1 lenta della CPU.")
v["A0275"] = V("UNSUPPORTED", "major", "data loading and Leiden on small graphs show no GPU advantage or CPU advantage",
    "Data loading 0.76-0.85x confermato (l223). Leiden a 10k: 0.36x solo per leiden_0.5 includendo rep1; escludendo rep1 1.12x; leiden_1.0 e 1.5 a 10k 1.36x e 1.60x anche con rep1; somma delle 3 risoluzioni 0.70x (5 rip.) e 1.31x (rep2-5).",
    W + "f02_scrna_pow.py PoW-4 output",
    "Il vantaggio CPU nel Leiden a 10k e' un costo una tantum della prima chiamata cuGraph nella prima ripetizione, non una proprieta' dei grafi piccoli.")
v["A0276"] = V("MISMATCH", "major", "data loading cost dominated by CUDA context initialisation and RMM pool allocation",
    "In scripts/benchmark_gpu.py init_rmm_pool() e gpu_warmup() sono chiamati PRIMA del time_step('data_loading'); Methods l83 dichiara lo stesso. Lo step cronometrato contiene read_h5ad + anndata_to_GPU.",
    "scripts/benchmark_gpu.py righe 225-245; manoscritto l83",
    "La spiegazione attribuisce lo 0.76-0.85x a costi esclusi dal cronometro; la differenza nasce da anndata_to_GPU e dalla lettura. Contraddice i Methods.")
v["A0277"] = V("UNSUPPORTED", "major", "Leiden on small graphs limited by low arithmetic intensity (roofline)",
    "Escludendo rep1, GPU Leiden a 10k e' piu' veloce della CPU (1.12x, 1.29x, 1.59x per r = 0.5, 1.0, 1.5). Inoltre CPU igraph usa n_iterations=2 (benchmark_cpu.py l239) e cuGraph max_iter=100 (rsc 0.14.1 tools/_clustering.py default n_iterations=100).",
    W + "f02_perstep_speedup_1gpu.csv; scripts/benchmark_cpu.py; github rapids_singlecell v0.14.1 _clustering.py",
    "Il roofline non e' la spiegazione supportata dai dati: l'effetto e' di inizializzazione, e i due Leiden non fanno lo stesso lavoro.")
v["A0278"] = V("UNSUPPORTED", "minor", "on small datasets the overhead of GPU operations may outweigh benefits",
    "A 10k la pipeline 1 GPU e' 12.0x (5 rip.) o 14.0x (rep2-5) piu' veloce; nessuna dimensione mostra la GPU piu' lenta end-to-end (Table 4).",
    W + "f02_table4_conventions.csv",
    "Non osservato nei dati; Dicks et al. 2026 lo riportano sotto ~50k celle senza DE: va spiegato che qui il DE CPU domina anche a 10k (54.9% del tempo CPU).")
v["A0279"] = V("UNSUPPORTED", "minor", "step-level heterogeneity extends into multi-GPU scaling",
    "Nessuno step e' stato distribuito tra GPU (vedi A0280); l'eterogeneita' tra 2/4/8 GPU sta nel data loading su CPU.",
    W + "f02_amdahl.csv", "Cornice interpretativa senza base.")
v["A0280"] = V("MISMATCH", "critical", "12% improvement 2->8 GPUs because only PCA and neighbours exploit distributed GPU computation, remaining 95%",
    "Medie 5 rip. a 1.3M: totale 493.29 -> 435.18 s (-11.8% di tempo, 1.13x). PCA+neighbours 17.23 s (2 GPU) vs 17.01 s (8 GPU), delta 0.22 s; data_loading 148.99 vs 90.61 s, delta 58.38 s, cioe' circa il 100% della differenza totale (58.12 s). PCA e neighbours non distribuiti: adata.X e' un CuPy array su GPU 0, rsc.pp.pca usa Dask solo con DaskArray, rsc.pp.neighbors non ha percorso Dask. Quota non-PCA/neighbours: 96.2% (rep1) / 96.1% (media), non 95%.",
    W + "f02_steps_2v8_1300000.csv; scripts/benchmark_multigpu.py righe 320-380; rapids_singlecell v0.14.1 _pca.py e _neighbors/__init__.py",
    "Il 12% non e' scaling multi-GPU ma una differenza di I/O tra nodi/job concorrenti (driver 535.247.01 per 2/4 GPU, 535.183.01 per 8 GPU). Il diario del progetto (CLAUDE.md) scrive per la pipeline standard 'PCA: Single-GPU truncated SVD' e 'Other 7 GPUs sat idle'.")
v["A0281"] = V("UNSUPPORTED", "major", "classic manifestation of Amdahl's law",
    "Fit T(N)=a+b/N sui 15 run 2/4/8 GPU a 1.3M: totale b=136.6 s (IC95 57-216) ma tutto dal data_loading (b=141.4); totale meno data_loading b=-4.75 s (IC95 -51.9, 42.4), frazione parallela ~0. Delta 2->4 = 6.7 s e delta 4->8 = 51.5 s: con Amdahl il primo dovrebbe essere il doppio del secondo.",
    W + "f02_amdahl.csv",
    "Non c'e' frazione parallela da stimare: Amdahl con p~0 descrive l'assenza di parallelismo, non un limite strutturale. Riferimento Amdahl1967 DOI dal bib, non aperto in questa sessione.")
v["A0282"] = V("UNSUPPORTED", "major", "distributing preprocessing would require substantial modifications to Scanpy architecture",
    "rapids-singlecell v0.14.1 ha gia' rami Dask per normalize_total, log1p (_normalize.py) e pca (_pca.py); la documentazione stable elenca anche calculate_qc_metrics, filter_cells/genes, highly_variable_genes, scale. Nolet et al. 2022 distribuivano filtering e normalisation su 8 V100 (272 -> 60 s a 1.3M).",
    "github scverse/rapids_singlecell v0.14.1 _normalize.py, _pca.py; rapids-singlecell.scverse.org stable out_of_core.md; Nolet 2022 Table 1",
    "L'opzione esisteva nello stack usato; non e' stata attivata.")
v["A0283"] = V("UNSUPPORTED", "major", "8 independent single-GPU workers with near-linear throughput scaling",
    "Throughput concorrente non misurato. I job 2 e 4 GPU girati in contemporanea sullo stesso nodo (driver 535.247.01, timestamp sovrapposti) hanno data_loading 149.0 e 135.1 s contro 90.6 s del job 8 GPU da solo su altro nodo: contesa di I/O gia' osservata. Lo speedup normalizzato per costo (f03) favorisce comunque meno GPU per job (2 GPU 34-175x vs 8 GPU 10-50x).",
    W + "f02_provenance.csv; " + W + "f02_steps_2v8_1300000.csv; " + W + "f03_cost_energy.csv",
    "Direzione plausibile (meno GPU per job), ma 'near-linear' e' contraddetto dalla contesa osservata: il 75% del tempo e' preprocessing CPU che si contende core e disco.")
v["A0284"] = V("UNSUPPORTED", "major", "DGX delivers greatest return as cluster of eight H100 workstations",
    "Nessuna misura di throughput, costo o ritorno; vedi A0283.", "n/a", "Affermazione di economia senza dati.")
v["A0285"] = V("UNSUPPORTED", "major", "most of the practical value accessible without a DGX",
    "A 500k e 1.3M la pipeline single-GPU non e' stata misurata (Table 4 l187); la variante ibrida con n_gpus=1 non e' stata eseguita.",
    "results/ (nessun gpu_500000_* o gpu_1300000_*)", "Plausibile perche' tutto il calcolo GPU e' gia' su GPU 0, ma non misurato.")
v["A0286"] = V("UNSUPPORTED", "major", "below 500,000 cells fits on a single H100; memory-optimised variant extends single-GPU feasibility to 1.3M and beyond",
    "Single-GPU misurato solo a 10k/50k/100k; soglia tra 100k e 500k non determinata. La variante memory-optimised e' stata eseguita solo a 8 GPU (tutti i file maxpower_*_8gpu; PCA covarianza distribuita su 8 GPU).",
    "results/gpu_*; results/maxpower_*_8gpu_results.json metadata.n_gpus=8",
    "'Single-GPU feasibility to 1.3M and beyond' non e' stata testata.")
v["A0287"] = V("MISMATCH", "major", "single H100 USD 2-4/h; 120x at 1.3M -> well under one dollar",
    "Il 120x richiede 8 GPU: 8 x 435.18 s x 2-4 USD/GPU-h = 1.93-3.87 USD. Con 2 GPU (105x): 0.55-1.10 USD. Una GPU sola non e' stata misurata a 1.3M. Prezzi letti: 1.99-4.29 USD/GPU-h (neocloud) e 6.88-12.29 (hyperscaler) (intuitionlabs, agg. 2026-10-11); Lambda 3.99.",
    W + "f03_cost_energy.py; https://intuitionlabs.ai/articles/h100-rental-prices-cloud-comparison; https://lambda.ai/service/gpu-cloud/pricing",
    "La frase combina il tempo a 8 GPU con il prezzo di 1 GPU. Il range 2-4 USD vale solo per neocloud.")
v["A0288"] = V("UNSUPPORTED", "major", "access to a DGX not a prerequisite; directly relevant to pay-as-you-go budgets",
    "Dipende da A0285-A0287 (single-GPU a 1.3M non misurato).", W + "f03_cost_energy.csv", "Riformulare come ipotesi.")
v["A0289"] = V("UNSUPPORTED", "minor", "biological outputs show high agreement",
    "Misurato solo a 10k (concordance_10000_r1.json).", "results/concordance_10000_r1.json", "Generalizzazione oltre il disegno.")
v["A0290"] = V("PASS", "info", "HVG Jaccard 1.000 and PCA rho 1.000",
    "concordance_10000_r1.json: hvg jaccard 1.0, pca mean_abs_spearman_rho 1.0 (Results l240). In piu': hash della lista HVG identico CPU vs 1 GPU a 10k, 50k, 100k (f02_determinism.csv).",
    "results/concordance_10000_r1.json; " + W + "f02_determinism.csv",
    "Sostenuto; l'identita' HVG si estende a 100k (dato utile da aggiungere). 'Identical numerical inputs' e' improprio: l'input GPU proviene da un preprocessing diverso.")
v["A0291"] = V("UNSUPPORTED", "major", "ARI 0.908-0.963 consistent with inherent stochasticity across implementations",
    "ARI ricalcolati ok. Ma: CPU Leiden identico nei 5 run a ogni N (1 hash); GPU identico a 10k; differenza di configurazione sistematica (igraph n_iterations=2 vs cuGraph max_iter=100); concordanza da run del 2026-03-11 (CPU 40/45 cluster vs 41/46 nel benchmark). Duo 2020 valuta 14 metodi in R, non igraph vs cuGraph.",
    W + "f02_determinism.csv; scripts/benchmark_cpu.py l236-240; results/concordance_10000_r1.json; OpenAlex Duo 2020",
    "La differenza e' implementativa e di configurazione, non stocastica.")
v["A0292"] = V("UNSUPPORTED", "major", "FP non-associativity negligible; dominant source is Leiden vertex ordering",
    "Nessun esperimento separa le due fonti (es. Leiden CPU sul grafo GPU, o semi diversi a parita' di grafo). A 10k la GPU e' deterministica tra ripetizioni.",
    W + "f02_determinism.csv", "Affermazione causale senza esperimento; proposto PoW-H.")
v["A0293"] = V("UNSUPPORTED", "major", "GPU and CPU analyses interchangeable for biological interpretation",
    "Solo 10k. A >=50k le etichette GPU cambiano tra ripetizioni con lo stesso seme (fino a 4 partizioni diverse in 5 run a 1.3M, r=1.5; numero di cluster 82-84) e il numero di cluster GPU diverge dalla CPU (1.3M r=1.0: CPU 75, GPU 67-70). Gardner 2025: ARI ~0.5 e 'they are not interchangeable'; Nolet 2022: ARI 0.54 a 1.3M.",
    W + "f02_determinism.csv; lit: 3731599.3767378.pdf p.355; 2022.05.26.493607v1 p.6",
    "Conclusione piu' forte del disegno e in contrasto non discusso con la letteratura citata.")
v["A0294"] = V("UNSUPPORTED", "minor", "CPU-side memory pressure, not GPU VRAM, is the binding constraint",
    "Coerente con Results l260-265 per questa pipeline (scale OOM a 13.7M, HVG OOM a 14M). ScaleSC elabora 13M cellule su una sola A100; Dicks 2026 100M su 8 B300 con Dask out-of-core.",
    "Results l260-265; ScaleSC bioRxiv 10.1101/2025.01.28.635256; Dicks 2026",
    "Vincolo della pipeline (preprocessing Scanpy in memoria), non dell'analisi GPU in generale.")
v["A0295"] = V("UNSUPPORTED", "minor", "challenges the common intuition", "Nessuna fonte citata per 'common intuition'.", "n/a", "Retorica; togliere o citare.")
v["A0296"] = V("PASS", "info", "VRAM flat at 49 GB (7.6% of 640 GB), peak RAM 535 GB at 11.9M",
    "maxpower_11900000: peak_vram 48.84 GB, 48.84/640 = 7.63%; peak_ram 534.55 GB (Results l262, Table 5).",
    "results/maxpower_11900000_8gpu_results.json", "Numeri ok; la VRAM include i pool RMM (2 GB/worker) e misura riservato, non fabbisogno.")
v["A0297"] = V("UNSUPPORTED", "major", "failure occurred because transient memory spikes briefly multiplied the working set past the cgroup limit",
    "535/1800 = 29.7% ok. Nessuna misura dei picchi: Results l262 'treat the attribution ... as unresolved'; Table 6 stimata; strumentazione solo tra step e solo processo padre (l111).",
    "Results l262, l283; Methods l111",
    "La frase afferma come causa cio' che i Risultati dichiarano non risolto (pur con 'most plausibly').")
v["A0298"] = V("UNSUPPORTED", "major", "short-lived peaks that the scanpy preprocessing stack is structured to create",
    "Non misurato (vedi A0297).", "Results l262", "Asserzione causale non sostenuta.")
v["A0299"] = V("UNSUPPORTED", "minor", "gains via avoiding transient peaks; VRAM heavily underutilised",
    "Il Leiden e' escluso come colpevole lato host (l262), eppure 'streaming Leiden' e' tra i rimedi; la VRAM misurata e' dominata dai pool.",
    "Results l262", "Suggerimenti non collegati ai dati.")
v["A0300"] = V("MISMATCH", "major", "capacity ~ cells x HVGs; 20M cells at 1,000 HVGs and 4M at 5,000",
    "Matrice densa a 11.9M x 2000 x 4 B = 95.2 GB = 17.8% del picco 534.55 GB. Anche con capacita' inversamente proporzionale agli HVG: 23.8M (1000) e 4.76M (5000). Con il bilancio di Table 6 (36.9 kB/cella non-HVG): 13.1M e 9.4M.",
    W + "f04_capacity_hvg.py -> f04_capacity_hvg.csv",
    "Le cifre non seguono da nessun modello coerente con i dati; Table 6 attribuisce 380 GB alle matrici sparse.")
v["A0301"] = V("MISMATCH", "major", "chunked variant reduced VRAM 49 -> 10 GB without improving the cell limit",
    "maxpower_chunked_12000000: peak_vram 9.6 GB (fattore 5.1), succeeded a 12.0M; Results l267: succeeded at 12.0M e fallito a 15.0M, mentre la pipeline standard falliva a 12.0M.",
    "results/maxpower_chunked_12000000_8gpu_results.json; Results l267",
    "Il limite e' migliorato (da 11.9M a >=12.0M, <15M).")
v["A0302"] = V("UNSUPPORTED", "minor", "pseudo-bulk optimal balance efficiency/rigour", "Rigore statistico non valutato nel benchmark.", "Table 7", "Opinione.")
v["A0303"] = V("PASS", "minor", "pseudo-bulk 44x vs cell-level t-test; avoids pseudoreplication [Squair2021]",
    "5597.79/127.47 = 43.9x. Abstract di Squair 2021 (letto via OpenAlex): metodi che ignorano la variabilita' tra repliche sono distorti e producono falsi positivi.",
    "results/de_benchmark_*.json; OpenAlex W doi:10.1038/s41467-021-25960-2", "Ok come tempo; non e' una accelerazione a parita' di test.")
v["A0304"] = V("MISMATCH", "major", "GPU acceleration of cell-level DE provides 3-7x, limited by sparse-to-dense I/O",
    "3.4x e 6.7-6.8x sono rapporti contro la t-test CPU (Table 7). Results l308: 'should be read as which approach finishes fastest overall, not as a within-method GPU acceleration factor'. Nessuna profilazione dell'I/O.",
    "Table 7; Results l308", "La Discussione usa il numero nel modo che i Risultati escludono.")
v["A0305"] = V("UNSUPPORTED", "minor", "Wilcoxon 826 vs t-test 1,656 s because argsort maps efficiently onto sparse data",
    "Tempi ok: 826.31 e 1655.47 s. Meccanismo non misurato.", "results/de_benchmark_wilcoxon_scatter.json, de_benchmark_ttest_scatter.json", "Spiegazione non verificata.")
v["A0306"] = V("UNSUPPORTED", "major", "at 3.4M virtually every gene reaches significance",
    "I JSON DE contengono solo tempi; nessuna distribuzione di p-value nei Risultati.", "results/de_benchmark_*.json", "Affermazione senza dato.")
v["A0307"] = V("UNVERIFIABLE", "minor", "pseudo-bulk with DESeq2/edgeR gold standard [Squair2021]",
    "Abstract letto, passaggio specifico non letto. Il benchmark usa Wilcoxon su CPM log, non modelli di conteggio.", "OpenAlex Squair 2021", "Incoerenza tra raccomandazione e implementazione.")
v["A0308"] = V("UNSUPPORTED", "minor", "pseudo-bulk default on statistical and computational grounds",
    "Base statistica non testata qui; 8 cluster su 81 con un solo donatore saltati (diario).", "n/a", "Opinione.")
v["A0309"] = V("UNSUPPORTED", "major", "GPU increasingly impactful for spatial statistics", "Vedi A0271, A0310.", W + "f01_spatial_speedup_conventions.csv", "Dipende dalla co-occurrence.")
v["A0310"] = V("UNSUPPORTED", "critical", "3,272x co-occurrence, largest GPU speedup reported for any spatial operation, O(n^2)",
    "3272x solo con rep2-5; CPU rep1 73.47 s con output identico -> 29x (r1 vs r1), 67x (CPU r1 vs GPU r2-5). Carico diverso: CPU 7 cluster, GPU 3. 'Largest reported' senza ricerca sistematica (nessun benchmark spatial GPU comparabile trovato in questa sessione); O(n^2) non mostrato.",
    W + "f01_spatial_speedup_conventions.csv; spatial_concordance_visium_hd_square_008um.json co_occurrence.status",
    "Cifra di testa non robusta.")
v["A0311"] = V("MISMATCH", "minor", "162-170x with rho >= 0.9995; identical rankings in seconds rather than minutes",
    "rep2-5: Moran 162.3x (HD 8um) e 167.2x (HD 2um), Geary 162.5x e 169.7x: range 162-170 ok. Con rep1: 37-129x. CPU 34-48 s, GPU 0.2-0.3 s: 'sotto il secondo contro mezzo minuto', non 'secondi contro minuti'. Ranking non identici: top-100 Jaccard 0.98 (Moran, HD 8um), FDR 98.2-99.9%.",
    W + "f01_spatial_speedup_conventions.csv; spatial_concordance_*.json", "Formulazione da correggere.")
v["A0312"] = V("UNSUPPORTED", "minor", "CPU-only operations are opportunities for future GPU-native implementations",
    "La documentazione stable di rapids-singlecell elenca versioni GPU di spatial_neighbors (knn, radius, delaunay, grid) e funzioni co_occurrence, ligrec, nhood_enrichment.",
    "rapids-singlecell.scverse.org/en/stable/notebooks/04_squidpy.html", "Verificare in quale versione sono comparse; se gia' in 0.14.x la frase e' errata.")
v["A0313"] = V("PASS", "info", "notable finding on clustering at extreme resolution",
    "HD 2um ARI media rep2-5 = 0.0795 (0.0843 in 4 rip., 0.0652 in r3).", "SPATIAL/results/spatial_concordance_visium_hd_square_002um.json", "Raccordo; numero ok.")
v["A0314"] = V("UNSUPPORTED", "major", "divergence not specific to GPU vs CPU; sensitivity of stochastic partitioning",
    "CPU 2,559 cluster in tutti i 5 run (deterministico), GPU 534-538: differenza sistematica 4.75x, non stocastica. Nessun confronto CPU-CPU o GPU-GPU con semi diversi.",
    "SPATIAL/results/spatial_*_visium_hd_square_002um_r*_results.json results_summary.n_clusters", "Ipotesi non testata.")
v["A0315"] = V("UNSUPPORTED", "minor", "389,492 bins, resolution 0.1; local optima abound",
    "389,492 bin dopo QC ok (n_spots_after_qc); risoluzione 0.1 (Table 3). Paesaggio di ottimi locali non misurato.", "spatial_cpu_visium_hd_square_002um_r2_results.json", "Numeri ok, meccanismo no.")
v["A0316"] = V("UNSUPPORTED", "minor", "users should employ consensus clustering",
    "Duo 2020 (abstract letto): il consensus clustering in genere non migliora rispetto al migliore dei metodi combinati.", "OpenAlex doi:10.12688/f1000research.15666.3", "Raccomandazione non testata e in parte contraria alla fonte citata poco prima.")
v["A0317"] = V("PASS", "info", "limitations intro", "nessun numero", "n/a", "Raccordo.")
v["A0318"] = V("MISMATCH", "minor", "scRNA-seq benchmark used a single biological dataset (mouse brain E18)",
    "Stress test e DE usano un secondo dataset: CELLxGENE Census mouse brain, 3,436,470 cellule, 41,321 geni, 202 donatori (maxpower metadata input_file brain_full_3436470.h5ad; de_benchmark_pseudobulk.json n_donors 202), replicato per copie fino a 11.9M.",
    "results/maxpower_3436470_8gpu_results.json; results/de_benchmark_pseudobulk.json; scripts/benchmark_maxpower.py", "Limite formulato in modo inesatto.")
v["A0319"] = V("PASS", "minor", "concordance performed at 10,000 cells",
    "Confermato (unico file concordance_10000_r1.json, malgrado slurm/analysis.sh preveda tutte le dimensioni); da aggiungere che proviene da un run precedente al benchmark.", "results/; slurm/analysis.sh", "Limite corretto ma incompleto.")
v["A0320"] = V("PASS", "info", "stress test mathematically equivalent but not implementation-identical", "Coerente con Methods l110.", "Methods l110", "Aggiungere i dati replicati.")
v["A0321"] = V("PASS", "info", "spatial on local RTX 4090; full 6.3M bins not benchmarked",
    "n_spots_input 6,296,688 -> 389,492 (JSON).", "spatial_cpu_visium_hd_square_002um_r2_results.json", "Ok.")
v["A0322"] = V("MISMATCH", "minor", "the cluster's driver (535.183.01) caps CUDA at 12.2",
    "I run scRNA a 1/2/4 GPU riportano driver 535.247.01, quelli a 8 GPU e lo stress test 535.183.01: il cluster ha nodi con driver diversi.",
    W + "f02_provenance.csv", "Dichiarare entrambi i driver e su quale nodo e' fallito lo spatial.")
v["A0323"] = V("UNVERIFIABLE", "info", "conservative driver policy reasonable", "Opinione.", "n/a", "Nessun dato.")
v["A0324"] = V("UNSUPPORTED", "major", "near-flat wall time 2->8 GPUs indicates bottleneck in CPU preprocessing and single-GPU ops; multi-node not useful",
    "La curva piatta deriva dal fatto che nessuno step e' distribuito (A0280); non informa sul multi-nodo.", W + "f02_amdahl.csv", "Ragionamento basato su un artefatto.")
v["A0325"] = V("PASS", "info", "transition", "nessun numero", "n/a", "Raccordo.")
v["A0326"] = V("MISMATCH", "major", "500k/1.3M only via Dask-CUDA hybrid in which preprocessing had no distributed GPU route",
    "rapids-singlecell 0.14.1 ha rami Dask per normalize_total/log1p/pca; nella ibrida X non diventa mai Dask, quindi neppure PCA e neighbours sono distribuiti. Il superamento degli 80 GB a 500k e 1.3M non ha un JSON di fallimento nel repo.",
    "rapids_singlecell v0.14.1 _normalize.py, _pca.py; scripts/benchmark_multigpu.py", "Il limite e' della configurazione, non dello stack.")
v["A0327"] = V("UNSUPPORTED", "minor", "75% CPU-preprocessing fraction is a property of the software stack",
    "75.2% nel run r1 a 8 GPU (348.7/463.4 s), 78.0% sulla media 5 rip.; deriva dalla scelta di Scanpy su CPU nella pipeline ibrida.", W + "f00_runs.csv", "Proprieta' della pipeline configurata.")
v["A0328"] = V("PASS", "info", "memory sampled between steps, parent process only, lower bounds", "Coerente con Methods l111 e scripts/benchmark_maxpower.py (psutil RSS).", "Methods l111", "Ok.")
v["A0329"] = V("PASS", "info", "would require continuous sampling or cgroup peak", "Coerente.", "n/a", "Ok.")
v["A0330"] = V("PASS", "info", "integration methods not benchmarked", "Coerente.", "n/a", "Ok; Dicks 2026 riportano Harmony fino a 11.4M.")
v["A0331"] = V("UNSUPPORTED", "major", "14.5 h -> 7.3 min at 1.3M, biologically concordant",
    "52,056 s = 14.46 h, 435.18 s = 7.25 min (8 GPU) ok; il DE e' il 93.5% del tempo CPU; con 2 GPU 8.2 min; concordanza solo a 10k.",
    W + "f02_speedup_with_without_DE.csv", "Riportare la composizione del guadagno e il limite della concordanza.")
v["A0332"] = V("UNSUPPORTED", "minor", "principal bottleneck CPU preprocessing; 11.9M using 7.6% of GPU memory",
    "7.63% ok; vedi A0010 e A0294 (pipeline, dati replicati, VRAM come pool).", "results/maxpower_11900000_8gpu_results.json", "Generalizzazione.")
v["A0333"] = V("MISMATCH", "critical", "Multi-GPU scaling modest benefit (12% at 1.3M, 2 to 8) due to non-GPU-parallelised phases",
    "Il 12% (11.8% di tempo) e' tutto nel data_loading (delta 58.4 su 58.1 s); PCA+neighbours invariati (17.23 vs 17.01 s) e non distribuiti. A 500k: 124.46/124.96/124.60 s.",
    W + "f02_steps_2v8_1300000.csv; " + W + "f02_amdahl.csv", "Conclusione da riscrivere: lo scaling multi-GPU non e' stato misurato.")
v["A0334"] = V("UNSUPPORTED", "major", "pseudo-bulk simultaneously fastest (44x) and most statistically rigorous",
    "43.9x ok; rigore non valutato; il pseudo-bulk implementato usa Wilcoxon su CPM log di 2,431 pseudo-campioni.", "results/de_benchmark_pseudobulk.json", "Seconda meta' non sostenuta dai dati.")
v["A0335"] = V("UNSUPPORTED", "critical", "51.6x end-to-end on Visium HD, co-occurrence 3,272x, concordance > 0.9995",
    "Vedi A0012: 41.5x con tutte le ripetizioni, 6.4x in rep1; HD 2um 10.8x; 'on Visium HD' generalizza la sola risoluzione 8 um.", W + "f01_spatial_speedup_conventions.csv", "Cifre di testa dipendenti dall'esclusione di rep1.")
v["A0336"] = V("UNVERIFIABLE", "minor", "billion-cell and billion-bin scales [Regev2017]", "Regev 2017 non letto in questa sessione; 'billion-bin' non e' un concetto del 2017.", "n/a", "Verificare la fonte o togliere.")

out = []
for r in inv:
    d = v[r["id"]]
    out.append(dict(inv_id=r["id"], track="F", line=r["line"], section=r["section"] or "Front matter",
                    locator=r["text"][:200], **d))

def N(line, section, locator, status, severity, claimed, recomputed, source, note):
    return dict(inv_id=None, track="F", line=line, section=section, locator=locator[:200], claimed=claimed,
                recomputed=recomputed, status=status, severity=severity, source=source, note=note)

# ---- extra findings on sentences outside the slice or not inventoried ----
out.append(N(14, "Abstract", "Multi-GPU scaling was sublinear due to CPU preprocessing dominance.", "MISMATCH", "critical",
    "sublinear multi-GPU scaling due to CPU preprocessing",
    "Nessuno step distribuito: PCA/neighbours su GPU 0 (X non Dask); differenza 2->8 GPU a 1.3M tutta nel data_loading (58.4 s); a 500k tempi identici (124.5/125.0/124.6).",
    W + "f02_amdahl.csv; scripts/benchmark_multigpu.py", "Frase dell'abstract non presente nell'inventario."))
out.append(N(14, "Abstract", "These results identify CPU-side preprocessing as the primary bottleneck and provide practical guidance for deploying GPU-accelerated workflows at atlas scale.", "UNSUPPORTED", "major",
    "CPU-side preprocessing primary bottleneck",
    "Il preprocessing e' su CPU per scelta della pipeline ibrida; rsc 0.14.1 offre percorsi GPU/Dask. Nella pipeline 1 GPU a 100k QC+normalisation+HVG pesano 0.30 s su 14.77 s (data loading 5.65 s).",
    W + "f00_runs.csv; rapids_singlecell v0.14.1", "Frase dell'abstract non presente nell'inventario."))
out.append(N(185, "Results", "The speedup increased monotonically with dataset size: 33.6x at 50k, 43.7x at 100k, 34.9x at 500k (2 GPU), and 119.6x at 1.3M (8 GPU)", "MISMATCH", "major",
    "speedup monotonic in dataset size",
    "43.8x (100k, 1 GPU) -> 34.9x (500k, 2 GPU): decresce; la serie mescola due pipeline. A pipeline fissa (ibrida 2 GPU): 8.1, 19.2, 24.1, 34.9, 105.5x.",
    W + "f02_table4_conventions.csv", "Sostiene il 'consistent' della Discussione (A0270)."))
out.append(N(252, "Results", "First, the aggregate peak VRAM at 1.3M cells with 8 GPUs (134.2 GB) exceeds the 80 GB capacity of any single H100 device; this working set could not have fit on one GPU alone", "MISMATCH", "critical",
    "aggregate VRAM > 80 GB proves distribution",
    "gpu8_1300000_r1: VRAM totale 14.6 GB dopo scale, 93.2 GB prima della PCA (subito dopo l'avvio del cluster Dask): +78.6 GB = 8 worker x pool RMM 10 GB. L'aggregato misura i pool riservati, non dati distribuiti.",
    "results/gpu8_1300000_r1_results.json memory.detailed scale_vram_after_gb, pca_vram_before_gb", "La prova di distribuzione e' invalida."))
out.append(N(157, "Methods", "Jobs were submitted via SLURM on a dedicated DGX H100 node (`poddgx02`).", "MISMATCH", "major",
    "dedicated node poddgx02",
    "gpu_{1,2,4,8}.sh senza --nodelist e senza --exclusive; driver 535.247.01 (1/2/4 GPU) vs 535.183.01 (8 GPU e stress test con --nodelist=poddgx02): almeno due nodi. Job 1/2/4 GPU concorrenti (timestamp 21:53-23:03 sovrapposti). CPU allocate: 16/32/56/200 per 1/2/4/8 GPU, 100 per la CPU.",
    W + "f02_provenance.csv; slurm/gpu_*.sh", "Confonde il confronto 2 vs 8 GPU (nodo, I/O, core)."))
out.append(N(159, "Methods", "Spatial benchmarks ran on a local workstation equipped with an NVIDIA RTX 4090 (24 GB GDDR6X), 100 CPU cores, and 256 GB DDR5 RAM", "MISMATCH", "minor",
    "100 CPU cores", "Tutti i JSON spatial CPU e GPU riportano n_cpus = 128 (thread impostati a 128 dallo script).",
    "SPATIAL/results/spatial_cpu_*_results.json metadata.n_cpus", "Baseline CPU spatial dichiarata in modo diverso dal run."))

# ---- hidden points (punti nascosti) ----
H = [
 ("H1 multi-GPU non distribuito", "critical", "UNSUPPORTED",
  "adata.X resta CuPy su GPU 0; rsc.pp.pca usa Dask solo con DaskArray; rsc.pp.neighbors senza ramo Dask; tempi PCA+neighbours identici a 2/4/8 GPU (500k: 2.98/2.97/3.00 s; 1.3M: 17.23/16.99/17.01 s).",
  W + "f02_amdahl.csv; scripts/benchmark_multigpu.py; rsc v0.14.1", "Tutta la sezione multi-GPU misura la stessa computazione single-GPU con worker Dask inattivi."),
 ("H2 nodi diversi, job concorrenti, CPU allocate diverse", "major", "UNSUPPORTED",
  "Driver 535.247.01 (1/2/4 GPU, concorrenti) vs 535.183.01 (8 GPU); cpus-per-task 16/32/56/200; data_loading a 1.3M 149/135/91 s.",
  W + "f02_provenance.csv; slurm/gpu_*.sh", "Le differenze tra configurazioni GPU sono confuse con nodo, contesa di I/O e core."),
 ("H3 esclusione rep1 nello spatial", "critical", "UNSUPPORTED",
  "CPU co-occurrence HD 8um r1 73.47 s vs r2-5 ~3573 s con output identico; speedup totale 51.6x (r2-5), 41.5x (r1-5), 6.4x (r1).",
  W + "f01_spatial_speedup_conventions.csv", "La rep1 non e' warmup per la CPU: e' 49x piu' veloce."),
 ("H4 warmup e JIT nello scRNA", "major", "UNSUPPORTED",
  "Warmup = matmul 100x100; rep1 GPU 10k 6.40 s vs 2.50 s (x2.56); SD 1.75 -> 0.11 s escludendo rep1; speedup 10k 12.0x -> 14.0x; leiden_0.5 10k r1 1.70 s vs 0.09 s.",
  W + "f02_table4_conventions.csv", "Convenzione diversa da quella dello spatial; Leiden 10k 'CPU faster' e' un artefatto."),
 ("H5 lo speedup end-to-end e' guidato dal DE CPU", "major", "UNSUPPORTED",
  "Quota DE nel tempo CPU: 54.9% (10k), 84.9% (50k), 86.9% (100k), 84.6% (500k), 93.5% (1.3M); speedup senza DE 9.4x/8.9x/10.2x (1 GPU) e 7.9-9.2x a 1.3M.",
  W + "f02_speedup_with_without_DE.csv", "Il 120x e' in gran parte un benchmark del Wilcoxon di Scanpy."),
 ("H6 equita' della baseline e normalizzazione per costo", "major", "UNSUPPORTED",
  "100 CPU logiche su 224 contro 1-8 H100; QC Scanpy invariato con 32 o 200 CPU (188.2 vs 186.6 s) -> step largamente single-thread; speedup per costo a 1.3M: 10-50x (8 GPU), 34-175x (2 GPU); per energia (limite TDP) 6x (8 GPU), 22x (2 GPU).",
  W + "f03_cost_energy.csv", "Con 8 GPU lo speedup per costo e' 2.4-12 volte inferiore a quello in tempo; con 2 GPU va da 0.3 a 3 volte quello in tempo: premia meno GPU per analisi."),
 ("H7 concordanza solo a 10k, da run diverso, GPU non deterministica a scala", "major", "UNSUPPORTED",
  "concordance_10000_r1.json del 2026-03-11 (prima del benchmark); hash etichette GPU variabili tra ripetizioni a >=50k; letteratura ARI ~0.5.",
  W + "f02_determinism.csv; results/concordance_10000_r1.json", "La concordanza non copre la scala a cui si fanno le affermazioni."),
 ("H8 Leiden igraph (2 iterazioni) vs cuGraph (100)", "major", "UNSUPPORTED",
  "benchmark_cpu.py: flavor='igraph', n_iterations=2; rsc.tl.leiden default n_iterations=100 (max_iter).", "scripts/benchmark_cpu.py; rsc v0.14.1 _clustering.py",
  "Ne' i tempi ne' l'ARI confrontano lo stesso algoritmo; contraddice 'identical parameters' (Table 1)."),
 ("H9 tetto della Jaccard kNN", "minor", "UNSUPPORTED",
  "concordance_10000_r1.json knn: max 0.9375 (=15/16), fraction_perfect 0.0, mediana 0.9375: gli insiemi confrontati hanno cardinalita' diverse (self o k diverso).",
  "results/concordance_10000_r1.json knn_concordance; scripts/compare_results.py compare_knn", "0.930 e' 99% del massimo raggiungibile; l'interpretazione 'floating-point' e' errata."),
 ("H10 codice non cronometrato", "minor", "UNSUPPORTED",
  "Esclusi init RMM, warmup, copia adata.raw, subset HVG, avvio/arresto Dask. Intervallo tra timestamp (limite superiore, include il salvataggio): 1 GPU 10k 8.2 s vs 2.5 s cronometrati; 8 GPU 1.3M 522 s vs 428 s.",
  W + "f02_walltime_gaps.csv", "'End-to-end' non comprende tutto cio' che l'utente paga."),
 ("H11 un solo dataset per la scala; stress su dati replicati", "major", "UNSUPPORTED",
  "Scala 10k-1.3M solo E18; stress e DE su CELLxGENE 3.44M, oltre 3.44M copie esatte (cellule duplicate).", "scripts/benchmark_maxpower.py", "Generalizzabilita' e realismo del kNN/Leiden a 11.9M limitati."),
 ("H12 co-occurrence spatial su carichi diversi", "major", "UNSUPPORTED",
  "HD 8um: CPU 7 cluster, GPU 3; concordanza co-occurrence 'shape_mismatch' (non calcolabile), mentre i Methods (l149) la descrivono.", "SPATIAL/results/spatial_concordance_visium_hd_square_008um.json", "Lo speedup confronta lavori diversi."),
 ("H13 equivalenza dei test DE", "major", "UNSUPPORTED",
  "Table 7 confronta t-test CPU, Wilcoxon GPU e Wilcoxon su pseudo-bulk; nessun confronto di p-value o ranking tra CPU e GPU a parita' di test; Wilcoxon CPU non misurato a 3.4M.", "results/de_benchmark_*.json", "Gli 'speedup' DE non sono accelerazioni a parita' di metodo."),
 ("H14 soglie arbitrarie", "minor", "UNSUPPORTED",
  "Co-occurrence/nhood saltati sopra 500 cluster, ligrec sopra 100k spot, rho>0.97 'stringent', risoluzione 0.1 per HD: nessuna motivazione o analisi di sensibilita'; ARI 'high' senza margine di equivalenza.", "manoscritto l144-145, l242", "Le soglie determinano quali step entrano nello speedup end-to-end."),
 ("H15 non determinismo GPU anche nello spatial", "minor", "UNSUPPORTED",
  "Output co-occurrence GPU HD 8um diverso in r3 e r5 (max diff 7.70); cluster GPU HD 2um 534 vs 538; ARI 0.0652 vs 0.0843.", "SPATIAL/results/*.npy; spatial_concordance_visium_hd_square_002um.json", "Va riportato insieme alla concordanza."),
]
for name, sev, st, rec, src, note in H:
    out.append(N(0, "Peer review: punto nascosto", name, st, sev, name, rec, src, note))

# ---- PoW ----
P = [
 ("PoW-A Amdahl e attribuzione del 12% (eseguito)", "UNSUPPORTED", "critical", "frazione parallela ~0; delta 2->8 GPU tutta nel data_loading", W + "f02_scrna_pow.py, f02_amdahl.csv, f02_steps_2v8_*.csv", "Alta priorita'. Rif.: Amdahl 1967 (DOI 10.1145/1465482.1465560 dal bib, non aperto)."),
 ("PoW-B sensibilita' alla rep1 nello spatial (eseguito)", "UNSUPPORTED", "critical", "51.6x -> 41.5x (r1-5) / 6.4x (r1); 3272x -> 2088x / 29x", W + "f01_spatial_repeats.py, f01_spatial_speedup_conventions.csv", "Alta priorita'. Seguito proposto: co-occurrence CPU 5 volte in processi nuovi e 5 nello stesso processo, registrando thread numba."),
 ("PoW-C speedup senza DE (eseguito)", "UNSUPPORTED", "major", "1.3M: 7.9-9.2x senza DE; DE 93.5% del tempo CPU", W + "f02_speedup_with_without_DE.csv", "Alta priorita'. Confronto con Dicks 2026 (10.48550/arXiv.2603.02402): ~110x su H200 senza DE e senza I/O."),
 ("PoW-D convenzione rep1 nello scRNA (eseguito)", "UNSUPPORTED", "major", "10k 12.0x -> 14.0x; 1.3M 8 GPU 119.6x -> 121.9x; SD 1 GPU 10k 1.75 -> 0.11", W + "f02_table4_conventions.csv", "Alta priorita'."),
 ("PoW-E speedup per costo ed energia (eseguito, ipotesi dichiarate)", "UNSUPPORTED", "major", "1.3M: 10-50x (8 GPU), 34-175x (2 GPU); energia limite TDP 6x / 22x", W + "f03_cost_energy.py, f03_cost_energy.csv", "Alta priorita'. Prezzi: intuitionlabs (agg. 2026-10-11), lambda.ai, instances.vantage.sh c7i.24xlarge 4.284 USD/h."),
 ("PoW-F determinismo e conteggi di cluster da hash (eseguito)", "UNSUPPORTED", "major", "GPU non deterministica a >=50k; CPU deterministica", W + "f02_determinism.csv", "Media priorita'. Rif.: Gardner 2025 (10.1145/3731599.3767378) ARI GPU-GPU 0.927."),
 ("PoW-G overhead non cronometrato (eseguito)", "UNSUPPORTED", "minor", "intervalli tra timestamp 1.6-5.1x il tempo cronometrato per le pipeline GPU a 10k-100k", W + "f02_walltime_gaps.csv", "Media priorita'."),
 ("PoW-H concordanza a tutte le N con repliche di seme e Leiden a pari iterazioni (proposto)", "info", "info",
  "Protocollo: compare_results.py sui CSV di etichette gia' salvati per r1-r5 a 50k-1.3M (cpu vs gpu e gpu2/gpu8); 5 semi per lato per ARI CPU-CPU, GPU-GPU, CPU-GPU; igraph n_iterations=-1 o 100 vs cuGraph 100. Dati: CSV sul cluster, non nel repo. Se l'ARI CPU-GPU a 1.3M resta ~0.9: la conclusione si rafforza; se scende verso 0.5 (Nolet, Gardner): 'interchangeable' va ritirata.", "slurm/analysis.sh; scripts/compare_results.py", "Alta priorita'."),
 ("PoW-I vero multi-GPU su nodo esclusivo (proposto)", "info", "info",
  "Protocollo: X letta come Dask array (anndata read_elem_lazy, chunk 100k celle), preprocessing rsc su Dask, PCA covariance_eigh, --exclusive e --nodelist fisso, stessi cpus-per-task, cache svuotata o pre-scaldata in modo uniforme; confronto con n_gpus=1 ibrida. Dati: gli stessi h5ad. Se lo speedup 1->8 GPU diventa >1.5x: lo scaling sublineare era un artefatto; se resta piatto: la tesi Amdahl regge.", "scripts/benchmark_multigpu.py", "Alta priorita'. Rif.: Nolet 2022 (10.1101/2022.05.26.493607): 1->8 V100 2.6x."),
 ("PoW-J scaling dei thread della baseline CPU (proposto)", "info", "info",
  "Protocollo: CPU a 1, 16, 50, 100, 224 thread per step a 100k e 1.3M; DE con implementazione CPU alternativa. Se lo speedup per step varia poco coi thread: la baseline e' di fatto single-thread e lo speedup per core va dichiarato.", "scripts/benchmark_cpu.py", "Media priorita'."),
 ("PoW-K secondo dataset reale (proposto)", "info", "info",
  "Protocollo: ripetere la scala 10k-1.3M e la concordanza sul dataset CELLxGENE 3.44M gia' scaricato (brain_full_3436470.h5ad, 202 donatori). Se gli speedup per step restano entro +-30%: generalizzabilita' rafforzata.", "data sul cluster", "Media priorita'. Rif.: Billato 2025 (10.1101/2025.10.28.681564)."),
 ("PoW-L energia misurata (proposto)", "info", "info",
  "Protocollo: nvidia-smi --query-gpu=power.draw a 1 Hz e RAPL per i socket, integrati sul run; kWh per analisi. Se il rapporto energetico e' <10x a 1.3M, il vantaggio 'in tempo' va distinto da quello in risorse.", "n/a", "Media priorita'."),
 ("PoW-M correzione della Jaccard kNN (proposto)", "info", "info",
  "Protocollo: escludere l'indice della cellula stessa e allineare k nelle due liste prima della Jaccard; ricalcolo dai .npz gia' salvati.", "scripts/compare_results.py", "Bassa priorita'."),
 ("PoW-N co-occurrence su etichette comuni (proposto)", "info", "info",
  "Protocollo: eseguire co-occurrence CPU e GPU sulle stesse etichette (quelle CPU) e sullo stesso intervallo di distanze; ripetere 5 volte in processi separati. Se lo speedup scende sotto 100x, la cifra 3272x va ritirata.", "SPATIAL/scripts/benchmark_spatial_*.py", "Alta priorita'."),
 ("PoW-O HD 2 um: componenti connesse e semi (proposto)", "info", "info",
  "Protocollo: contare le componenti connesse del grafo kNN di espressione; leidenalg e cuGraph con 5 semi ciascuno; ARI intra- e inter-implementazione. Se le componenti sono migliaia, i 2,559 cluster CPU riflettono la struttura del grafo, non la stocasticita'.", "n/a", "Media priorita'. Rif.: Duo 2020 (10.12688/f1000research.15666.3)."),
]
for name, st, sev, rec, src, note in P:
    out.append(N(0, "Peer review: PoW", name, st, sev, name, rec, src, note))

json.dump(out, open(os.path.join(TR, "F_findings.json"), "w"), ensure_ascii=False, indent=1)
from collections import Counter
print(len(out), Counter(o["status"] for o in out), Counter((o["status"], o["severity"]) for o in out if o["status"] in ("MISMATCH",)))
missing = [r["id"] for r in inv if r["id"] not in v]
print("missing", missing)
