"""F track PoW: cost-normalised (and TDP-bounded energy) speedup of the scRNA benchmark.

Times: recomputed from /tmp/repo/results JSON (mean of 5 repeats, Table 4 convention) via f02 output
       f02_table4_conventions.csv (column mean_r1_5).
ASSUMPTIONS (declared, not data):
  GPU price per H100 GPU-hour, on-demand, read in this session on 2026-11-03 from
    https://intuitionlabs.ai/articles/h100-rental-prices-cloud-comparison (updated 2026-10-11, checked 2026-10-10):
      low  = 2.69 (Runpod Community Cloud SXM), mid = 3.99 (Lambda H100 SXM 8-GPU; also https://lambda.ai/service/gpu-cloud/pricing),
      lambda_1gpu = 4.29 (Lambda 1-GPU SXM), high = 6.88 (AWS p5.48xlarge per H100-hour, us-east).
    GPU instance price is assumed to include its host CPUs/RAM.
  CPU price: AWS c7i.24xlarge (96 vCPU Sapphire Rapids, 192 GiB) 4.284 USD/h, read from
    https://instances.vantage.sh/aws/ec2/c7i.24xlarge -> 0.044625 USD per vCPU-hour.
    Scenario A: baseline = 100 logical CPUs (SLURM --cpus-per-task=100 on a 224-logical-CPU node) -> 4.46 USD/h
    Scenario B: baseline = 100 physical cores = 200 vCPU -> 8.93 USD/h
  Energy (upper bound, TDP): H100 SXM up to 700 W (https://www.nvidia.com/en-us/data-center/h100/, read in session);
    Xeon 8480C assumed equal to 8480+ (350 W, 56 cores / 112 threads; vendor listings seen in search results, not Intel ARK).
    CPU energy share = allocated logical CPUs / 224 x 2 x 350 W. GPUs counted at full TDP for the whole run (they idle
    most of the time in the hybrid pipeline, so the GPU energy is overestimated and the ratio is a lower bound).
Output: f03_cost_energy.csv
"""
import os
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
T = pd.read_csv(os.path.join(HERE, "f02_table4_conventions.csv")).set_index(["ngpu", "n"])
gpu_price = {"low_2.69": 2.69, "mid_3.99": 3.99, "lambda1_4.29": 4.29, "aws_6.88": 6.88}
vcpu_h = 4.284 / 96
cpu_price = {"A_100vCPU": 100 * vcpu_h, "B_200vCPU": 200 * vcpu_h}
alloc_cpus = {1: 16, 2: 32, 4: 56, 8: 200}  # SLURM --cpus-per-task in slurm/gpu_{1,2,4,8}.sh
rows = []
for (g, n), r in T.iterrows():
    if g == 0:
        continue
    t_cpu = T.loc[(0, n), "mean_r1_5"]; t_gpu = r.mean_r1_5
    for cpk, cp in cpu_price.items():
        c_cpu = t_cpu / 3600 * cp
        for gpk, gp in gpu_price.items():
            c_gpu = t_gpu / 3600 * g * gp
            rows.append(dict(n=n, ngpu=g, t_cpu_s=t_cpu, t_gpu_s=t_gpu, speedup_time=t_cpu / t_gpu,
                             cpu_scenario=cpk, gpu_price=gpk, cost_cpu_usd=c_cpu, cost_gpu_usd=c_gpu,
                             cost_norm_speedup=c_cpu / c_gpu))
    # TDP-bound energy
    e_cpu = t_cpu / 3600 * (100 / 224 * 700) / 1000           # kWh
    e_gpu = t_gpu / 3600 * (g * 700 + alloc_cpus[g] / 224 * 700) / 1000
    rows.append(dict(n=n, ngpu=g, t_cpu_s=t_cpu, t_gpu_s=t_gpu, speedup_time=t_cpu / t_gpu,
                     cpu_scenario="energy_TDP_bound", gpu_price="-", cost_cpu_usd=e_cpu, cost_gpu_usd=e_gpu,
                     cost_norm_speedup=e_cpu / e_gpu))
R = pd.DataFrame(rows)
R.round(4).to_csv(os.path.join(HERE, "f03_cost_energy.csv"), index=False)
pd.set_option("display.width", 250)
sel = R[(R.n == 1300000) | ((R.n == 100000) & (R.ngpu == 1)) | ((R.n == 10000) & (R.ngpu == 1))]
print(sel.round(3).to_string(index=False))
# the manuscript's 'well under one dollar' claim: 7.3 min (8 GPUs) at USD 2-4 per GPU-hour
t8 = T.loc[(8, 1300000), "mean_r1_5"]; t2 = T.loc[(2, 1300000), "mean_r1_5"]
print("\nClaim check, 1.3M cells:")
for p in (2.0, 4.0):
    print(f"  8 GPU x {t8:.1f} s at {p} USD/GPU-h = {t8/3600*8*p:.2f} USD ; one GPU-equivalent of the same time = {t8/3600*p:.2f} USD ;"
          f" 2 GPU x {t2:.1f} s = {t2/3600*2*p:.2f} USD")
