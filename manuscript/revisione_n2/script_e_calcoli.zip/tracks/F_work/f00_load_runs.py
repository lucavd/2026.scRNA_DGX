"""F track, step 0: load every scRNA benchmark JSON into one long table.
Read-only on /tmp/repo/results. Output: F_work/f00_runs.csv (one row per run x step).
"""
import json, glob, os, re, csv

RES = "/tmp/repo/results"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "f00_runs.csv")

pat = re.compile(r"^(cpu|gpu|gpu2|gpu4|gpu8)_(\d+)_r(\d+)_results\.json$")
rows = []
for f in sorted(glob.glob(os.path.join(RES, "*.json"))):
    m = pat.match(os.path.basename(f))
    if not m:
        continue
    kind, n, r = m.group(1), int(m.group(2)), int(m.group(3))
    ngpu = {"cpu": 0, "gpu": 1, "gpu2": 2, "gpu4": 4, "gpu8": 8}[kind]
    d = json.load(open(f))
    md = d["metadata"]
    gi = md.get("gpu_info", {})
    drv = gi.get("driver_version")
    for step, t in d["timings"].items():
        rows.append(dict(file=os.path.basename(f), n=n, ngpu=ngpu, rep=r,
                         timestamp=md.get("timestamp"), n_cpus=md.get("n_cpus"),
                         driver=drv, step=step, seconds=t,
                         peak_ram_gb=d["memory"].get("peak_ram_gb"),
                         peak_vram_gb=d["memory"].get("peak_vram_gb")))
with open(OUT, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)
print("rows", len(rows), "->", OUT)
