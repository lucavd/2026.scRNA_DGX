"""F track PoW: effect of repeat 1 in the spatial benchmark, and workload equality of co-occurrence.
Reads /tmp/repo/SPATIAL/results/spatial_{cpu,gpu}_<platform>_r<k>_results.json (read-only).
Output: F_work/f01_spatial_repeats.csv (per platform x pipeline x repeat x step) and printed summary:
 - mean of r2-5 (paper convention) vs mean of r1-5 vs r1 alone, for total and co_occurrence
 - speedup CPU/GPU under each convention
 - n_clusters per pipeline/repeat (co-occurrence workload depends on clusters)
Convention: speedup = mean(CPU total)/mean(GPU total); SD not needed here.
"""
import json, glob, os, re, csv
import statistics as st

RES = "/tmp/repo/SPATIAL/results"
HERE = os.path.dirname(os.path.abspath(__file__))
pat = re.compile(r"^spatial_(cpu|gpu)_(.+)_r(\d+)_results\.json$")
rows = []
meta = {}
for f in sorted(glob.glob(os.path.join(RES, "spatial_*_results.json"))):
    m = pat.match(os.path.basename(f))
    if not m:
        continue
    pipe, plat, rep = m.group(1), m.group(2), int(m.group(3))
    d = json.load(open(f))
    md = d["metadata"]
    meta[(pipe, plat, rep)] = dict(ts=md.get("timestamp"), n_cpus=md.get("n_cpus"),
                                   nclu=d["results_summary"].get("n_clusters"),
                                   gpu=md.get("gpu_info", {}))
    for step, t in d["timings"].items():
        rows.append(dict(platform=plat, pipeline=pipe, rep=rep, step=step, seconds=t,
                         n_clusters=d["results_summary"].get("n_clusters"),
                         timestamp=md.get("timestamp"), n_cpus=md.get("n_cpus")))
with open(os.path.join(HERE, "f01_spatial_repeats.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def get(plat, pipe, step, reps):
    v = [r["seconds"] for r in rows if r["platform"] == plat and r["pipeline"] == pipe
         and r["step"] == step and r["rep"] in reps]
    return v

out = []
for plat in sorted({r["platform"] for r in rows}):
    print("=" * 70, plat)
    for k in sorted(meta):
        if k[1] == plat:
            print("  ", k[0], "r%d" % k[2], meta[k]["ts"], "n_cpus", meta[k]["n_cpus"], "n_clusters", meta[k]["nclu"])
    for step in ["total", "co_occurrence", "spatial_autocorr_moran", "spatial_autocorr_geary", "umap", "pca"]:
        c_all = get(plat, "cpu", step, range(1, 6)); g_all = get(plat, "gpu", step, range(1, 6))
        if not c_all or not g_all or min(c_all) < 0 or min(g_all) < 0:
            print("  ", step, "skipped/neg", c_all, g_all); continue
        c25, g25 = get(plat, "cpu", step, range(2, 6)), get(plat, "gpu", step, range(2, 6))
        c1, g1 = get(plat, "cpu", step, [1])[0], get(plat, "gpu", step, [1])[0]
        s25 = st.mean(c25) / st.mean(g25); s15 = st.mean(c_all) / st.mean(g_all); s1 = c1 / g1
        print(f"   {step:24s} CPU r1={c1:9.2f} r2-5={st.mean(c25):9.2f} | GPU r1={g1:7.2f} r2-5={st.mean(g25):7.2f} "
              f"| speedup r2-5={s25:8.1f} r1-5={s15:8.1f} r1only={s1:8.1f}")
        print("      CPU per rep:", [round(x, 2) for x in c_all], " GPU per rep:", [round(x, 3) for x in g_all])
        out.append(dict(platform=plat, step=step, cpu_r1=c1, cpu_r2_5=st.mean(c25), cpu_r1_5=st.mean(c_all),
                        gpu_r1=g1, gpu_r2_5=st.mean(g25), gpu_r1_5=st.mean(g_all),
                        speedup_r2_5=s25, speedup_r1_5=s15, speedup_r1=s1))
with open(os.path.join(HERE, "f01_spatial_speedup_conventions.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
