"""Costruisce tracks/E_findings.json (track E, citazioni).

Uso: python3 -I build_E_findings.py <cartella review>
Verifica che ogni locator (tranne le chiavi bib) sia una sottostringa esatta della riga indicata
del manoscritto e che ogni riga di inv_E.json abbia un esito.
"""
import json
import sys
from collections import Counter
from pathlib import Path

REV = Path(sys.argv[1])
MD = (REV / "full_paper_LNBI.md").read_text().split("\n")
INV = json.loads((REV / "tracks" / "inv_E.json").read_text())
SEC = {r["id"]: r["section"] for r in INV}
W = "tracks/E_work/"
EV1 = W + "web_evidence_part1.txt"
EV2 = W + "web_evidence_part2.txt"
PDF = W + "pdf_txt/"

F = []


def add(inv_id, line, locator, claimed, recomputed, status, severity, source, note, section=None):
    if section is None:
        section = SEC.get(inv_id, "") if inv_id else ""
    F.append({"inv_id": inv_id, "track": "E", "line": line, "section": section,
              "locator": locator, "claimed": claimed, "recomputed": recomputed,
              "status": status, "severity": severity, "source": source, "note": note})


# ---------------------------------------------------------------------------
# 1. Verifica di contenuto: una voce per riga di inv_E.json
# ---------------------------------------------------------------------------
add("A0004", 8, "`{luca.vedovelli,corrado.lanera,daniele.sabbatini,dario.gregori}@ubep.unipd.it`",
    "citazione [@ubep] (estratta dall'inventario)",
    "Non e' una citazione: '@ubep' e' parte di un indirizzo email dentro codice inline; pandoc-citeproc non la risolve come chiave.",
    "PASS", "info", "full_paper_LNBI.md riga 8", "Falso positivo dell'estrattore; nessuna azione.")

add("A0013", 22, "Single-cell RNA sequencing has become the standard technology for dissecting cellular heterogeneity in complex tissues [@Regev2017].",
    "scRNA-seq e' la tecnologia standard per la eterogeneita' cellulare [Regev2017]",
    "Regev2017 (Science Forum eLife 2017, descrive un progetto proposto) dice che scRNA-seq e' 'rapidly becoming widely disseminated' e 'the first single-cell genomic characterization method to become feasible at large-scale'; non dice che sia lo standard.",
    "UNSUPPORTED", "minor", "https://elifesciences.org/articles/27041 (" + EV2 + ")",
    "Fonte del 2017 piu' debole dell'affermazione; citare una review recente (es. Heumos2023) o attenuare.")

add("A0014", 23, "Recent atlas-scale projects such as the Human Cell Atlas [@Regev2017], Tabula Sapiens [@TabulaSapiens2022], and the Allen Brain Atlas [@Yao2023] routinely generate datasets",
    "HCA, Tabula Sapiens e Allen Brain Atlas generano dataset da centinaia di migliaia a milioni di cellule",
    "TabulaSapiens2022: ~500,000 cellule (PASS). Yao2023: scRNA-seq 'around 7 million cells', MERFISH ~4.3 milioni (PASS). Regev2017: progetto proposto, nessun dataset riportato (non supporta 'routinely generate').",
    "UNSUPPORTED", "minor", "Crossref abstract 10.1126/science.abl4896, 10.1038/s41586-023-06812-z; elifesciences.org/articles/27041 (" + EV1 + ", " + EV2 + ")",
    "Per HCA citare un dataset o il portale HCA, non il white paper. Yao2023 e' l'atlante Allen dell'intero cervello murino (Allen Brain Cell Atlas); 'Allen Brain Atlas' indica di solito l'atlante ISH del 2007.")

add("A0015", 24, "The dominant analysis framework, Scanpy [@Wolf2018], executes on CPU and relies on NumPy, SciPy, and scikit-learn",
    "Scanpy, framework dominante, gira su CPU e si basa su NumPy, SciPy, scikit-learn",
    "Wolf2018: 'SCANPY's core relies on NUMPY, SCIPY, MATPLOTLIB, PANDAS, and H5PY'; 'Parts of the toolkit rely on SCIKIT-LEARN'. 'Dominant' non e' nella fonte.",
    "PASS", "info", "https://genomebiology.biomedcentral.com/articles/10.1186/s13059-017-1382-0 (" + EV2 + ")",
    "'Dominant' e' un giudizio non citato (Seurat e' almeno altrettanto diffuso); valutare 'widely used'.")

add("A0016", 25, "Leiden clustering [@Traag2019], uniform manifold approximation and projection (UMAP) [@McInnes2018], and differential expression (DE) testing, can require hours to days",
    "Traag2019 e McInnes2018 come riferimenti dei metodi Leiden e UMAP",
    "Traag2019: 'We prove that the Leiden algorithm yields communities that are guaranteed to be connected.' McInnes2018: 'UMAP is a dimension reduction technique'. Citazioni di metodo corrette.",
    "PASS", "info", "nature.com/articles/s41598-019-41695-z; joss.theoj.org/papers/10.21105/joss.00861.pdf (" + EV2 + ")",
    "'hours to days' non e' sostenuto da alcuna citazione: nei dati propri la CPU a 1.3M impiega 14.5 h, di cui 93.5% DE (vedi finding su riga 183).")

add("A0017", 28, "spatial analysis pipelines built on Squidpy [@Palla2022] add computationally intensive operations such as spatial autocorrelation (Moran's I, Geary's C), co-occurrence analysis",
    "Squidpy offre autocorrelazione spaziale (Moran, Geary), co-occorrenza, neighbourhood enrichment",
    "Palla2022: 'In Squidpy, we implement two spatial autocorrelation statistics: Moran's I and Geary's C.'; 'Cluster co-occurrence ratio'; neighborhood enrichment permutazionale.",
    "PASS", "info", "https://www.nature.com/articles/s41592-021-01358-2 (" + EV2 + ")",
    "La parte 'up to 6.3 million 2 um bins' della stessa frase non e' citata ed e' errata: finding separato su riga 28.")

add("A0018", 32, "rapids-singlecell [@Dicks2026] offers a near-drop-in replacement for Scanpy that executes the same analytical pipeline on NVIDIA GPUs via cuML, cuGraph, and CuPy.",
    "RAPIDS fornisce primitive GPU; rapids-singlecell e' un sostituto quasi drop-in di Scanpy via cuML, cuGraph, CuPy",
    "Dicks2026: 'near drop-in GPU replacements for core scanpy-based analysis steps', costruito su CuPy, cuML (PCA, UMAP), cuGraph (Leiden), cuVS. Pagina RAPIDS/CUDA-X: cuDF, cuML, cuGraph, Dask.",
    "PASS", "info", PDF + "2603.02402v1.txt righe 20-120; developer.nvidia.com/topics/ai/data-science/cuda-x-for-data-science",
    "")

add("A0019", 33, "including single-cell pipelines [@Nolet2022], and proposed GPU frameworks for datasets exceeding ten million cells [@Hu2025].",
    "speedup GPU in genomica, in single-cell, framework GPU oltre 10M cellule",
    "TaylorWeiner2019 abstract: runtime ridotto >200 volte. Nolet2022: 1.3M cellule, 951 s su 1 V100 e 365 s su 8 V100 contro >4 h CPU. Hu2025 abstract: 'handling datasets of 10-20 million cells' su una A100.",
    "PASS", "info", "Crossref 10.1186/s13059-019-1836-7 e 10.1093/bioadv/vbaf167; " + PDF + "2022.05.26.493607v1.full.txt Table 1",
    "Le stesse fonti contraddicono la frase successiva sulla novita' (finding su riga 34).")

add("A0020", 35, "but their study was limited to a single GPU and did not explore multi-GPU configurations or stress-test hardware limits",
    "Gardner2025 limitato a una GPU, senza multi-GPU ne' stress test",
    "Gardner2025: H100 80 GB, nessun esperimento multi-GPU; future work: 'multi-GPU execution for datasets with > 10^7 cells'; range 50k-1.2M cellule.",
    "PASS", "info", PDF + "3731599.3767378.txt righe 150-260, 610-660",
    "Corretto sul perimetro, ma il testo omette il risultato principale di Gardner2025 (ARI CPU-GPU ~0.50, 'not interchangeable'): finding separato su riga 244.")

add("A0024", 53, "All single-cell experiments used the 10x Genomics 1.3-million mouse brain cell dataset (E18) [@Zheng2017]",
    "Il dataset 1.3M E18 di 10x Genomics e' descritto in Zheng2017",
    "Zheng2017 (abstract Crossref): sistema a goccioline, ~250k cellule su 29 campioni, 68k PBMC, chimerismo; nessun dataset 1.3M di cervello E18. Nolet2022 e Dicks2026 citano il dataset come risorsa 10x Genomics (2017), URL 10xgenomics.com/datasets/1-3-million-brain-cells-from-e-18-mice-2-standard-1-3-0.",
    "UNSUPPORTED", "major", "api.crossref.org/works/10.1038/ncomms14049; " + PDF + "2603.02402v1.txt (ref. 17); " + PDF + "2022.05.26.493607v1.full.txt (ref. 21)",
    "Attribuzione errata del dataset; citare la pagina dataset 10x Genomics (2017) o l'application note. Vedi anche finding su riga 53 per i dataset dello stress test.")

add("A0027", 61, "Both the CPU and GPU pipelines implemented the standard Scanpy best-practices workflow [@Luecken2019; @Heumos2023] with identical parameters.",
    "la pipeline segue le best practice di Luecken2019 e Heumos2023",
    "Luecken2019: 'We recommend scran for normalization of non-full-length datasets'; 'We prefer not to scale gene expression'. La pipeline usa normalize_total(1e4)+log1p e scaling con max_value 10 (Table 1). Heumos2023: testo non raggiungibile (nature.com client_error).",
    "UNSUPPORTED", "minor", "link.springer.com/article/10.15252/msb.20188746 (" + EV2 + "); /tmp/repo/scripts/benchmark_cpu.py righe 183-197",
    "Il flusso e' quello del tutorial standard di Scanpy, non le raccomandazioni delle fonti; riformulare ('standard Scanpy workflow, cfr.').")

add("A0028", 62, "The CPU pipeline used Scanpy 1.12 [@Wolf2018] with NumPy 2.2.6 and the igraph Leiden backend (igraph 1.0.0); the GPU pipeline used rapids-singlecell 0.14.1 [@Dicks2026]",
    "Wolf2018 per Scanpy, Dicks2026 per rapids-singlecell",
    "Citazioni primarie corrette; la documentazione rapids-singlecell raccomanda Dicks et al. 2026 (arXiv).",
    "PASS", "info", "rapids-singlecell.scverse.org/en/stable; genomebiology Wolf2018",
    "Dicks2026 ha usato rsc 0.13.5; qui 0.14.1: nessun problema.")

add("A0029", 63, "Both pipelines shared the AnnData format [@Virshup2024] for data interchange.",
    "AnnData [Virshup2024]", "Virshup2024: 'anndata: Access and store annotated data matrices', JOSS 9(101) 4371.",
    "PASS", "info", "api.crossref.org/works/10.21105/joss.04371", "")

add("A0036", 74, "On log-normalised data [@Satija2015; @Yip2019]",
    "HVG metodo Seurat v1 su dati log-normalizzati [Satija2015; Yip2019]",
    "Satija2015 Methods: media e dispersione (varianza/media) per gene, 20 bin per espressione media, z-normalizzazione della dispersione nei bin. Docstring scanpy: flavor 'seurat' riproduce Satija2015 e 'Expects logarithmized data'. Yip2019 abstract: confronto di 7 metodi HVG incluso Seurat. Script: flavor di default ('seurat').",
    "PASS", "info", "dspace.mit.edu/bitstream/1721.1/105746/1/Regev_Spatial%20reconstruction.pdf; github scanpy _highly_variable_genes.py; /tmp/repo/scripts/benchmark_cpu.py riga 197",
    "")

add("A0040", 78, "igraph (CPU) / cuGraph (GPU) [@Traag2019]",
    "Leiden [Traag2019]", "Traag2019 definisce l'algoritmo Leiden (abstract letto).",
    "PASS", "info", "nature.com/articles/s41598-019-41695-z",
    "Incoerenza interna (non di citazione): righe 399 e 430 attribuiscono la CPU a 'leidenalg', ma benchmark_cpu.py riga 238 e SPATIAL/scripts/benchmark_spatial_cpu.py riga 335 usano flavor='igraph'.")

add("A0041", 79, "2D embedding [@McInnes2018]", "UMAP [McInnes2018]",
    "McInnes2018 (JOSS): 'UMAP is a dimension reduction technique'.", "PASS", "info",
    "joss.theoj.org/papers/10.21105/joss.00861.pdf", "")

add("A0042", 80, "On Leiden r = 1.0 clusters [@Soneson2018]",
    "test DE Wilcoxon contestualizzato con Soneson2018",
    "Soneson2018 (abstract bioRxiv v1): valutazione di 30 approcci DE su scRNA-seq; Supplementary Table 2 include 'Wilcoxon'.",
    "PASS", "info", "biorxiv.org/content/10.1101/143289v1; Supplementary 41592_2018_BFnmeth4612_MOESM1_ESM.pdf",
    "Testo principale non raggiungibile; la citazione regge come contesto generale.")

add("A0044", 87, "we employed a hybrid multi-GPU pipeline using Dask-CUDA [@Rocklin2015].",
    "Dask-CUDA [Rocklin2015]",
    "Rocklin2015 descrive Dask (algoritmi a blocchi, scheduling, out-of-core su CPU); nessuna menzione di GPU o CUDA. Dask-CUDA e' un progetto RAPIDS successivo.",
    "UNSUPPORTED", "minor", PDF + "Majora-7b98e3ed-013.txt (abstract, grep gpu/cuda)",
    "Scrivere 'Dask [@Rocklin2015] con Dask-CUDA [@RAPIDS2024]'.")

add("A0050", 94, "The panel follows the metric families adopted in published scRNA-seq method benchmarks [@Tian2019; @Duo2020; @Luecken2022]",
    "le famiglie di metriche seguono Tian2019, Duo2020, Luecken2022",
    "Luecken2022: ARI, NMI, HVG conservation (tra 14 metriche). Duo2020: ARI tra partizioni e stabilita' tra run. Tian2019: benchmark di clustering (abstract). kNN Jaccard, |rho| dei loading PCA e rho dei logFC non compaiono in queste fonti.",
    "PASS", "info", "nature.com/articles/s41592-021-01336-8; f1000research.com/articles/7-1141/v3; publications.wehi.edu.au/Publications/14963",
    "Supporto parziale ma accettabile per ARI/NMI; per kNN Jaccard citare Gardner2025 o Nolet2022, che la usano.")

add("A0055", 102, "Mean per-cell Jaccard overlap of k-nearest-neighbour sets (k = 15) [@Luecken2022]",
    "kNN Jaccard definita in Luecken2022",
    "Luecken2022 usa 14 metriche (PCR batch, ASW, graph connectivity, iLISI, kBET, NMI, ARI, cLISI, isolated label F1/ASW, cell-cycle, HVG conservation, trajectory); nessuna e' una Jaccard sui vicini kNN; 'Jaccard' non compare nel testo.",
    "UNSUPPORTED", "minor", "https://www.nature.com/articles/s41592-021-01336-8 (" + EV1 + ")",
    "Sostituire con Gardner2025 (usa 'kNN Jaccard') o Nolet2022 (percentuale di vicini conservati), entrambi gia' in bibliografia.")

add("A0056", 103, "Adjusted Rand Index of Leiden cluster assignments, adjusted for chance [@Hubert1985]",
    "ARI [Hubert1985]",
    "Testo non letto: link.springer.com client_error, Crossref e OpenAlex senza abstract. Metadati confermati (J Classif 2(1):193-218).",
    "UNVERIFIABLE", "info", "api.crossref.org/works/10.1007/BF01908075; api.openalex.org/works/doi:10.1007/BF01908075",
    "Attribuzione canonica, ma per regola non verificata in questa sessione.")

add("A0057", 104, "Normalised Mutual Information of cluster assignments [@Vinh2010]",
    "NMI [Vinh2010]",
    "Vinh2010 abstract: studio organizzato delle misure informazionali per confrontare clustering, 'importance of correcting information theoretic measures for chance', raccomanda NID.",
    "PASS", "info", "https://jmlr.org/papers/v11/vinh10a.html",
    "La Table 2 non dice quale normalizzazione di NMI e' usata (default sklearn: media aritmetica); Vinh2010 raccomanda varianti corrette per il caso.")

add("A0058", 105, "Spearman rho of log-fold-changes for top 100 DE genes per cluster, after Hungarian matching [@Soneson2018]",
    "metrica rho logFC top100 con matching ungherese attribuita a Soneson2018",
    "Testo principale non raggiungibile (nature.com client_error, bioRxiv full client_error, PMC reCAPTCHA). Abstract e Supplementary non menzionano Spearman sui logFC ne' matching ungherese.",
    "UNVERIFIABLE", "minor", "biorxiv.org/content/10.1101/143289v1; Supplementary MOESM1 (" + EV2 + ")",
    "Probabile metrica definita dagli autori: presentarla come propria e citare Kuhn (1955) per il metodo ungherese.")

add("A0065", 115, "Pseudo-bulk aggregation summed raw counts by donor x cluster, normalised to counts per million, log-transformed, and applied the Wilcoxon test on the aggregated matrix [@Squair2021].",
    "pseudo-bulk + Wilcoxon su logCPM tra cluster, come in Squair2021",
    "Squair2021: pseudobulk con edgeR, DESeq2, limma; Wilcoxon valutato solo come metodo single-cell; ambito 'to compare cells of the same type between experimental conditions'; 'We did not annotate methods used to identify genes differentially expressed between cell types'. Lo script confronta cluster (marker) con Wilcoxon su 2,431 pseudo-campioni (202 donatori, 81 cluster).",
    "UNSUPPORTED", "major", "nature.com/articles/s41467-021-25960-2 (" + EV2 + "); /tmp/repo/scripts/test_de_benchmark.py righe 619-740; results/de_benchmark_pseudobulk.json",
    "Squair2021 non sostiene questo disegno (test e confronto); dichiarare che e' un proxy computazionale. Il docstring dello script ammette che l'implementazione completa userebbe DESeq2/edgeR.")

add("A0080", 140, "The CPU baseline used Scanpy 1.12 for expression steps and Squidpy 1.8.1 [@Palla2022] for spatial steps.",
    "Squidpy [Palla2022]", "Palla2022 e' la citazione primaria di Squidpy (funzioni spaziali confermate).",
    "PASS", "info", "nature.com/articles/s41592-021-01358-2", "Metadati bib errati: vedi voce Palla2022.")

add("A0090", 160, "with Squidpy 1.8.1 [@Palla2022] and spatialdata [@Marconato2024] added on top for the spatial pipeline.",
    "Squidpy e SpatialData", "Marconato2024 abstract: SpatialData, formato e framework per dati spatial omics; Palla2022 Squidpy.",
    "PASS", "info", "api.crossref.org/works/10.1038/s41592-024-02212-x; nature.com Squidpy",
    "Metadati bib di entrambe le voci errati (autori): vedi voci bibliografiche.")

add("A0097", 173, "We note that GPU floating-point arithmetic is non-deterministic due to non-associative parallel reductions [@Shanmugavelu2024; @Collange2015]",
    "l'aritmetica GPU e' non deterministica per riduzioni non associative",
    "Collange2015: le riduzioni 'may become non-deterministic' per la non associativita', su architetture multi-core, many-core ed eterogenee (non solo GPU). Shanmugavelu2024: variabilita' da non associativita' 'coupled with asynchronous parallel operations' (atomiche), con alternative deterministiche disponibili.",
    "UNSUPPORTED", "minor", PDF + "1-s2.0-S0167819115001155-main.txt abstract; " + PDF + "Impacts_of_floating-point_non-associativity_on_reproducibility_for_HPC_and_deep_learning_applications.txt abstract e intro",
    "Le fonti dicono 'puo' essere' e solo per riduzioni asincrone; inoltre la divergenza CPU-GPU misurata dalle metriche di concordanza deriva soprattutto da algoritmi diversi (kNN approssimato vs esatto, implementazioni Leiden), non dal non determinismo. Riformulare.")

add("A0140", 232, "only the PCA and neighbour steps benefit from additional GPUs, a classic instance of Amdahl's law [@Amdahl1967].",
    "scaling sublineare come istanza della legge di Amdahl",
    "Amdahl1967: 'The nature of this overhead appears to be sequential so that it is unlikely to be amenable to parallel processing techniques. Overhead alone would then place an upper limit on throughput'.",
    "PASS", "info", "www3.cs.stonybrook.edu/~rezaul/Spring-2019/CSE613/reading/Amdahl-1967.pdf", "")

add("A0149", 244, "These concordance levels are consistent with the range of inter-method variation reported in mixture-control benchmarks of scRNA-seq analysis pipelines [@Tian2019]",
    "ARI 0.908-0.963 coerenti con la variazione tra metodi in Tian2019 e Duo2020; pipeline intercambiabili",
    "Duo2020: 'substantial differences in the performance, run time and stability between the methods', ARI tra metodi solo in dendrogramma, nessun confronto tra implementazioni dello stesso algoritmo. Tian2019: risultati ARI non letti (solo abstract). Gardner2025, sullo stesso dataset e con Scanpy vs RAPIDS: ARI ~0.50 e 'they are not interchangeable'.",
    "UNSUPPORTED", "major", "f1000research.com/articles/7-1141/v3; publications.wehi.edu.au/Publications/14963; " + PDF + "3731599.3767378.txt righe 410-560",
    "Il confronto con la variazione tra metodi diversi non sostiene l'intercambiabilita' di due implementazioni; la conclusione va temperata e confrontata con Gardner2025.")

add("A0174", 267, "Inspired by the chunked-preprocessing strategy of ScaleSC [@Hu2025], we also implemented a third variant",
    "strategia di preprocessing a blocchi di ScaleSC",
    "Hu2025 (bioRxiv 10.1101/2025.01.28.635256): 'split the dataset into chunks along cells'; 'In HVG, two loops of all chunks are needed: the first loop obtains mean and variance'; 'We can calculate X^T X by simply adding up all chunks.'",
    "PASS", "info", "biorxiv.org/content/10.1101/2025.01.28.635256.full.pdf (" + EV1 + ")",
    "Dettagli letti nel preprint; la versione pubblicata (PMC12321287) era bloccata da reCAPTCHA, ma l'abstract pubblicato e' coerente.")

add("A0277", 416, "Leiden clustering on small graphs is limited by low arithmetic intensity: consistent with the roofline model [@Williams2009], cuGraph's constant-time overhead exceeds CPU's short runtime",
    "il modello roofline spiega l'overhead costante di cuGraph su grafi piccoli",
    "Williams2009: limite di prestazione in regime stazionario, 'Attainable GFlops/sec = min(Peak FP Performance, Peak Memory Bandwidth x Operational Intensity)', intensita' operativa = 'operations per byte of DRAM traffic'; nessuna trattazione di overhead fissi, kernel launch o problemi piccoli.",
    "UNSUPPORTED", "major", "www.cs.colostate.edu/~cs475/f19/more_assignments/Labs/L10/RooflineCACM2009.pdf (" + EV1 + ")",
    "Il roofline non modella la latenza/overhead costante: la spiegazione corretta e' l'overhead di lancio e di setup, non l'intensita' aritmetica. Togliere la citazione o riformulare. Dicks2026 riporta lo stesso effetto sotto ~50k cellule ('kernel launch overhead and host-device memory transfers').")

add("A0281", 418, "This imbalance represents a classic manifestation of Amdahl's law [@Amdahl1967], where the non-parallelised fraction dominates overall speedup.",
    "frazione non parallelizzata domina lo speedup (Amdahl)",
    "Amdahl1967 sostiene che l'overhead sequenziale pone un limite superiore al throughput.",
    "PASS", "info", "Amdahl-1967.pdf (ristampa IEEE SSCS News)",
    "La frase precedente chiama il preprocessing CPU 'inherently sequential', in contrasto con Methods riga 88 e Limitations (vincolo dello stack software; gira su 100 core).")

add("A0291", 422, "entirely consistent with the algorithm's inherent stochasticity across implementations (igraph vs cuGraph) and with published benchmarks of clustering variability in scRNA-seq workflows [@Duo2020]",
    "ARI coerenti con la variabilita' del clustering documentata da Duo2020",
    "Duo2020 non confronta implementazioni dello stesso algoritmo e non tratta Leiden/Louvain; per Seurat (grafo) riporta 'returned the same clusters in all five instances'.",
    "UNSUPPORTED", "minor", "f1000research.com/articles/7-1141/v3 (" + EV1 + ")",
    "Stesso problema di A0149; Gardner2025 sarebbe la fonte pertinente (e indica concordanza piu' bassa).")

add("A0303", 426, "it avoids pseudoreplication and properly accounts for inter-donor variability [@Squair2021]",
    "pseudo-bulk evita la pseudoreplicazione e tiene conto della variabilita' tra donatori",
    "Squair2021: 'Statistical methods for differential expression must account for the intrinsic variability of biological replicates'; pseudobulk con la massima fedelta' alla verita' sperimentale; 'pseudobulk methods required only minutes per cell type'.",
    "PASS", "minor", "nature.com/articles/s41467-021-25960-2 (" + EV2 + ")",
    "La citazione regge; ma 'Our DE benchmark confirms' e' eccessivo: il benchmark misura solo tempi e confronta cluster, ambito escluso da Squair2021.")

add("A0307", 426, "pseudo-bulk methods coupled with proper count-based models (DESeq2, edgeR) are the gold standard for multi-donor experiments [@Squair2021]",
    "pseudo-bulk + DESeq2/edgeR gold standard",
    "Squair2021: 'pseudobulk methods achieve the highest fidelity to the experimental ground truth' con edgeR, DESeq2, limma. 'Gold standard' nella fonte indica solo 18 dataset di riferimento.",
    "PASS", "info", "nature.com/articles/s41467-021-25960-2",
    "Coerenza interna: il pseudo-bulk del paper usa Wilcoxon su logCPM, non DESeq2/edgeR; le Conclusioni lo chiamano 'most statistically rigorous'.")

add("A0336", 441, "as single-cell and spatial datasets grow toward the billion-cell and billion-bin scales [@Regev2017].",
    "verso scale da miliardi di cellule e di bin [Regev2017]",
    "Regev2017 non indica un obiettivo numerico di cellule (cita ~10^11 neuroni del cervello umano) e non tratta bin spaziali.",
    "UNSUPPORTED", "minor", "elifesciences.org/articles/27041 (" + EV2 + ")",
    "Togliere 'billion-bin' o citare una fonte pertinente; per scale >100M cellule c'e' Tahoe-100M (citato in Dicks2026).")

# ---------------------------------------------------------------------------
# 2. Verifica dei metadati: una voce per chiave bib
# ---------------------------------------------------------------------------
BIB_LINE = {"Wolf2018": 24, "Dicks2026": 32, "Virshup2024": 63, "Traag2019": 25, "McInnes2018": 25,
            "Rocklin2015": 87, "RAPIDS2024": 32, "Zheng2017": 53, "Nolet2022": 33, "Gardner2025": 35,
            "Hu2025": 33, "Tian2019": 94, "Shanmugavelu2024": 173, "Collange2015": 173, "Hubert1985": 103,
            "Vinh2010": 104, "Luecken2022": 94, "Duo2020": 94, "TaylorWeiner2019": 33, "Williams2009": 416,
            "TabulaSapiens2022": 23, "Regev2017": 22, "Luecken2019": 61, "Heumos2023": 61, "Soneson2018": 80,
            "Squair2021": 115, "Yip2019": 74, "Yao2023": 23, "Satija2015": 74, "Palla2022": 28,
            "Marconato2024": 160, "Amdahl1967": 232}


def bib(key, claimed, recomputed, status, severity, source, note):
    add(None, BIB_LINE[key], key, claimed, recomputed, status, severity, source, note, section="Bibliografia")


CR = "https://api.crossref.org/works/"
OA = "https://api.openalex.org/works/doi:"
bib("Wolf2018", "Wolf, Angerer, Theis; Genome Biology 19(1):15, 2018; doi 10.1186/s13059-017-1382-0",
    "Crossref: stessi autori, Genome Biol 19(1) article 15, 2018; nessun update o errata.", "PASS", "info",
    CR + "10.1186/s13059-017-1382-0", "")
bib("Dicks2026", "13 autori; arXiv preprint arXiv:2603.02402, 2026; doi 10.48550/arXiv.2603.02402",
    "OpenAlex e arxiv.org/abs: 13 autori coincidenti, solo v1 (2026-03-02), is_published false, nessun journal-ref al 2026-11-03. La documentazione rapids-singlecell raccomanda questa citazione; nessun DOI Zenodo.",
    "PASS", "info", OA + "10.48550/arXiv.2603.02402; https://arxiv.org/abs/2603.02402; rapids-singlecell.scverse.org",
    "Ancora preprint: va bene citarlo; togliere il commento '% VERIFY' dal .bib e ricontrollare prima della consegna.")
bib("Virshup2024", "Virshup et al.; JOSS 9(101):4371, 2024", "Crossref: identico (2024-09-16).", "PASS", "info",
    CR + "10.21105/joss.04371", "")
bib("Traag2019", "Traag, Waltman, van Eck; Sci Rep 9:5233, 2019", "Crossref: identico; issue 1 non riportato nel bib (non necessario).",
    "PASS", "info", CR + "10.1038/s41598-019-41695-z", "")
bib("McInnes2018", "McInnes, Healy, Saul, Grossberger; JOSS 3(29):861, 2018", "Crossref: identico.", "PASS", "info",
    CR + "10.21105/joss.00861", "Citazione del software JOSS; il metodo e' in arXiv:1802.03426, eventualmente da aggiungere.")
bib("Rocklin2015", "Rocklin; Proc. 14th Python in Science Conf., pp. 126-132, 2015; doi 10.25080/Majora-7b98e3ed-013",
    "Crossref: nessun record (client_error). OpenAlex: stesso titolo e autore, pp. 126-132, 2015. PDF locale: 'PROC. OF THE 14th PYTHON IN SCIENCE CONF. (SCIPY 2015)'.",
    "PASS", "info", OA + "10.25080/Majora-7b98e3ed-013; " + PDF + "Majora-7b98e3ed-013.txt", "")
bib("RAPIDS2024", "@misc RAPIDS Development Team, 'RAPIDS: Open GPU Data Science', 2024, url rapids.ai",
    "Nessun DOI ne' Zenodo trovato. rapids.ai ora reindirizza a developer.nvidia.com (CUDA-X Data Science), senza indicazioni di citazione. Dicks2026 cita 'RAPIDS Development Team. RAPIDS: Libraries for End to End GPU Data Science. https://rapids.ai (2023)'.",
    "MISMATCH", "minor", "https://rapids.ai/branding/ (redirect); developer.nvidia.com/topics/ai/data-science/cuda-x-for-data-science; " + PDF + "2603.02402v1.txt ref. 13",
    "Titolo non corrispondente alla forma usata dagli sviluppatori; per LNCS aggiungere versione (26.02) e data di ultimo accesso dell'URL.")
bib("Zheng2017", "33 autori; Nat Commun 8:14049, 2017", "Crossref: 33 autori coincidenti, article 14049, 2017.", "PASS", "info",
    CR + "10.1038/ncomms14049", "Metadati corretti; l'uso nel testo e' errato (A0024).")
bib("Nolet2022", "Nolet et al.; bioRxiv 2022; doi 10.1101/2022.05.26.493607",
    "Crossref: posted-content preprint 2022-05-28, relation vuota; OpenAlex: solo bioRxiv, non pubblicato.", "PASS", "info",
    CR + "10.1101/2022.05.26.493607; " + OA + "10.1101/2022.05.26.493607", "Nessuna versione pubblicata da sostituire.")
bib("Gardner2025", "6 autori; Proc. SC '25 Workshops, ACM, 2025; senza pagine",
    "Crossref: 6 autori coincidenti, Proc. SC '25 Workshops, ACM, pp. 349-358, 2025-11-15, St. Louis.", "MISMATCH", "minor",
    CR + "10.1145/3731599.3767378", "Mancano le pagine 349-358 (richieste da splncs04 per inproceedings).")
bib("Hu2025", "9 autori; Bioinformatics Advances 5(1):vbaf167, 2025",
    "Crossref: 9 autori coincidenti, 5(1) vbaf167, online 2025-07-17; ha preprint 10.1101/2025.01.28.635256 (citata correttamente la versione pubblicata).",
    "PASS", "info", CR + "10.1093/bioadv/vbaf167", "")
bib("Tian2019", "12 autori; Nat Methods 16:479-487, 2019", "Crossref: identico, issue 6.", "PASS", "info",
    CR + "10.1038/s41592-019-0425-8", "")
bib("Shanmugavelu2024", "6 autori; booktitle 'Proceedings of the SC '24 Workshops ... (CORRECTNESS 2024)', 2024; senza pagine ne' editore",
    "Crossref: 6 autori coincidenti; container 'SC24-W: Workshops of the International Conference for High Performance Computing, Networking, Storage and Analysis', IEEE, pp. 170-179, 2024.",
    "MISMATCH", "minor", CR + "10.1109/SCW63240.2024.00028; " + PDF + "Impacts_of_floating-point_non-associativity_on_reproducibility_for_HPC_and_deep_learning_applications.txt",
    "Allineare booktitle a Crossref, aggiungere pp. 170-179 e publisher IEEE.")
bib("Collange2015", "4 autori; Parallel Computing 49:83-97, 2015",
    "Crossref client_error; OpenAlex e PDF locale: identico, non ritrattato.", "PASS", "info",
    OA + "10.1016/j.parco.2015.09.001; " + PDF + "1-s2.0-S0167819115001155-main.txt", "")
bib("Hubert1985", "Hubert, Arabie; J Classif 2(1):193-218, 1985", "Crossref: identico.", "PASS", "info",
    CR + "10.1007/BF01908075", "")
bib("Vinh2010", "Vinh, Epps, Bailey; JMLR 11:2837-2854, 2010; url",
    "jmlr.org: identico, JMLR 11(95) 2837-2854; JMLR non assegna DOI.", "PASS", "info",
    "https://jmlr.org/papers/v11/vinh10a.html", "")
bib("Luecken2022", "11 autori; Nat Methods 19(1):41-50, 2022", "Crossref: identico (online 2021-12-23, stampa 2022-01).",
    "PASS", "info", CR + "10.1038/s41592-021-01336-8", "")
bib("Duo2020", "Duo, Robinson, Soneson; F1000Research 7:1141, 2020; doi versione 3",
    "Crossref: v3 (doi .15666.3) issued 2020-11-16, volume 7, 1141.", "PASS", "info",
    CR + "10.12688/f1000research.15666.3", "")
bib("TaylorWeiner2019", "9 autori; Genome Biol 20:228, 2019", "Crossref: identico.", "PASS", "info",
    CR + "10.1186/s13059-019-1836-7", "")
bib("Williams2009", "Williams, Waterman, Patterson; CACM 52(4):65-76, 2009", "Crossref: identico.", "PASS", "info",
    CR + "10.1145/1498765.1498785", "")
bib("TabulaSapiens2022", "The Tabula Sapiens Consortium; Science 376(6594):eabl4896, 2022", "Crossref: identico.",
    "PASS", "info", CR + "10.1126/science.abl4896", "")
bib("Regev2017", "61 autori; eLife 6:e27041, 2017",
    "Crossref: 61 individui (coincidenti) piu' 'Human Cell Atlas Meeting Participants'; eLife 6 e27041, 2017-12-05.",
    "PASS", "info", CR + "10.7554/eLife.27041", "Manca solo l'autore collettivo; opzionale.")
bib("Luecken2019", "Luecken, Theis; Mol Syst Biol 15(6):e8746, 2019", "Crossref: identico.", "PASS", "info",
    CR + "10.15252/msb.20188746", "")
bib("Heumos2023", "13 voci autore incluso consorzio; Nat Rev Genet 24(8):550-572, 2023",
    "Crossref: identico per i primi 10, consorzio, Schiller, Theis (i 31 membri del consorzio sono omessi, accettabile).",
    "PASS", "info", CR + "10.1038/s41576-023-00586-w", "")
bib("Soneson2018", "Soneson, Robinson; Nat Methods 15(4):255-261, 2018", "Crossref: identico.", "PASS", "info",
    CR + "10.1038/nmeth.4612", "")
bib("Squair2021", "14 autori; Nat Commun 12:5692, 2021", "Crossref: identico.", "PASS", "info",
    CR + "10.1038/s41467-021-25960-2", "")
bib("Yip2019", "Yip, Sham, Wang; Brief Bioinform 20(4):1583-1589, 2019", "Crossref: identico (online 2018-02-21).",
    "PASS", "info", CR + "10.1093/bib/bby011", "")
bib("Yao2023", "9 autori + others; Nature 624(7991):317-332, 2023",
    "Crossref: 101 autori, primi 9 coincidenti; Nature 624(7991) 317-332, 2023.", "PASS", "info",
    CR + "10.1038/s41586-023-06812-z", "'and others' produce et al. in splncs04: accettabile.")
bib("Satija2015", "5 autori; Nat Biotechnol 33(5):495-502, 2015", "Crossref: identico.", "PASS", "info",
    CR + "10.1038/nbt.3192", "")
bib("Palla2022", "12 autori: ... Holber, Olle; Virshup, Isaac; Pegno, Mohammad Nofallah; Theis; Nat Methods 19:171-178, 2022",
    "OpenAlex e nature.com: 13 autori: Palla, Spitzer, Klein, Fischer DS, Schaar, Kuemmerle, Rybakov, Ibarra, Holmberg O, Virshup, Lotfollahi M, Richter S, Theis; 19(2) 171-178, 2022.",
    "MISMATCH", "major", OA + "10.1038/s41592-021-01358-2; https://www.nature.com/articles/s41592-021-01358-2",
    "Autori errati: 'Holber' va corretto in 'Holmberg'; 'Pegno, Mohammad Nofallah' non esiste (sono Mohammad Lotfollahi e Sabrina Richter, mancanti). Aggiungere issue 2.")
bib("Marconato2024", "9 autori: Marconato, Palla, Yaber KA, Chierici A, Puente-Lelievre C, Nabavi S, Rattray M, Stegle, Theis; Nat Methods 22:58-62, 2024",
    "Crossref: 22 autori: Marconato, Palla, Yamauchi KA, Virshup, Heidari, Treis, Vierdag, Toth, Stockhaus, Shrestha, Rombaut, Pollaris, Lehner, Voehringer, Kats, Saeys, Saka, Huber, Gerstung, Moore, Theis, Stegle; 22(1) 58-62; online 2024-03-20, stampa 2025-01.",
    "MISMATCH", "major", CR + "10.1038/s41592-024-02212-x",
    "Cinque autori del bib non figurano tra gli autori (Chierici, Puente-Lelievre, Nabavi, Rattray; 'Yaber' al posto di Yamauchi); ordine sbagliato (Stegle ultimo). Anno: volume 22 e' 2025 in stampa; usare 2025 o lasciare 2024 coerente con la data online, ma non vol 22 con 2024 senza nota.")
bib("Amdahl1967", "Amdahl; Proc. AFIPS '67 Spring Joint Computer Conference, pp. 483-485, 1967",
    "Crossref: Proc. April 18-20, 1967, Spring Joint Computer Conference, ACM, p. 483; ristampa: AFIPS Conf. Proc. vol. 30, pp. 483-485.",
    "PASS", "info", CR + "10.1145/1465482.1465560; Amdahl-1967.pdf", "")

# ---------------------------------------------------------------------------
# 3. Mancanze e problemi di contesto bibliografico (inv_id null)
# ---------------------------------------------------------------------------
add(None, 34, "However, most benchmarks report headline speedups without systematically examining (i) per-step performance variation, (ii) multi-GPU scaling behaviour and its bottlenecks",
    "i benchmark precedenti non esaminano per-step, multi-GPU, concordanza numerica e limiti di memoria",
    "Nolet2022 (gia' citato): tempi per step su 1, 2, 4, 8 V100 sullo stesso dataset 1.3M e concordanza CPU-GPU (PCA |r|>=0.999, vicini conservati 95.66%). Gardner2025: speedup per step e concordanza (ARI). Hu2025: 13M cellule su una A100 (limiti di memoria). Dicks2026: per step su tre GPU e Tahoe-100M multi-GPU.",
    "MISMATCH", "major", PDF + "2022.05.26.493607v1.full.txt Table 1 e righe 230-245; " + PDF + "3731599.3767378.txt; " + PDF + "2603.02402v1.txt",
    "La cornice di novita' e' contraddetta da lavori gia' in bibliografia; riformulare la gap statement indicando cosa e' davvero nuovo (H100, DE a 3.4M, spatial, istrumentazione).",
    section="Introduction")

add(None, 88, "within that path only PCA and neighbour graph construction had distributed GPU implementations usable for the pipeline as configured here",
    "nel percorso Dask-CUDA solo PCA e vicini avevano implementazioni GPU distribuite",
    "Nolet2022: 'Filtering & Normalization' distribuito, 272 s su 1 V100 e 60.5 s su 8 V100. Dicks2026: integrazione Dask con 'log-normalization, highly variable gene (HVG) selection, scaling, PCA ...' su Tahoe-100M (100M cellule) in meno di 20 minuti su 8 B300. Hu2025: rapids-singlecell 'supports multi-GPU configurations with Dask arrays'.",
    "MISMATCH", "major", PDF + "2022.05.26.493607v1.full.txt Table 1; " + PDF + "2603.02402v1.txt righe 160-170, 440-450; biorxiv ScaleSC",
    "Il testo attribuisce il preprocessing su CPU allo stack disponibile, ma le fonti citate documentano preprocessing GPU distribuito e una capacita' di 100M cellule; serve un confronto esplicito, anche per il limite 11.9M dichiarato nell'abstract.",
    section="Data and Methods > Single-cell RNA-seq > Multi-GPU pipeline")

add(None, 244, "support the conclusion that GPU and CPU pipelines are interchangeable for biological interpretation",
    "pipeline GPU e CPU intercambiabili per l'interpretazione biologica",
    "Gardner2025 (citato solo per i limiti): stesso dataset 1.3M, Scanpy vs RAPIDS su H100, ARI CPU-GPU mediana 0.45-0.55 ('approximately 0.50') a tutte le taglie e conclusione 'demonstrates that they are not interchangeable'.",
    "MISMATCH", "major", PDF + "3731599.3767378.txt righe 400-560",
    "Il risultato contrario di una fonte citata non e' discusso; spiegare le differenze (Louvain vs Leiden, regressione, versioni) o attenuare la conclusione, anche in abstract e Discussion.",
    section="Results > Single-cell RNA-seq > CPU and GPU produce biologically concordant results")

add(None, 240, "though some variation in the k-nearest neighbours across the graph was expected due to floating-point precision differences",
    "differenze kNN dovute a precisione in virgola mobile",
    "Scanpy pp.neighbors: con transformer=None usa kNN esatto solo per dati piccoli (sorgente: n_obs < 4096, o metrica euclidea e n_obs < 8192), altrimenti PyNNDescent approssimato; a 10k cellule la CPU usa quindi PyNNDescent. rapids-singlecell pp.neighbors: default 'brute', 'guaranteeing exact results'. Gardner2025: 'approximate (NN-descent on CPU) versus exact (brute-force GPU) neighbor search methods can yield systematically different kNN graphs'. Gli script chiamano entrambe le funzioni con i default.",
    "UNSUPPORTED", "major", "scanpy.readthedocs.io pp.neighbors; github scanpy neighbors/__init__.py; rapids-singlecell.scverse.org pp.neighbors; /tmp/repo/scripts/benchmark_cpu.py riga 223, benchmark_gpu.py riga 296",
    "La kNN Jaccard 0.930 riflette soprattutto ricerca approssimata vs esatta, non la precisione numerica; correggere l'attribuzione e citare Gardner2025.",
    section="Results > Single-cell RNA-seq > CPU and GPU produce biologically concordant results")

add(None, 422, "contributes negligibly to observed differences, as the dominant source of variation is the Leiden algorithm's non-deterministic vertex ordering",
    "il contributo della non associativita' e' trascurabile; domina l'ordinamento dei vertici di Leiden",
    "Nessuna citazione e nessun esperimento a supporto (nel repo c'e' solo concordance_10000_r1.json, nessuna concordanza GPU vs GPU tra ripetizioni). Gardner2025: con seed fisso la GPU da' Leiden ARI mediana 0.927 tra run ripetuti. Dicks2026 attribuisce le differenze a ordine di accumulo e 'non-deterministic atomic operations'.",
    "UNSUPPORTED", "major", "/tmp/repo/results (ls); " + PDF + "3731599.3767378.txt righe 520-560; " + PDF + "2603.02402v1.txt righe 200-215",
    "Affermazione causale non dimostrata e in tensione con la riga 240 (che invoca la precisione numerica); togliere o sostenere con una misura GPU-GPU.",
    section="Discussion")

add(None, 416, "Normalisation and neighbour graph construction represent ideal GPU workloads, achieving speedups of 88-329x and 44-88x respectively, because they involve high arithmetic intensity",
    "normalizzazione ad alta intensita' aritmetica",
    "Williams2009: intensita' operativa = 'operations per byte of DRAM traffic'; 'a kernel with operational intensity 1.0 Flops/Byte is memory-bound'. Normalizzazione (divisione e log1p per elemento) ha poche operazioni per byte: e' un caso memory-bound; il vantaggio GPU viene dalla banda di memoria (H100 SXM 3.35 TB/s).",
    "MISMATCH", "major", "RooflineCACM2009.pdf (" + EV1 + "); nvidia.com/en-us/data-center/h100",
    "Contraddice il modello citato due frasi dopo; riformulare (alto parallelismo e banda, bassa intensita' aritmetica).",
    section="Discussion")

add(None, 28, "The 10x Genomics Visium HD platform generates up to 6.3 million 2 um bins per tissue section",
    "Visium HD: fino a 6.3 milioni di bin da 2 um per sezione",
    "Space Ranger glossary (10x Genomics): 'Visium HD capture areas contain a continuous grid of 2x2 um barcoded squares, ~11.2 million in total' (area 6.5 mm). 6.3 milioni e' il numero di bin del dataset usato, non il massimo della piattaforma.",
    "MISMATCH", "major", "https://www.10xgenomics.com/support/software/space-ranger/getting-started/space-ranger-glossary",
    "Affermazione senza citazione e numericamente errata; citare la documentazione 10x e distinguere dataset e piattaforma.",
    section="Introduction")

add(None, 420, "Single H100 GPUs are readily rentable on commercial cloud platforms at approximately USD 2 to 4 per hour",
    "H100 a 2-4 USD/h; l'analisi a 1.3M costa 'well under one dollar'",
    "Prezzo senza citazione. Ricalcolo dai JSON: media totale gpu8_1300000 r1-r5 = 435.18 s su 8 GPU = 0.967 GPU-ore, cioe' 1.93-3.87 USD a 2-4 USD/h, non 'well under one dollar'. A 1.3M la pipeline standard non entra in una H100 (Table 4).",
    "UNSUPPORTED", "major", "results/gpu8_1300000_r*_results.json timings.total; " + W + "scripts/e_numbers.py; " + W + "e_numbers_output.txt",
    "Citare una fonte di prezzo datata (listino del provider con data di accesso) e correggere il conto: o 8 GPU-ore frazionarie, o una misura single-GPU che a 1.3M non esiste.",
    section="Discussion")

add(None, 161, "the GPU components of the spatial pipeline failed on the cluster's driver (535.183.01), which caps CUDA runtime at 12.2",
    "il driver 535 limita il runtime CUDA a 12.2 e impedisce la pipeline spatial; con 550.x funziona",
    "CUDA 12.9 release notes: 12.2 GA richiede >=535.54.03, 12.4 GA >=550.54.14, 12.9 GA >=575.51.03; minor version compatibility CUDA 12.x da >=525.60.13. RAPIDS (release corrente): 'CUDA 12 with Driver 525.60.13 or newer'. Anche 550.x e' sotto la versione nativa di un'immagine CUDA 12 recente, quindi il 'cap a 12.2' non spiega da solo perche' 550 funzioni e 535 no.",
    "UNSUPPORTED", "major", "docs.nvidia.com/cuda/archive/12.9.0/cuda-toolkit-release-notes; docs.nvidia.com/datascience/install",
    "Spiegazione tecnica senza fonte e non coerente con la compatibilita' documentata; riportare il messaggio d'errore reale (es. PTX JIT, nvJitLink) e citare la documentazione NVIDIA. Stessa affermazione in Limitations (riga 432).",
    section="Data and Methods > Hardware and software environment")

add(None, 53, "All single-cell experiments used the 10x Genomics 1.3-million mouse brain cell dataset (E18)",
    "tutti gli esperimenti single-cell usano il dataset 10x 1.3M E18",
    "Stress test e DE a 3.4M usano CZ CELLxGENE Census (versione 2025-11-08, mouse brain, 10x 3', is_primary_data) con 3,436,470 cellule sorgente, replicate fino a 11.9M; il DE pseudo-bulk usa 202 donatori reali. Nessuna menzione ne' citazione di CELLxGENE nel manoscritto.",
    "MISMATCH", "major", "results/maxpower_limit_8gpu.json source_cells; results/de_benchmark_pseudobulk.json n_donors; /tmp/repo/scripts/benchmark_maxpower.py righe 47-60, 200-230, 469-517",
    "Descrivere e citare la sorgente (CZ CELLxGENE Discover, NAR 2025, e Census con versione) e dichiarare la replica delle cellule oltre 3.4M; incide sull'interpretazione del limite 11.9M dell'abstract.",
    section="Data and Methods > Single-cell RNA-seq > Dataset and subsampling")

add(None, 223, "PCIe Gen5 bandwidth (128 GB/s) is not saturated at these sub-gigabyte dataset sizes",
    "PCIe Gen5 128 GB/s",
    "Pagina NVIDIA H100: H100 SXM 'PCIe Gen5: 128GB/s' (valore aggregato del collegamento). Valore coerente ma senza citazione.",
    "UNSUPPORTED", "minor", "https://www.nvidia.com/en-us/data-center/h100/",
    "Citare la scheda NVIDIA e precisare che e' la banda bidirezionale aggregata.",
    section="Results > Single-cell RNA-seq > Per-step speedup varies over two orders of magnitude")

add(None, 154, "comprising 8 x NVIDIA H100 80 GB SXM GPUs connected via NVLink 4.0, dual Intel Xeon Platinum 8480C CPUs (112 cores total), and 2 TB DDR5 RAM",
    "specifiche DGX H100",
    "Scheda DGX H100 (PNY, partner NVIDIA): 8x H100, 640 GB totali, 'Dual Intel Xeon Platinum 8480C Processors', '112 Cores total', 2TB. Valori coerenti, senza citazione.",
    "UNSUPPORTED", "minor", "https://www.pny.com/en-eu/nvidia/dgx/h100",
    "Citare la DGX H100 User Guide o il datasheet NVIDIA.",
    section="Data and Methods > Hardware and software environment")

add(None, 252, "which are implemented as single-GPU operations in cuGraph 26.2",
    "Leiden e UMAP sono operazioni single-GPU in cuGraph 26.2",
    "Documentazione cuGraph (versione 26.12): Leiden single-GPU 'cugraph.leiden' e multi-GPU 'cugraph.dask.community.leiden.leiden'. UMAP e' in cuML, non in cuGraph (pagina CUDA-X; Dicks2026).",
    "MISMATCH", "minor", "https://docs.nvidia.com/cugraph/latest/api_docs/cugraph/community/index.html; " + PDF + "2603.02402v1.txt righe 300-305",
    "Documentazione 26.2 non letta; scrivere 'as called by rapids-singlecell' e attribuire UMAP a cuML.",
    section="Results > Single-cell RNA-seq > Memory is not a bottleneck at benchmark scale")

add(None, 252, "rather than silently collapsing onto a single GPU, as reported for some Dask-CUDA configurations",
    "collasso silenzioso su una GPU riportato per alcune configurazioni Dask-CUDA",
    "Nessuna citazione; il diario CLAUDE.md descrive un bug di reporting del client, non un collasso documentato in letteratura.",
    "UNSUPPORTED", "minor", "full_paper_LNBI.md riga 252; /tmp/repo/CLAUDE.md riga 461",
    "Citare l'issue o la documentazione, oppure togliere 'as reported'.",
    section="Results > Single-cell RNA-seq > Memory is not a bottleneck at benchmark scale")

add(None, 426, "p-values from cell-level tests become uninformative because virtually every gene reaches statistical significance due to the enormous sample size",
    "a 3.4M cellule quasi ogni gene e' significativo; DESeq2 ed edgeR nominati",
    "Nessuna citazione e nessun dato riportato a supporto; DESeq2 (Love 2014) ed edgeR (Robinson 2010) nominati senza riferimento.",
    "UNSUPPORTED", "minor", "full_paper_LNBI.md riga 426",
    "Riportare la quota di geni significativi dai risultati o citare (es. Squair2021 sui falsi positivi); aggiungere i riferimenti di DESeq2 ed edgeR.",
    section="Discussion")

add(None, 105, "after Hungarian matching",
    "metodi citati senza riferimento: matching ungherese, triangolazione di Delaunay, ligand-receptor (CellPhoneDB)",
    "Nessuna citazione per Kuhn (1955), per la triangolazione di Delaunay (scipy.spatial) e per il metodo ligand-receptor; Palla2022 dice che Squidpy fornisce 'a re-implementation of the popular CellphoneDB method'.",
    "UNSUPPORTED", "minor", "full_paper_LNBI.md righe 105, 133, Table 3; nature.com Squidpy",
    "Aggiungere i riferimenti metodologici minimi.",
    section="Data and Methods > Single-cell RNA-seq > Concordance metrics")

add(None, 156, "Key software versions: Scanpy 1.12, rapids-singlecell 0.14.1, CuPy 13.6.0, Dask 2026.1.1, Dask-CUDA 26.2.0, Python 3.12.12.",
    "software usato senza citazione",
    "Non citati: CuPy (Okuta et al. 2017, citato da Dicks2026), cuML (Raschka et al. 2020), igraph, NumPy (Harris 2020), SciPy (Virtanen 2020), scikit-learn, PyNNDescent, Singularity/Apptainer, SLURM, psutil.",
    "UNSUPPORTED", "minor", PDF + "2603.02402v1.txt riferimenti 2, 11, 12, 14",
    "Per LNCS bastano le citazioni dei componenti centrali (CuPy, cuML, igraph, NumPy/SciPy).",
    section="Data and Methods > Hardware and software environment")

add(None, 428, "is, to our knowledge, the largest GPU speedup reported for any spatial transcriptomics operation",
    "3,272x e' il piu' grande speedup GPU riportato per un'operazione spatial",
    "Nessuna citazione ne' ricerca documentata; anche la complessita' O(n^2) dell'implementazione CPU di Squidpy non e' citata. Dicks2026 non riporta la co-occorrenza.",
    "UNSUPPORTED", "minor", "full_paper_LNBI.md riga 428; " + PDF + "2603.02402v1.txt",
    "Togliere la priorita' o documentarla; il valore dipende da un'implementazione CPU single-thread di riferimento.",
    section="Discussion")

add(None, 432, "integration methods (Harmony, scVI)",
    "Harmony e scVI nominati senza riferimento",
    "Nessuna citazione (Korsunsky 2019; Lopez 2018). Dicks2026 riporta Harmony GPU su 11.4M cellule in meno di 25 s: pertinente al limite dichiarato.",
    "UNSUPPORTED", "minor", "full_paper_LNBI.md riga 432; " + PDF + "2603.02402v1.txt righe 150-160",
    "", section="Discussion")

add(None, 321, "reduced the analysis from 3.4 million individual cells to a few hundred pseudo-samples per cluster",
    "qualche centinaio di pseudo-campioni per cluster",
    "results/de_benchmark_pseudobulk.json: n_pseudobulk_samples 2431, n_clusters 81, n_donors 202: in media 2431/81 = 30.0 pseudo-campioni per cluster (2,431 in totale).",
    "MISMATCH", "minor", "results/de_benchmark_pseudobulk.json results.pseudobulk; " + W + "scripts/e_numbers.py",
    "Correggere in 'about 30 pseudo-samples per cluster (2,431 in total)'. Convenzione: media semplice su cluster.",
    section="Results > Single-cell RNA-seq > Differential expression: pseudo-bulk is fastest and most correct")

add(None, 183, "At 1.3 million cells, the 8-GPU pipeline completed the full analysis in 435.2 +/- 16.2 s (7.3 min), compared with 52,056.2 +/- 392.0 s (14.5 h) for the CPU pipeline",
    "speedup 119.6x a 1.3M; nessun confronto con Dicks2026 sullo stesso dataset",
    "Ricalcolo (media r1-r5, SD campionaria): CPU totale 52,056.2 s (SD 392.0); de_testing 48,688.3 s = 93.5%; resto della pipeline 3,367.9 s (56.1 min). Dicks2026, stesso dataset, senza DE e senza I/O: CPU 32 core 'over 52 minutes', una GPU 25-26 s (>120x).",
    "UNSUPPORTED", "major", "results/cpu_1300000_r*_results.json timings; " + W + "scripts/e_numbers.py; " + W + "e_numbers_output.txt; " + PDF + "2603.02402v1.txt righe 140-150",
    "Il titolo 120x e' guidato quasi tutto dal Wilcoxon CPU; un revisore chiedera' il confronto con Dicks2026, che ottiene lo stesso fattore su una sola GPU.",
    section="Results > Single-cell RNA-seq > GPU acceleration achieves up to 120-fold end-to-end speedup")

# ---------------------------------------------------------------------------
# Controlli e scrittura
# ---------------------------------------------------------------------------
ids_done = {f["inv_id"] for f in F if f["inv_id"]}
missing = [r["id"] for r in INV if r["id"] not in ids_done]
assert not missing, missing
assert len([f for f in F if f["section"] == "Bibliografia"]) == 32
for f in F:
    assert len(f["locator"]) <= 200, (f["inv_id"], len(f["locator"]))
    if f["section"] != "Bibliografia":
        assert f["locator"] in MD[f["line"] - 1], (f["inv_id"], f["line"], f["locator"][:60])
    for k in ("locator", "claimed", "recomputed", "note", "source"):
        assert "—" not in f[k] and "–" not in f[k], (f["inv_id"], k)
out = REV / "tracks" / "E_findings.json"
out.write_text(json.dumps(F, ensure_ascii=False, indent=1))
print("scritte", len(F), "voci in", out)
print("status", Counter(f["status"] for f in F))
print("severita'", Counter(f["severity"] for f in F))
print("status x sev", Counter((f["status"], f["severity"]) for f in F))
