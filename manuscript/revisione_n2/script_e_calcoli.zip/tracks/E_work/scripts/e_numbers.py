"""Track E: numeri di contesto ricalcolati dai JSON (sola lettura)."""
import json, glob, statistics, sys
R = '/tmp/repo/results'
# 1) CPU 1.3M: tempo totale e quota DE, media su r1..r5 (SD campionaria)
tot, de, nonde = [], [], []
for f in sorted(glob.glob(f'{R}/cpu_1300000_r*_results.json')):
    t = json.load(open(f))['timings']
    tot.append(t['total'])
    dek = ['de_testing']
    d = sum(t[k] for k in dek)
    de.append(d); nonde.append(t['total'] - d)
    print(f.split('/')[-1], 'keys=', list(t.keys()), 'DEkeys=', dek)
print('CPU 1.3M total mean', statistics.mean(tot), 'sd', statistics.stdev(tot), 'n', len(tot))
print('CPU 1.3M DE mean', statistics.mean(de), 'non-DE mean', statistics.mean(nonde), 'non-DE min', statistics.mean(nonde)/60)
# 2) pseudobulk samples per cluster
d = json.load(open(f'{R}/de_benchmark_pseudobulk.json'))['results']['pseudobulk']
print('pseudobulk samples', d['n_pseudobulk_samples'], 'clusters', d['n_clusters'], 'donors', d['n_donors'],
      'mean per cluster', d['n_pseudobulk_samples']/d['n_clusters'])
# 3) costo GPU 8xH100 a 1.3M: GPU-ore
g = [json.load(open(f))['timings']['total'] for f in sorted(glob.glob(f'{R}/gpu8_1300000_r*_results.json'))]
m = statistics.mean(g)
print('gpu8 1.3M mean total s', m, 'n', len(g), 'GPU-hours', m*8/3600, 'USD@2', m*8/3600*2, 'USD@4', m*8/3600*4)
# 4) stress test source
print(json.load(open(f'{R}/maxpower_limit_8gpu.json')))
