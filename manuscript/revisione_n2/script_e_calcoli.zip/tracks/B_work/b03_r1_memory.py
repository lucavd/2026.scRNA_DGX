"""Track B: effetto della ripetizione 1 (warmup) e traiettorie di memoria.
Uso: python3 -I b03_r1_memory.py /tmp/repo/SPATIAL/results
"""
import json, sys
from pathlib import Path
import numpy as np
R = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/repo/SPATIAL/results")
P = {"visium": "spatial_{p}_visium_r{k}_results.json",
     "hd8": "spatial_{p}_visium_hd_square_008um_r{k}_results.json",
     "hd2": "spatial_{p}_visium_hd_square_002um_r{k}_results.json"}
L = lambda pl, pi, k: json.load(open(R / P[pl].format(p=pi, k=k)))
m = lambda x: sum(x) / len(x)

print("== HD 8um: scenari per co-occurrence e totale ==")
c = [L("hd8", "cpu", k)["timings"] for k in range(1, 6)]
g = [L("hd8", "gpu", k)["timings"] for k in range(1, 6)]
for s in ("co_occurrence", "total", "spatial_autocorr_moran", "spatial_autocorr_geary", "umap", "nhood_enrichment"):
    cc = [t[s] for t in c]; gg = [t[s] for t in g]
    print(f"{s:24s} CPU r1={cc[0]:.2f} CPU r2-5={m(cc[1:]):.2f} ratio(r2-5/r1)={m(cc[1:])/cc[0]:.1f}x | "
          f"GPU r1={gg[0]:.3f} GPU r2-5={m(gg[1:]):.3f} | speedup: r2-5={m(cc[1:])/m(gg[1:]):.1f} r1-5(RoM)={m(cc)/m(gg):.1f} "
          f"r1-5(MoR)={m([a/b for a,b in zip(cc,gg)]):.1f} r1vs r1={cc[0]/gg[0]:.1f} CPUr1 vs GPUr2-5={cc[0]/m(gg[1:]):.1f}")
print("CPU r1 co_occurrence share of CPU r1 total: %.2f%%" % (100 * c[0]["co_occurrence"] / c[0]["total"]))
print("HD8 senza co-occurrence (r2-5): CPU=%.1f GPU=%.2f speedup=%.2f" % (
    m([t["total"] - t["co_occurrence"] for t in c[1:]]), m([t["total"] - t["co_occurrence"] for t in g[1:]]),
    m([t["total"] - t["co_occurrence"] for t in c[1:]]) / m([t["total"] - t["co_occurrence"] for t in g[1:]])))
# identita' output co-occurrence CPU r1 vs r2-5
a1 = np.load(R / "spatial_cpu_visium_hd_square_008um_r1_co_occurrence.npy")
print("CPU co-occ r1 == r2..r5:", [bool(np.array_equal(a1, np.load(R / f"spatial_cpu_visium_hd_square_008um_r{k}_co_occurrence.npy"))) for k in range(2, 6)])

print("\n== Moran/Geary CPU r1 vs r2-5 per piattaforma (nhood eseguito solo su visium e hd8) ==")
for pl in P:
    cc = [L(pl, "cpu", k)["timings"] for k in range(1, 6)]
    for s in ("spatial_autocorr_moran", "spatial_autocorr_geary", "nhood_enrichment"):
        v = [t[s] for t in cc]
        print(f"{pl:7s} {s:24s} r1={v[0]:.3f} r2-5 mean={m(v[1:]):.3f}")

print("\n== Speedup totale: convenzioni ==")
for pl in P:
    cc = [L(pl, "cpu", k)["timings"]["total"] for k in range(1, 6)]
    gg = [L(pl, "gpu", k)["timings"]["total"] for k in range(1, 6)]
    print(f"{pl:7s} r2-5={m(cc[1:])/m(gg[1:]):.2f}  r1-5 RoM={m(cc)/m(gg):.2f}  r1-5 MoR={m([a/b for a,b in zip(cc,gg)]):.2f}  r1 only={cc[0]/gg[0]:.2f}")

print("\n== Moran/Geary speedup (r2-5 RoM) su tutte le piattaforme ==")
for pl in P:
    cc = [L(pl, "cpu", k)["timings"] for k in range(1, 6)]; gg = [L(pl, "gpu", k)["timings"] for k in range(1, 6)]
    for s in ("spatial_autocorr_moran", "spatial_autocorr_geary"):
        print(f"{pl:7s} {s:24s} {m([t[s] for t in cc[1:]])/m([t[s] for t in gg[1:]]):.2f}  CPU r2-5 mean s={m([t[s] for t in cc[1:]]):.1f}")

print("\n== Traiettoria VRAM (GPU r2) e RAM per ripetizione ==")
for pl in P:
    d = L(pl, "gpu", 2)["memory"]["detailed"]
    steps = [k[:-len("_vram_before_gb")] for k in d if k.endswith("_vram_before_gb")]
    print(pl, "VRAM before/after:", [(s, d[s + "_vram_before_gb"], d[s + "_vram_after_gb"]) for s in steps])
    for pi in ("cpu", "gpu"):
        print(f"   {pi} peak_ram r1..r5 = {[L(pl, pi, k)['memory']['peak_ram_gb'] for k in range(1, 6)]}"
              f"  data_loading_ram_before r1..r5 = {[L(pl, pi, k)['memory']['detailed']['data_loading_ram_before_gb'] for k in range(1, 6)]}")
    print("   VRAM peak / 24 GB = %.1f%%" % (100 * L(pl, "gpu", 2)["memory"]["peak_vram_gb"] / 24.0))

print("\n== Bin: 2um vs 8um ==")
print("6296688/393543 =", 6296688 / 393543, "; 6296688/389492 =", 6296688 / 389492, "; 400000-389492 =", 400000 - 389492)
print("HD2 cluster: 2559/538=%.4f 2559/537(mean r2-5)=%.4f" % (2559 / 538, 2559 / 537))
print("Dense 6.3M x 2000 float32 GB = %.1f ; float64 = %.1f" % (6296688 * 2000 * 4 / 1e9, 6296688 * 2000 * 8 / 1e9))
print("squidpy _occur_count local_results bytes: k=7 -> %.2f GB ; k=3 -> %.2f GB (n=393543, l=49)" % (
    393543 * 49 * 49 * 4 / 1e9, 393543 * 49 * 9 * 4 / 1e9))
