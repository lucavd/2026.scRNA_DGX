"""Track B: concordanza spatial dai JSON spatial_concordance_<platform>.json e dai .npy.
Uso: python3 -I b02_concordance.py /tmp/repo/SPATIAL/results
"""
import json, sys
from pathlib import Path
import numpy as np

R = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/repo/SPATIAL/results")
P = {"visium": "visium", "hd8": "visium_hd_square_008um", "hd2": "visium_hd_square_002um"}
def mean(x): return sum(x) / len(x)

for key, p in P.items():
    d = json.load(open(R / f"spatial_concordance_{p}.json"))
    print(f"\n========== {key} ({len(d)} entries; repeat_ids={[e['repeat_id'] for e in d]}) ==========")
    fields = [("moranI", "n_common_genes"), ("moranI", "I_spearman_rho"), ("moranI", "I_pearson_r"),
              ("moranI", "svg_jaccard_top50"), ("moranI", "svg_jaccard_top100"), ("moranI", "svg_jaccard_top200"),
              ("moranI", "svg_jaccard_fdr005"), ("moranI", "n_svg_cpu"), ("moranI", "n_svg_gpu"), ("moranI", "n_svg_shared"),
              ("gearyC", "C_spearman_rho"), ("gearyC", "svg_jaccard_top50"), ("gearyC", "svg_jaccard_top100"),
              ("gearyC", "svg_jaccard_top200"), ("gearyC", "svg_jaccard_fdr005"), ("gearyC", "n_svg_cpu"),
              ("gearyC", "n_svg_gpu"), ("gearyC", "n_svg_shared"),
              ("clusters", "ari"), ("clusters", "nmi"), ("clusters", "n_clusters_cpu"), ("clusters", "n_clusters_gpu"),
              ("clusters", "n_common_spots")]
    for sec, f in fields:
        v = [e.get(sec, {}).get(f) for e in d]
        s = f"{sec}.{f:22s} r1-5={v}"
        if all(isinstance(x, (int, float)) for x in v):
            s += f"  mean2-5={mean(v[1:]):.6f} mean1-5={mean(v):.6f} min={min(v)} max={max(v)}"
        print(s)
    for sec in ("co_occurrence", "nhood_enrichment"):
        print(f"{sec:16s} per repeat: {[e.get(sec) for e in d]}")
    # FDR jaccard ricalcolato da conteggi: shared/(cpu+gpu-shared)
    for sec in ("moranI", "gearyC"):
        for e in d:
            m = e[sec]
            j = m["n_svg_shared"] / (m["n_svg_cpu"] + m["n_svg_gpu"] - m["n_svg_shared"])
            print(f"  {sec} r{e['repeat_id']}: jaccard_fdr ricalcolata={j:.6f} (json {m['svg_jaccard_fdr005']}); overlap/n_cpu={m['n_svg_shared']/m['n_svg_cpu']:.4f}")
    # speedup nel JSON (per ripetizione)
    for e in d:
        t = e["timing"]
        print(f"  timing r{e['repeat_id']}: total={t['total']}  co_occ={t.get('co_occurrence',{}).get('speedup')}"
              f" moran={t.get('spatial_autocorr_moran',{}).get('speedup')} geary={t.get('spatial_autocorr_geary',{}).get('speedup')}")

# Rapporto cluster HD 2um
print("\n2559/538 =", 2559 / 538, " 2559/534 =", 2559 / 534)

# .npy co-occurrence e nhood: forme, identita' tra ripetizioni
print("\n===== .npy =====")
for key, p in (("visium", "visium"), ("hd8", "visium_hd_square_008um")):
    for pipe in ("cpu", "gpu"):
        arrs = [np.load(R / f"spatial_{pipe}_{p}_r{k}_co_occurrence.npy") for k in range(1, 6)]
        nh = [np.load(R / f"spatial_{pipe}_{p}_r{k}_nhood_enrichment.npy") for k in range(1, 6)]
        same = [bool(np.allclose(arrs[0], a, equal_nan=True)) for a in arrs]
        maxd = [float(np.nanmax(np.abs(arrs[0] - a))) for a in arrs]
        nsame = [bool(np.allclose(nh[0], a, equal_nan=True)) for a in nh]
        nmaxd = [float(np.nanmax(np.abs(nh[0] - a))) for a in nh]
        print(f"{key} {pipe}: co_occ shape={arrs[0].shape} dtype={arrs[0].dtype} identical_to_r1={same} maxabsdiff={maxd}")
        print(f"{key} {pipe}: nhood shape={nh[0].shape} identical_to_r1={nsame} maxabsdiff={nmaxd}")
