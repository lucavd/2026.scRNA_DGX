"""Track B: costruisce tracks/B_findings.json a partire dagli esiti (valori da b01, b02, b03).
Uso: python3 -I b04_build_findings.py <review_dir>
"""
import json, sys
from pathlib import Path

RV = Path(sys.argv[1])
inv = {r["id"]: r for r in json.load(open(RV / "tracks/inv_B.json"))}
R = "/tmp/repo/SPATIAL/results"
W = "tracks/B_work"
B1 = f"{W}/b01_timings.py"; B2 = f"{W}/b02_concordance.py"; B3 = f"{W}/b03_r1_memory.py"

def loc(r):
    t = r.get("text") if r.get("text") else " | ".join(r.get("cells", [])) if r.get("cells") else r.get("caption", "")
    if r["kind"] == "figure":
        t = r["caption"]
    return t[:200]

E = {}  # id -> (status, severity, claimed, recomputed, source, note)
def add(i, status, sev, claimed, recomputed, source, note):
    E[i] = (status, sev, claimed, recomputed, source, note)

R1NOTE = ("vedi A0093: CPU r1 HD 8 um ha prodotto la stessa matrice di co-occurrence (np.array_equal su r1..r5) in 73.47 s contro "
          "3,573.20 s (media r2-5), rapporto 48.6x")

add("A0001", "MISMATCH", "major", "single-cell and spatial transcriptomics on NVIDIA DGX H100",
    "Tutti i 30 JSON spatial hanno gpu_info.gpu_name = 'NVIDIA GeForce RTX 4090' (15 GPU) o n_gpus 0 (15 CPU); nessun run spatial su H100. H100 solo nei JSON scRNA.",
    f"{R}/spatial_*_results.json metadata.gpu_info, metadata.n_gpus ({B1})",
    "Il titolo attribuisce anche lo spatial al DGX H100; l'abstract non nomina mai la RTX 4090. Corretto solo per la parte scRNA.")
add("A0012", "UNSUPPORTED", "critical",
    "up to 51.6x end-to-end (Visium HD 8 um), 3,272x co-occurrence, Spearman rho >= 0.9995, three 10x Visium platforms",
    "51.6x = 4,068.40/78.79 = 51.64 con media r2-5; con r1-5 41.46x (ratio of means) o 42.59x (mean of ratios); r1 da sola 6.39x. "
    "Co-occurrence: 3,573.20/1.0922 = 3,271.5x con r2-5 (3,272x e' la sola r2: 3,271.81); r1-5 2,087.9x (RoM) o 2,623.0x (MoR); "
    "CPU r1 vs GPU r2-5 = 67.3x. rho minimo 0.999526 (Geary, HD 8 um): >= 0.9995 OK. Le 'tre piattaforme' sono due dataset (v1, HD) con HD a due bin.",
    f"{R}/spatial_{{cpu,gpu}}_visium_hd_square_008um_r{{1..5}}_results.json timings.total, timings.co_occurrence; spatial_concordance_*.json; {B1}, {B3}",
    "I due numeri di punta dipendono dall'esclusione della r1, nella quale la CPU ha calcolato la stessa co-occurrence 48.6x piu' in fretta "
    "(" + R1NOTE + "). Inoltre l'abstract non dice che lo spatial e' su una RTX 4090 locale.")
add("A0017", "MISMATCH", "minor", "Visium HD generates up to 6.3 million 2 um bins per tissue section",
    "6,296,688 = bin 2 um filtrati del solo campione usato (metadata.n_spots_input HD 2 um, = 16 x 393,543). La capture area Visium HD contiene ~11.2 milioni di quadrati 2x2 um (glossario Space Ranger 4.0).",
    f"{R}/spatial_cpu_visium_hd_square_002um_r1_results.json metadata.n_spots_input; https://www.10xgenomics.com/support/software/space-ranger/4.0/getting-started/space-ranger-glossary",
    "6.3M e' il conteggio on-tissue di un campione, non il massimo della piattaforma ('up to'). Citazione Palla2022 non letta in questo track.")
add("A0023", "UNSUPPORTED", "minor", "both modalities on DGX H100 and RTX 4090; all code and containers for full reproducibility",
    "scRNA solo su H100, spatial solo su RTX 4090 (gpu_info). Per lo spatial: SPATIAL/Dockerfile.spatial non pinna scanpy/squidpy/spatialdata; "
    "i CSV per gene (moranI/gearyC) e le etichette dei cluster scritti da save_results non sono nel repo (solo JSON e .npy), quindi Tabella 10 "
    "si verifica solo sul JSON derivato spatial_concordance_*.json; figures/generate_spatial_figures.py non riproduce i PNG (Fig. 7 senza barre d'errore nel codice, Fig. 8 con 3272 hardcoded ma 3,271x nel PNG).",
    "SPATIAL/Dockerfile.spatial; SPATIAL/scripts/benchmark_spatial_gpu.py save_results; ls SPATIAL/results; figures/generate_spatial_figures.py righe 48-51, 114",
    "'full reproducibility' non sostenuta per la parte spatial. L'affermazione sul collo di bottiglia CPU e' di competenza del track scRNA.")
add("A0066", "PASS", "info", "two 10x public datasets, downloaded programmatically from the 10x portal",
    "download_spatial_data.py scarica via wget da cf.10xgenomics.com: V1_Mouse_Brain_Sagittal_Anterior (spatial-exp 1.1.0) e Visium_HD_Tiny_3prime_Dataset_outs.zip (spatial-exp 4.0.1).",
    "SPATIAL/scripts/download_spatial_data.py righe 26-52",
    "Il dataset HD e' un dataset di esempio per sviluppatori, vedi A0068.")
add("A0067", "PASS", "info", "Visium v1 Mouse Brain Sagittal Anterior, 2,695 spots, 55 um, approximately 32,285 genes",
    "n_spots_input = 2,695 e n_genes_input = 32,285 in tutti i 10 JSON Visium (dopo QC 2,695 x 19,112). 55 um e' specifica di piattaforma, non presente nei dati.",
    f"{R}/spatial_*_visium_r*_results.json metadata.n_spots_input, n_genes_input, results_summary ({B1})",
    "'approximately' superfluo: 32,285 e' esatto.")
add("A0068", "MISMATCH", "major", "Visium HD Mouse Brain (CytAssist, FFPE); 8 um 393,543 bins; 2 um from 6.3M to 389,492; 19,059 genes",
    "Numeri OK: 393,543 (input e dopo QC, 8 um); 6,296,688 input 2 um, sottocampione esatto 400,000 (seed 42) poi QC -> 389,492 (10,508 bin rimossi); 19,059 geni in input (dopo QC 18,821 a 8 um, 14,380 a 2 um). "
    "Dataset: il codice scarica Visium_HD_Tiny_3prime_Dataset (Space Ranger 4.0.1), che 10x descrive come dataset Visium HD 3' di mouse brain con FASTQ sottocampionati e immagini ritagliate, 'not meant to be used to draw biological conclusions'; il dataset Visium HD 3' mouse brain di 10x e' fresh frozen.",
    f"{R}/spatial_*_visium_hd_*_r*_results.json metadata/results_summary; SPATIAL/scripts/download_spatial_data.py righe 43-52, 203-228; https://www.10xgenomics.com/support/software/space-ranger/4.0/resources/visium-hd-example-data; https://www.10xgenomics.com/datasets/visium-hd-three-prime-mouse-brain-fresh-frozen",
    "'FFPE' non corrisponde alla chimica 3' del dataset usato e va dichiarato che e' il dataset 'Tiny' a letture sottocampionate: incide sulla sparsita' per bin e sull'interpretazione della concordanza dei cluster a 2 um.")
add("A0069", "PASS", "info", "2 um subsampled to approximately 400,000 bins with --max-spots to fit 24 GB VRAM; full scale requires DGX-class resources",
    "run_all_benchmarks.sh usa --max-spots 400000 per CPU e GPU HD 2 um; sottocampione esatto di 400,000 prima della QC; gpu_vram_total_gb = 24.0.",
    "SPATIAL/run_all_benchmarks.sh righe 63-74; benchmark_spatial_cpu.py righe 252-256",
    "Il fatto che 6.3M non entri in 24 GB e richieda un DGX non e' documentato da alcun run.")
add("A0070", "PASS", "info", "two phases: expression and spatial statistics (Table 3)",
    "Struttura Phase A (passi 1-8) e Phase B (passi 9-14) in entrambi gli script.", "SPATIAL/scripts/benchmark_spatial_{cpu,gpu}.py", "")
add("A0071", "PASS", "info", "Steps 1-8 share parameters with scRNA-seq pipeline except QC min_genes = 1 for HD",
    "min_genes = 1 per visium_hd e 200 per Visium in entrambi gli script; min_cells 3, target_sum 1e4, 2,000 HVG, scale max_value 10, PCA 50, k = 15 identici a scripts/benchmark_cpu.py.",
    "SPATIAL/scripts/benchmark_spatial_cpu.py righe 270-317; scripts/benchmark_cpu.py righe 174-223",
    "Nel codice lo step 1 e' il data loading e la QC e' lo step 2 ('QC through UMAP' copre 2-8). La differenza di risoluzione Leiden e' dichiarata in tabella.")
add("A0072", "PASS", "info", "Table 3 header", "Intestazione coerente con il contenuto.", "full_paper_LNBI.md riga 130", "")
add("A0073", "PASS", "info", "Leiden r = 1.0 for Visium, r = 0.1 for HD",
    "Regola nel codice: resolution 0.1 se n_after_qc > 100,000, altrimenti 1.0 (CPU righe 322-329, GPU righe 376-379); Visium 2,695 spot -> 1.0, HD -> 0.1.",
    "SPATIAL/scripts/benchmark_spatial_{cpu,gpu}.py", "La regola dipende dal numero di spot, non dalla piattaforma. CPU: sc.tl.leiden flavor='igraph', n_iterations=2.")
add("A0074", "PASS", "info", "Spatial neighbours, no GPU, Delaunay triangulation (scipy.spatial)",
    "sq.gr.spatial_neighbors(coord_type='generic', delaunay=True) in entrambi gli script; squidpy 1.8.1 _build.py importa scipy.spatial.Delaunay (riga 26, uso riga 387); metadata GPU 'cpu_only (squidpy)'.",
    "SPATIAL/scripts/benchmark_spatial_gpu.py riga 420; squidpy-1.8.1 wheel squidpy/gr/_build.py", "")
add("A0075", "PASS", "info", "Moran's I GPU yes", "GPU: rsc.gr.spatial_autocorr(mode='moran'); CPU: sq.gr.spatial_autocorr.", "benchmark_spatial_gpu.py riga 446", "Calcolato solo sui 2,000 HVG (vedi finding riga 149).")
add("A0076", "PASS", "info", "Geary's C GPU yes", "GPU: rsc.gr.spatial_autocorr(mode='geary').", "benchmark_spatial_gpu.py riga 457", "Solo sui 2,000 HVG.")
add("A0077", "PASS", "info", "Co-occurrence GPU yes", "GPU: rsc.gr.co_occurrence; metadata 'gpu (rsc.gr.co_occurrence)'.", "benchmark_spatial_gpu.py riga 470", "")
add("A0078", "PASS", "info", "Neighbourhood enrichment GPU no", "GPU script chiama sq.gr.nhood_enrichment dopo anndata_to_CPU; metadata 'cpu_only (squidpy)'.", "benchmark_spatial_gpu.py righe 478-485", "")
add("A0079", "PASS", "info", "Ligand-receptor GPU no", "GPU script chiama sq.gr.ligrec; metadata 'cpu_only (squidpy)'.", "benchmark_spatial_gpu.py righe 490-508", "")
add("A0080", "PASS", "info", "Scanpy 1.12 and Squidpy 1.8.1 (CPU)", "software_versions scanpy '1.12', squidpy '1.8.1' in tutti i 30 JSON spatial.", f"{R}/spatial_*_results.json metadata.software_versions ({B1})", "Citazione Palla2022 non verificata in questo track.")
add("A0081", "PASS", "info", "rapids-singlecell 0.14.1", "rapids_singlecell '0.14.1', cupy '13.6.0' in tutti i 15 JSON GPU spatial.", f"{R}/spatial_gpu_*_results.json metadata.software_versions", "")
add("A0082", "PASS", "info", "co-occurrence and nhood enrichment skipped above 500 clusters",
    "Codice: eseguiti solo se n_clusters <= 500. JSON: HD 2 um CPU 2,559 cluster e GPU 538/538/534/538/538 -> co_occurrence = nhood_enrichment = -1 in tutti i 10 JSON; Visium (16/15) e HD 8 um (7/3) eseguiti in tutte le ripetizioni.",
    f"{R}/spatial_*_results.json timings, results_summary.n_clusters; benchmark_spatial_cpu.py righe 385-405 ({B1})",
    "La soglia e' applicata da ciascuna pipeline sul proprio numero di cluster.")
add("A0083", "PASS", "info", "ligand-receptor skipped above 100,000 spots",
    "Codice: eseguito solo se n_after_qc <= 100,000 e n_clusters <= 500; ligrec = -1 in tutti i 20 JSON HD (393,543 e 389,492 spot); eseguito su Visium (CPU 4.485 s, GPU 4.325 s, media r2-5).",
    f"{R}/spatial_*_results.json timings.ligrec; benchmark_spatial_cpu.py righe 408-427",
    "Non dichiarati: la condizione aggiuntiva n_clusters <= 500 e n_perms = 100 (ridotto, commento '1000 for production').")
add("A0084", "PASS", "info", "SVG Jaccard for top 50, 100, 200 by Moran's I and FDR < 0.05",
    "Implementato cosi' in compare_spatial_results.py (righe 143-167). Valori top-100/top-200 Moran: 1.0 su v1, 0.9802 su HD 8 um e HD 2 um (tutte le ripetizioni).",
    f"{R}/spatial_concordance_*.json moranI.svg_jaccard_top{{50,100,200}}, svg_jaccard_fdr005 ({B2})",
    "N = 100 e 200 sono dichiarati nei Metodi ma mai riportati nei Risultati, dove valgono 0.980 su HD (vedi A0311).")
add("A0089", "MISMATCH", "major", "RTX 4090 (24 GB GDDR6X), 100 CPU cores, 256 GB DDR5, driver 550.x",
    "gpu_name 'NVIDIA GeForce RTX 4090', gpu_vram_total_gb 24.0 OK. n_cpus = 128 in tutti i 30 JSON spatial (os.cpu_count() nel container, usato per OMP/MKL/OPENBLAS/NUMBA_NUM_THREADS). driver_version = 580.126.09 in tutti i 15 JSON GPU. 256 GB, DDR5, GDDR6X non sono nei JSON (256 GB e '100 cores' solo in CLAUDE.md).",
    f"{R}/spatial_*_results.json metadata.n_cpus, metadata.gpu_info.driver_version; benchmark_spatial_cpu.py righe 26-45",
    "La baseline CPU spatial girava con 128 thread, non 100 core; il driver e' 580, non 550 (il '550+' viene dal commento di Dockerfile.spatial). Stesso '100 cores' nello short paper.")
add("A0090", "PASS", "info", "spatial container on the same 26.02-cuda12-py3.12 image, with Squidpy 1.8.1 and spatialdata",
    "SPATIAL/Dockerfile.spatial e Dockerfile: FROM nvcr.io/nvidia/rapidsai/base:26.02-cuda12-py3.12; squidpy 1.8.1 nei JSON; spatialdata installato senza versione.",
    "SPATIAL/Dockerfile.spatial; Dockerfile; JSON software_versions",
    "Versioni non pinnate nel Dockerfile.spatial; i run spatial usano 'docker run' (run_all_benchmarks.sh). Citazioni Palla2022 e Marconato2024 non lette qui.")
add("A0091", "UNVERIFIABLE", "minor", "scRNA ran via forward compatibility; spatial GPU failed on driver 535.183.01, which caps CUDA at 12.2",
    "535.183.01 compare in 42 JSON (gpu8_* e maxpower_*); i 65 JSON gpu_*, gpu2_*, gpu4_* riportano invece 535.247.01. Release notes NVIDIA: CUDA 12.2 GA richiede >= 535.54.03, CUDA 12.3 GA >= 545.23.06, quindi il ramo 535 arriva nativamente a 12.2. Nessun log del fallimento spatial nel repo; SPATIAL.md attribuisce il blocco a RMM 26.02 che richiederebbe driver 570+.",
    "/tmp/repo/results/*.json metadata.gpu_info.driver_version; https://docs.nvidia.com/cuda/archive/12.3.2/cuda-toolkit-release-notes/index.html; SPATIAL/SPATIAL.md riga 263",
    "Il limite 12.2 e il driver sono corretti; il fallimento della parte GPU spatial non e' documentato da log. Il cluster mostra due driver 535 diversi.")
add("A0092", "MISMATCH", "major", "downgrade attempted to RAPIDS 25.02; spatial dependency stack could not be resolved",
    "La storia git documenta un downgrade a RAPIDS 24.06 (base 24.06-cuda12.2-py3.11): commit 524af6f (26/03/2026) 'RAPIDS 24.06 test container passes all GPU tests' e d65ff4d (27/03/2026) 'Full container validated on DGX H100: CuPy, RMM, rapids-singlecell all PASS', con requirements-squidpy.txt (spatialdata 0.3.0) e squidpy 1.6.5 installato con --no-deps; il Dockerfile e' poi stato riportato a 26.02 (446fc86). Nessuna traccia di 25.02 ne' di una risoluzione fallita.",
    "git -C /tmp/repo show 524af6f d65ff4d 446fc86; constraints.txt; requirements-squidpy.txt; SPATIAL/SPATIAL.md righe 263-265",
    "Versione e esito del tentativo non corrispondono alla provenienza del repo; serve riscrivere o documentare (log) il fallimento.")
add("A0093", "MISMATCH", "critical", "first repeat = JIT/warmup, excluded; mean of repeats 2-5",
    "I tempi di Tabelle 8 e 9 seguono davvero r2-5. Eccezioni: colonna CPU RAM = media r1-5 (8.08, 10.77) e non r2-5 (8.30, 11.36); 3,272x = sola r2 (r2-5: 3,271.5x); N cluster GPU HD 2 um = valore modale 538 (media r2-5 537). "
    "Soprattutto, per HD 8 um la r1 CPU non e' un warmup piu' lento: totale 584.60 s contro 4,068.40 s, co-occurrence 73.47 s contro 3,573.20 s con output identico. "
    "Includendo r1 (ratio of means): v1 1.64x, HD 8 um 41.46x, HD 2 um 10.44x, co-occurrence 2,087.9x, Moran HD 8 um 46.0x; mean of ratios: 42.59x e 2,623.0x. Con la sola r1: HD 8 um 6.39x, co-occurrence 29.2x.",
    f"{R}/spatial_{{cpu,gpu}}_*_r{{1..5}}_results.json timings, memory.peak_ram_gb; spatial_cpu_visium_hd_square_008um_r*_co_occurrence.npy; {B1}, {B3}",
    "Meccanismo plausibile dal codice di squidpy 1.8.1: nhood_enrichment chiama parallelize con n_jobs=None -> 1, e _callback_wrapper esegue numba.set_num_threads(1) nel thread principale; da r2 i kernel numba paralleli (_occur_count della co-occurrence, Moran/Geary) girano a 1 thread. "
    "Coerente: Moran/Geary HD 8 um piu' lenti in r2-5 (47.9 vs 35.7 s), nessun rallentamento su HD 2 um dove nhood non gira (34.5 vs 35.9 s). Il meccanismo non e' verificato a runtime; il dato 48.6x con output identico e' certo. Il confronto e' quindi GPU contro CPU a thread singolo, non contro 128 core.")
add("A0217", "PASS", "info", "Table 8 summarises spatial results", "Riferimento corretto.", "full_paper_LNBI.md riga 330", "")
add("A0218", "MISMATCH", "minor", "Table 8 ... (RTX 4090, mean of repeats 2-5)",
    "Tempi e speedup = media r2-5; CPU RAM = media r1-5 (v1 1.276, HD 8 um 8.08, HD 2 um 10.77) invece di r2-5 (1.33, 8.30, 11.36); VRAM identica con entrambe (12.90, 22.60, 22.61).",
    f"{R}/spatial_cpu_*_r*_results.json memory.peak_ram_gb ({B1})", "Convenzione dichiarata non applicata alla colonna RAM.")
add("A0219", "PASS", "info", "Table 8 header",
    "Colonne coerenti. 'GPU VRAM' = memoria usata del device via NVML, che include il pool RMM (12.89 GB gia' prima del data loading).",
    "benchmark_spatial_gpu.py righe 78-82, 154-175", "La RAM della pipeline GPU (2.6, 11.5, 15.5 GB in media r2-5) non e' riportata.")
add("A0220", "PASS", "info", "Visium v1: 2,695 | 10.0 | 6.0 | 1.7x | 1.3 | 12.9",
    "CPU 10.025 s, GPU 5.995 s, 1.67x (r2-5); RAM 1.33 (r2-5) o 1.28 (r1-5); VRAM 12.90.", f"{R}/spatial_*_visium_r*_results.json ({B1})", "")
add("A0221", "MISMATCH", "minor", "HD 8 um: 393,543 | 4,068 | 79 | 51.6x | 8.1 | 22.6",
    "CPU 4,068.40 s, GPU 78.79 s, 51.64x (r2-5) OK; CPU RAM 8.1 = media r1-5 (8.08), con r2-5 8.30; VRAM 22.60 OK.",
    f"{R}/spatial_*_visium_hd_square_008um_r*_results.json ({B1})", "51.6x dipende dall'esclusione di r1 (41.5x includendola): vedi A0093.")
add("A0222", "MISMATCH", "minor", "HD 2 um: 389,492 | 1,042 | 97 | 10.8x | 10.8 | 22.6",
    "CPU 1,041.99 s, GPU 96.73 s, 10.77x (r2-5) OK; CPU RAM 10.8 = media r1-5 (10.77), con r2-5 11.36 (picchi 8.41, 9.22, 10.81, 11.99, 13.43); VRAM 22.61.",
    f"{R}/spatial_*_visium_hd_square_002um_r*_results.json ({B1})", "")
add("A0223", "UNSUPPORTED", "major", "speedup increased from 1.7x to 51.6x, GPU acceleration increasingly valuable as spatial resolution increases (also heading line 326)",
    "1.67x e 51.64x OK (r2-5), ma HD 2 um, la risoluzione piu' alta, ha 10.77x. HD 8 um senza co-occurrence: 495.2/77.70 = 6.37x.",
    f"{B1}, {B3}", "Lo speedup segue numero di spot e presenza della co-occurrence, non la risoluzione; vale anche per il titolo di sezione 'GPU speedup scales dramatically with platform resolution'. Vedi anche A0093.")
add("A0224", "PASS", "info", "Fig. 7 caption: 1.7x to 51.6x; error bars SD repeats 2-5; HD 2 um subsampled to 400k",
    "Valori OK; SD campionaria r2-5 dei totali: CPU 0.08 / 7.66 / 40.54 s, GPU 0.08 / 1.08 / 1.24 s (v1 / HD 8 / HD 2); 400,000 prima della QC.",
    f"{B1}; /tmp/repo/figures/fig7_spatial_speedup.png",
    "Le barre d'errore del PNG non sono estraibili; nessuno script nel repo genera questo PNG (il generatore committato non disegna barre d'errore).")
add("A0225", "MISMATCH", "critical", "co-occurrence 3,272x (3,573 s on CPU to 1.09 s on GPU)",
    "3,573.20 s e 1.0922 s OK (r2-5); rapporto 3,271.5 (ratio of means e mean of ratios), cioe' 3,271x, come annotato nel PNG della Fig. 8; 3,272x e' la sola r2 (3,271.81). "
    "CPU r1 = 73.47 s con output identico: CPU r1 vs GPU r2-5 = 67.3x; r1-5 = 2,087.9x. CPU con 7 cluster, GPU con 3 (input diversi).",
    f"{R}/spatial_*_visium_hd_square_008um_r*_results.json timings.co_occurrence; *_co_occurrence.npy; {B1}, {B3}",
    "Errore di arrotondamento minore, ma il valore centrale misura una CPU che da r2 gira probabilmente a 1 thread numba e su una partizione diversa (" + R1NOTE + ").")
add("A0226", "MISMATCH", "major", "CPU co-occurrence O(n^2) per interval, while the GPU parallelises across all bins and intervals",
    "squidpy 1.8.1 _occur_count: doppio ciclo sulle n x n coppie con ciclo interno sugli intervalli (O(n^2 l)), ma con @njit(parallel=True) e prange su n: anche la CPU e' parallela (NUMBA_NUM_THREADS = 128). L'implementazione GPU di rapids-singlecell non e' stata letta.",
    "squidpy-1.8.1-py3-none-any.whl squidpy/gr/_ppatterns.py _occur_count, _co_occurrence_helper",
    "Il contrasto seriale contro parallelo e' fuorviante: in r1 la CPU parallela impiega 73.5 s.")
add("A0227", "PASS", "info", "7 Leiden clusters, co-occurrence 88% of CPU time",
    "n_clusters CPU = 7 in tutte le ripetizioni; 3,573.20/4,068.40 = 87.83% (r2-5); 85.22% con r1-5; nella sola r1 12.57%.",
    f"{B1}, {B3}", "La GPU aveva 3 cluster; la quota 88% esiste solo nelle ripetizioni rallentate.")
add("A0228", "MISMATCH", "minor", "Fig. 8 caption: 3,272x (3,573 s to 1.09 s); 162-163x; CPU-only steps at 1.0x",
    "PNG della Fig. 8 annota 3,271x, coerente con r2-5 (3,271.5); 162.27x e 162.52x OK; spatial_neighbors 0.97x e nhood 1.03x -> 1.0x OK; 'largest acceleration in this study' OK nello studio.",
    f"/tmp/repo/figures/fig8_spatial_perstep.png; {B1}", "Didascalia e figura discordano (3,272 vs 3,271).")
add("A0229", "PASS", "info", "PCA 257x, normalisation 176x, spatial autocorrelation 162-163x, UMAP 159x",
    "256.62x, 176.29x, 162.27x e 162.52x, 158.84x (ratio of means r2-5).", f"{B1}", "")
add("A0230", "PASS", "info", "Leiden 16x, k-NN 20x", "16.36x e 19.72x (r2-5).", f"{B1}", "Leiden CPU e GPU producono 7 contro 3 cluster.")
add("A0231", "MISMATCH", "minor", "Table 9 caption: spatial-specific operations; CPU fallback executed transparently inside GPU pipeline",
    "6 delle 11 righe sono passi di espressione (PCA, normalizzazione, UMAP, HVG, vicini, Leiden). Lo script GPU chiama esplicitamente sq.gr.spatial_neighbors e sq.gr.nhood_enrichment dopo rsc.get.anndata_to_CPU, non un fallback trasparente. rsc 0.14.1 OK.",
    "benchmark_spatial_gpu.py righe 412-485", "Descrizione della tabella imprecisa; data loading e QC (7.48x) omessi.")
add("A0232", "PASS", "info", "Table 9 header", "OK.", "full_paper_LNBI.md riga 353", "")
add("A0233", "MISMATCH", "minor", "Co-occurrence | 3,573 | 1.09 | 3,272x", "3,573.20 | 1.0922 | 3,271.5x -> 3,271x (r2-5).", f"{B1}", "3,272x e' la sola r2; vedi A0093 e A0225.")
for i, cl, rc in [
    ("A0234", "PCA | 72.8 | 0.28 | 257x", "72.757 | 0.2835 | 256.62x"),
    ("A0235", "Normalisation | 0.65 | 0.004 | 176x", "0.6523 | 0.0037 | 176.29x"),
    ("A0236", "Moran's I | 47.9 | 0.30 | 162x", "47.903 | 0.2952 | 162.27x"),
    ("A0237", "Geary's C | 47.4 | 0.29 | 163x", "47.375 | 0.2915 | 162.52x"),
    ("A0238", "UMAP | 194.3 | 1.22 | 159x", "194.287 | 1.2231 | 158.84x"),
    ("A0239", "HVG selection | 0.94 | 0.012 | 76x", "0.9438 | 0.0124 | 75.96x"),
    ("A0240", "Expression neighbours | 39.4 | 2.00 | 20x", "39.394 | 1.9973 | 19.72x"),
    ("A0241", "Leiden clustering | 19.2 | 1.17 | 16x", "19.185 | 1.1727 | 16.36x"),
    ("A0242", "Spatial neighbours | 55.9 | 57.4 | 1.0x (CPU-only)", "55.903 | 57.368 | 0.97x"),
    ("A0243", "Nhood enrichment | 11.8 | 11.4 | 1.0x (CPU-only)", "11.761 | 11.410 | 1.03x")]:
    note = ""
    if i in ("A0236", "A0237"):
        note = "CPU r1 = 35.7 / 36.2 s: anche Moran/Geary CPU sono piu' lenti in r2-5 (vedi A0093); con CPU r1 vs GPU r2-5 121x / 124x."
    add(i, "PASS", "info", cl, rc + " (media r2-5, ratio of means)", f"{R}/spatial_*_visium_hd_square_008um_r*_results.json timings ({B1})", note)
add("A0244", "PASS", "info", "HD 2 um 10.8x despite 389,492 bins because co-occurrence skipped (>500 clusters)",
    "10.77x; 389,492 OK; CPU 2,559 e GPU 534-538 cluster > 500 -> co_occurrence e nhood_enrichment = -1. HD 8 um senza co-occurrence: 6.37x, quindi l'attribuzione regge.",
    f"{B1}, {B3}", "Anche la nhood enrichment e' saltata.")
add("A0245", "MISMATCH", "major", "UMAP dominated the GPU pipeline time (92x speedup, consuming 92% of the 97 s total GPU time)",
    "UMAP 92.10x OK, ma UMAP GPU = 8.96 s = 9.26% di 96.73 s. Sulla GPU dominano spatial_neighbors 54.91 s (56.77%) e data_loading 29.25 s (30.24%). UMAP domina la pipeline CPU (825.32 s, 79.21%).",
    f"{R}/spatial_gpu_visium_hd_square_002um_r*_results.json timings ({B1})",
    "92% sbagliato di un ordine di grandezza e in contraddizione con la frase sul 57-73% (A0248).")
add("A0246", "PASS", "info", "Visium v1 1.7x; CPU-only steps (spatial neighbours, ligand-receptor) dominate",
    "1.67x; nella pipeline GPU ligrec 4.32 s (72.14%) + spatial_neighbors 0.41 s (6.79%) + nhood 0.29 s (4.84%) = 83.8% di 5.99 s.", f"{B1}", "")
add("A0247", "PASS", "info", "three CPU-only steps; spatial neighbours ~55 s on all HD platforms; ligrec Visium only",
    "spatial_neighbors CPU 55.90 / 54.11 s, GPU 57.37 / 54.91 s (HD 8 / HD 2); su HD 8 um spatial_neighbors + nhood = 87.3% del tempo GPU; ligrec solo Visium.", f"{B1}", "")
add("A0248", "PASS", "info", "spatial neighbours 57-73% of GPU time on HD",
    "56.77% (HD 2 um) e 72.81% (HD 8 um), media r2-5; per ripetizione 56.4-73.2%.", f"{B1}", "")
add("A0249", "PASS", "info", "autocorrelation concordance near-perfect across all platforms", "rho Moran/Geary tra 0.999526 e 1.0.", f"{B2}", "")
add("A0250", "MISMATCH", "minor", "Fig. 9 caption: rho >= 0.9995; top-50 Jaccard 1.0; ARI 0.080; cugraph vs leidenalg",
    "Numeri OK (rho minimo 0.999526; top-50 = 1.0 in 30/30 voci; ARI HD 2 um 0.0795 media r2-5). La CPU usa sc.tl.leiden(flavor='igraph', n_iterations=2), cioe' igraph community_leiden, non leidenalg.",
    f"{R}/spatial_concordance_*.json ({B2}); benchmark_spatial_cpu.py righe 331-337", "Stesso errore leidenalg in A0265 e A0315.")
add("A0251", "PASS", "info", "Moran's I and Geary's C Spearman > 0.9995 in all cases",
    "Moran 1.0 / 0.999877 / 0.999982; Geary 1.0 / 0.999526 / 0.999912 (v1 / HD 8 / HD 2), identici nelle 5 ripetizioni.", f"{R}/spatial_concordance_*.json moranI.I_spearman_rho, gearyC.C_spearman_rho ({B2})", "Calcolati su 2,000 HVG, non su tutti i geni.")
add("A0252", "PASS", "info", "top-50 SVG identical (Jaccard = 1.0) on all three platforms",
    "svg_jaccard_top50 = 1.0 per Moran e Geary in tutte le 15 voci per statistica.", f"{B2}", "Top-100 e top-200 Moran = 0.9802 su HD: 'scientifically equivalent' regge, ma i ranking non sono identici.")
add("A0253", "PASS", "info", "FDR < 0.05 overlap 100%, 99.9%, 98.2%",
    "Jaccard ricalcolata dai conteggi: 1434/1434 = 1.000; 1383/(1384+1384-1383) = 0.99856; 478/(484+481-478) = 0.98152.", f"{B2}", "Sono indici di Jaccard su Moran; Geary: 1.000 / 0.9975 / 0.9856.")
add("A0254", "PASS", "info", "Table 10 caption", "Coerente con compare_spatial_results.py.", "compare_spatial_results.py righe 143-167", "")
add("A0255", "PASS", "info", "Table 10 header", "OK.", "full_paper_LNBI.md riga 386", "")
add("A0256", "PASS", "info", "Moran rho 1.0000 | 0.9999 | 1.0000", "1.000000 | 0.999877 | 0.999982", f"{B2}", "")
add("A0257", "PASS", "info", "Geary rho 1.0000 | 0.9995 | 0.9999", "1.000000 | 0.999526 | 0.999912", f"{B2}", "")
add("A0258", "PASS", "info", "SVG Jaccard top 50: 1.000 x3", "1.0 | 1.0 | 1.0", f"{B2}", "")
add("A0259", "PASS", "info", "SVG Jaccard FDR: 1.000 | 0.999 | 0.982", "1.0 | 0.9986 | 0.9815 (0.98152 dai conteggi)", f"{B2}", "")
add("A0260", "PASS", "info", "Cluster ARI 0.856 | 0.974 | 0.080",
    "0.8561 | 0.97385 (r2-5: 0.973, 0.9747, 0.973, 0.9747) | 0.0795 (r2-5: 0.0843, 0.0652, 0.0843, 0.0843)", f"{B2}",
    "Segue la media r2-5; la sola r2 darebbe 0.973 su HD 8 um.")
add("A0261", "PASS", "info", "Cluster NMI 0.892 | 0.940 | 0.667", "0.8915 | 0.94025 | 0.666925 (media r2-5)", f"{B2}", "")
add("A0262", "MISMATCH", "minor", "N clusters 16 / 15 | 7 / 3 | 2,559 / 538",
    "16/15 e 7/3 costanti; HD 2 um GPU 538, 538, 534, 538, 538 (r1-r5), media r2-5 537.", f"{B2}", "Riportato il valore modale, non la convenzione dichiarata.")
add("A0263", "PASS", "info", "v1 ARI 0.856 NMI 0.892; HD 8 um ARI 0.974 NMI 0.940",
    "0.8561 / 0.8915; 0.97385 / 0.94025.", f"{B2}", "Su HD 8 um ARI alto nonostante 7 cluster CPU contro 3 GPU.")
add("A0264", "PASS", "info", "HD 2 um ARI 0.080, NMI 0.667; 2,559 vs 538 clusters",
    "0.0795, 0.6669; 2,559 (5/5) e 538 (4/5, 534 in r3).", f"{B2}", "")
add("A0265", "MISMATCH", "major", "4.75x difference; leidenalg (CPU) vs cuGraph (GPU)",
    "2,559/538 = 4.757 -> 4.76x (4.77x con la media 537). La CPU usa sc.tl.leiden(flavor='igraph'), cioe' igraph, non leidenalg; la Discussione (riga 422) dice correttamente 'igraph vs cuGraph' per lo scRNA.",
    f"{B3}; benchmark_spatial_cpu.py righe 331-337; scripts/benchmark_cpu.py righe 237-239",
    "Implementazione sbagliata e incoerente nel testo; rapporto troncato.")
add("A0266", "UNSUPPORTED", "major", "subsampling from 6.3 million to 389,492 bins disrupts spatial contiguity, compounding the effect",
    "Numeri OK. Ma il Leiden e' calcolato sul grafo kNN di espressione (sc.pp.neighbors su 50 PC), non sul grafo spaziale: la contiguita' spaziale non entra nel clustering. La CPU produce 2,559 cluster identici in 5/5 ripetizioni.",
    "benchmark_spatial_cpu.py righe 314-337 (neighbors e leiden prima di spatial_neighbors)",
    "Meccanismo non sostenuto dal codice; la sparsita' del dataset Tiny sottocampionato e' una spiegazione alternativa da considerare.")
add("A0267", "UNSUPPORTED", "major", "Peak VRAM 12.9 GB on v1 and plateau 22.6 GB on both HD, well within 24 GB",
    "Letture NVML corrette (12.90, 22.60, 22.61), ma 12.89-12.90 GB sono gia' occupati prima del data loading in tutti i run GPU (pool RMM, rmm.reinitialize(pool_allocator=True)); su Visium la VRAM non si muove mai da 12.9; su HD sale a 22.6 durante Moran's I, pari al 94.2% di 24 GB, identica sui due dataset.",
    f"{R}/spatial_gpu_*_r*_results.json memory.detailed.*_vram_before_gb ({B3}); benchmark_spatial_gpu.py righe 154-175",
    "La misura riflette prenotazione e crescita del pool, non il fabbisogno; 'well within' e 'modest' non sono sostenuti.")
add("A0268", "MISMATCH", "minor", "CPU RAM from 1.3 GB (v1) to 10.8 GB (HD 2 um)",
    "1.33 GB OK; 10.8 = media r1-5 (10.77), con r2-5 11.36. La RSS di base cresce tra ripetizioni nello stesso processo (data_loading_ram_before HD 2 um CPU 0.51, 4.71, 5.52, 7.09, 8.35 GB), quindi i picchi r2-5 includono residui delle ripetizioni precedenti; RAM pipeline GPU fino a 16.9 GB non riportata.",
    f"{R}/spatial_*_r*_results.json memory ({B3})", "Convenzione non rispettata e misura contaminata dall'esecuzione in serie.")
add("A0269", "UNSUPPORTED", "major", "full Visium HD resolution (6.3M bins at 2 um) would fit comfortably within DGX H100 memory",
    "Nessuna misura a 6.3M; 6,296,688 bin = 16.2 volte il sottocampione. La pipeline CPU densifica esplicitamente la matrice HVG (toarray): a 6.3M x 2,000 sono 50.4 GB in float32 (100.7 GB in float64); la pipeline GPU spatial e' a GPU singola; le letture VRAM sono dominate dal pool (A0267).",
    f"{B3}; benchmark_spatial_cpu.py righe 307-311", "Estrapolazione senza base; in tensione con A0069 ('requires DGX-class resources') e SPATIAL.md ('needs >>24 GB VRAM').")
add("A0310", "UNSUPPORTED", "major", "3,272x co-occurrence is the largest GPU speedup reported for any spatial operation; O(n^2) CPU; thousands of bins",
    "3,271x con r2-5; 2,088x con r1-5; 67x CPU r1 vs GPU r2-5. Nessuna fonte citata per il primato. I bin sono 393,543, non migliaia. La CPU squidpy e' anch'essa parallela (numba prange).",
    f"{B1}, {B3}; squidpy 1.8.1 _ppatterns.py", "Primato non verificabile e basato su un baseline CPU probabilmente a thread singolo (A0093).")
add("A0311", "MISMATCH", "minor", "Moran/Geary 162-170x, rho >= 0.9995, identical SVG rankings in seconds rather than minutes",
    "162.27-162.52x (HD 8 um) e 167.16-169.73x (HD 2 um): il range 162-170 unisce le due HD ma i valori HD 2 um non compaiono nei Risultati (162-163x); Visium 7.84x. rho minimo 0.999526 OK. Ranking non identici: rho 0.999877 / 0.999526 su HD 8 um, top-100 Jaccard 0.9802. CPU 34.5-47.9 s (meno di un minuto), GPU 0.21-0.30 s.",
    f"{B1}, {B2}", "Range non coerente con i Risultati; 'identical' e 'minutes' inesatti.")
add("A0314", "UNSUPPORTED", "minor", "the ARI 0.080 divergence is not specific to GPU versus CPU",
    "ARI 0.0795 OK. Nessun confronto CPU-CPU o GPU-GPU eseguito. Dati: CPU 2,559 cluster identici in 5/5 ripetizioni; GPU 534-538 cluster e ARI CPU-GPU tra 0.065 e 0.084; su HD 8 um le matrici di co-occurrence GPU di r3 e r5 differiscono da r1 (max diff 7.70) per etichette GPU diverse a seme fisso.",
    f"{B2}", "L'affermazione e' un'ipotesi non testata; i dati mostrano non determinismo solo sul lato GPU.")
add("A0315", "MISMATCH", "minor", "389,492 bins, resolution 0.1, leidenalg (CPU) vs cuGraph (GPU)",
    "389,492 e 0.1 OK; CPU = igraph (flavor='igraph'), non leidenalg.", "benchmark_spatial_cpu.py righe 322-337", "Come A0265.")
add("A0321", "PASS", "info", "spatial on local RTX 4090; full HD 2 um 6.3 million bins not benchmarked",
    "gpu_name RTX 4090 in tutti i JSON GPU spatial; 6,296,688 bin, run solo sul sottocampione.", f"{B1}", "")
add("A0322", "MISMATCH", "major", "driver 535.183.01 caps CUDA at 12.2; container could not be downgraded without breaking spatial dependencies",
    "535.183.01 presente nei JSON maxpower; limite 12.2 coerente con le release notes NVIDIA. Il downgrade a RAPIDS 24.06 e' documentato come riuscito sui test GPU (commit 524af6f, d65ff4d) e poi annullato (446fc86).",
    "git -C /tmp/repo log; https://docs.nvidia.com/cuda/archive/12.3.2/cuda-toolkit-release-notes/index.html", "Come A0092.")
add("A0335", "UNSUPPORTED", "critical", "51.6x end-to-end on Visium HD, co-occurrence 3,272x, concordance > 0.9995",
    "51.6x vale solo per HD 8 um (HD 2 um 10.8x); 3,271x con r2-5; con r1-5 41.5x e 2,088x; rho minimo 0.999526 OK.",
    f"{B1}, {B3}, {B2}", "Conclusione costruita sui due numeri che dipendono dall'esclusione della r1 (A0093) e generalizzata a 'Visium HD'.")
add("A0336", "UNVERIFIABLE", "minor", "datasets grow toward the billion-cell and billion-bin scales [@Regev2017]",
    "Letto l'abstract di Regev et al. 2017 (eLife 6:e27041, DSpace MIT): nessuna affermazione su scale di miliardi di cellule o di bin; testo completo non letto.",
    "https://dspace.mit.edu/handle/1721.1/113427?show=full", "Un white paper HCA del 2017 difficilmente sostiene 'billion-bin' per lo spatial.")

out = []
for i, r in inv.items():
    st, sev, cl, rc, src, note = E[i]
    out.append({"inv_id": i, "track": "B", "line": r["line"], "section": r["section"], "locator": loc(r),
                "claimed": cl, "recomputed": rc, "status": st, "severity": sev, "source": src, "note": note})

NEW = [
    (149, "Data and Methods > Spatial transcriptomics > Spatial concordance metrics",
     "Spatial autocorrelation concordance was measured as the Spearman rho between CPU and GPU per-gene Moran's I (and separately Geary's C) statistics across all genes.",
     "Spearman across all genes", "n_common_genes = 2000 in tutte le 15 voci di concordanza; entrambi gli script sottoinsiemano ai 2,000 HVG prima di spatial_autocorr ('Run on HVGs only'), su 19,112 / 18,821 / 14,380 geni dopo QC.",
     "MISMATCH", "major", f"{R}/spatial_concordance_*.json moranI.n_common_genes; benchmark_spatial_cpu.py righe 301-367 ({B2})",
     "La concordanza di punta (rho >= 0.9995) riguarda solo i 2,000 HVG."),
    (149, "Data and Methods > Spatial transcriptomics > Spatial concordance metrics",
     "Finally, co-occurrence concordance was the Spearman rho between the full CPU and GPU co-occurrence matrices.",
     "co-occurrence concordance computed as Spearman rho", "Mai calcolata: status 'shape_mismatch' in 5/5 ripetizioni su v1 (16x16x49 contro 15x15x49) e HD 8 um (7x7x49 contro 3x3x49), 'missing_data' su HD 2 um; idem per nhood enrichment. Nessun valore nei Risultati.",
     "UNSUPPORTED", "major", f"{R}/spatial_concordance_*.json co_occurrence, nhood_enrichment ({B2})",
     "L'output GPU della co-occurrence, il passo con lo speedup di punta, non e' mai stato validato contro la CPU."),
    (344, "Results > Spatial transcriptomics > GPU speedup scales dramatically with platform resolution",
     "At 393,543 bins with 7 Leiden clusters, co-occurrence alone consumed 88% of the CPU pipeline time.",
     "co-occurrence CPU vs GPU on the same task", "CPU co-occurrence su 7 cluster, GPU su 3 cluster (Leiden diversi). Nel kernel squidpy l'array locale n x (l k^2) int32 vale 3.78 GB con k = 7 e 0.69 GB con k = 3 (n = 393,543, l = 49).",
     "UNSUPPORTED", "major", f"{R}/spatial_*_visium_hd_square_008um_r*_results.json results_summary.n_clusters; {B3}; squidpy _occur_count",
     "Lo speedup 3,272x confronta due calcoli su partizioni diverse; il testo non lo dichiara."),
    (165, "Data and Methods > Hardware and software environment",
     "Each benchmark configuration was repeated five times; we report mean +/- standard deviation.",
     "mean +/- SD reported", "Tabelle 8, 9, 10 riportano solo medie. SD campionaria r2-5 dei totali: v1 CPU 0.08 / GPU 0.08 s; HD 8 um 7.66 / 1.08 s; HD 2 um 40.54 / 1.24 s. Tipo di SD (campionaria o di popolazione) non dichiarato.",
     "MISMATCH", "minor", f"{B1}", "Per lo spatial la SD manca nelle tabelle; dichiarare n = 4 ripetizioni e ddof."),
    (142, "Data and Methods > Spatial transcriptomics > Spatial analysis pipeline",
     "Steps without GPU implementations (spatial neighbours, neighbourhood enrichment, ligand-receptor) were executed identically on CPU in both pipelines.",
     "CPU-only steps identical in both pipelines", "Stesse chiamate squidpy con gli stessi parametri (spatial_neighbors generic/Delaunay, nhood_enrichment, ligrec n_perms=100). Le matrici z-score di nhood differiscono tra ripetizioni anche sulla CPU (max diff fino a 70.3 su HD 8 um) perche' nessun seed e' passato.",
     "PASS", "info", f"benchmark_spatial_{{cpu,gpu}}.py; {R}/*_nhood_enrichment.npy ({B2})", "Identici nel codice; nhood non deterministico."),
    (None, "Coerenza con short paper camera-ready",
     "manuscript_short_cameraready.md righe 45, 51, 106, 118",
     "stessi numeri spatial nel camera-ready", "Camera-ready riporta gli stessi valori (2,695 / 393,543 / 389,492; 1.7x 10.0 vs 6.0 s; 51.6x 4,068 vs 79 s; 10.8x 1,042 vs 97 s; 3,272x 3,573 -> 1.09 s; rho >= 0.9995; ARI 0.856 / 0.974 / 0.080; '100 cores, 256 GB RAM'). Dice pero' 'All benchmarks ran inside Singularity containers', mentre lo spatial gira con docker run (run_all_benchmarks.sh), e non dichiara la convenzione r2-5.",
     "PASS", "info", "manuscript_short_cameraready.md; SPATIAL/run_all_benchmarks.sh",
     "Coerenza numerica completa, quindi gli errori di A0093, A0089, A0245 ecc. sono gia' nel lavoro pubblicato; correggerli nel full paper creera' divergenze da segnalare."),
]
for line, sec, locator, cl, rc, st, sev, src, note in NEW:
    out.append({"inv_id": None, "track": "B", "line": line, "section": sec, "locator": locator[:200],
                "claimed": cl, "recomputed": rc, "status": st, "severity": sev, "source": src, "note": note})

# controlli
assert len([o for o in out if o["inv_id"]]) == len(inv) == 89
for o in out:
    for k in ("claimed", "recomputed", "source", "note"):
        assert "–" not in o[k] and "—" not in o[k], (o["inv_id"], k)
json.dump(out, open(RV / "tracks/B_findings.json", "w"), indent=1, ensure_ascii=False)
from collections import Counter
print(len(out), Counter(o["status"] for o in out), Counter((o["status"], o["severity"]) for o in out if o["status"] != "PASS"))
