"""Track B: ricalcolo tempi, speedup, memoria spatial dai JSON grezzi.
Uso: python3 -I b01_timings.py /tmp/repo/SPATIAL/results
Convenzioni: media aritmetica delle ripetizioni indicate; SD campionaria (ddof=1);
speedup = media(CPU)/media(GPU) (ratio of means, RoM) e, a parte, media dei rapporti per ripetizione (MoR).
"""
import json, sys, statistics as st
from pathlib import Path

R = Path(sys.argv[1] if len(sys.argv) > 1 else "/tmp/repo/SPATIAL/results")
PLAT = {"visium": "spatial_{p}_visium_r{k}_results.json",
        "hd8": "spatial_{p}_visium_hd_square_008um_r{k}_results.json",
        "hd2": "spatial_{p}_visium_hd_square_002um_r{k}_results.json"}

def load(plat, pipe, k):
    return json.load(open(R / PLAT[plat].format(p=pipe, k=k)))

def mean(xs): return sum(xs) / len(xs)
def sd(xs): return st.stdev(xs) if len(xs) > 1 else float("nan")

out = {}
for plat in PLAT:
    out[plat] = {}
    D = {pipe: {k: load(plat, pipe, k) for k in range(1, 6)} for pipe in ("cpu", "gpu")}
    steps = list(D["cpu"][1]["timings"].keys())
    print(f"\n==================== {plat} ====================")
    for pipe in ("cpu", "gpu"):
        md = D[pipe][1]["metadata"]
        rs = [D[pipe][k]["results_summary"] for k in range(1, 6)]
        print(f"[{pipe}] n_spots_input={md['n_spots_input']} n_genes_input={md['n_genes_input']} n_cpus={md['n_cpus']}"
              f" gpu_info={md.get('gpu_info')} versions={md['software_versions']}")
        print(f"[{pipe}] per-repeat after_qc spots={[r['n_spots_after_qc'] for r in rs]} genes={[r['n_genes_after_qc'] for r in rs]}"
              f" n_hvgs={[r['n_hvgs'] for r in rs]} n_clusters={[r['n_clusters'] for r in rs]}"
              f" svg_moran={[r['n_svgs_moran_fdr005'] for r in rs]} svg_geary={[r['n_svgs_geary_fdr005'] for r in rs]}"
              f" hvg_hash={sorted(set(r['hvg_list_hash'] for r in rs))}")
        print(f"[{pipe}] timestamps={[D[pipe][k]['metadata']['timestamp'] for k in range(1,6)]}")
    print(f"{'step':24s} | {'CPU r1..r5':>48s} | {'GPU r1..r5':>48s}")
    for s in steps:
        c = [D["cpu"][k]["timings"][s] for k in range(1, 6)]
        g = [D["gpu"][k]["timings"][s] for k in range(1, 6)]
        print(f"{s:24s} | {' '.join(f'{x:9.4f}' for x in c)} | {' '.join(f'{x:9.4f}' for x in g)}")
    print("\n-- medie e speedup --")
    print(f"{'step':24s} {'CPU r2-5':>10s} {'SDc':>8s} {'GPU r2-5':>10s} {'SDg':>8s} {'RoM2-5':>9s} {'MoR2-5':>9s} | {'CPU r1-5':>10s} {'GPU r1-5':>10s} {'RoM1-5':>9s} {'MoR1-5':>9s} | {'r2 only':>8s}")
    for s in steps:
        c = [D["cpu"][k]["timings"][s] for k in range(1, 6)]
        g = [D["gpu"][k]["timings"][s] for k in range(1, 6)]
        if min(c) <= 0 or min(g) <= 0:
            print(f"{s:24s} SKIPPED/negative: cpu={c} gpu={g}")
            out[plat][s] = None
            continue
        c25, g25 = c[1:], g[1:]
        rom25 = mean(c25) / mean(g25); mor25 = mean([a / b for a, b in zip(c25, g25)])
        rom15 = mean(c) / mean(g); mor15 = mean([a / b for a, b in zip(c, g)])
        r2 = c[1] / g[1]
        out[plat][s] = dict(cpu25=mean(c25), gpu25=mean(g25), sdc25=sd(c25), sdg25=sd(g25), rom25=rom25, mor25=mor25,
                            cpu15=mean(c), gpu15=mean(g), sdc15=sd(c), sdg15=sd(g), rom15=rom15, mor15=mor15, r2=r2,
                            cpu=c, gpu=g)
        print(f"{s:24s} {mean(c25):10.4f} {sd(c25):8.4f} {mean(g25):10.4f} {sd(g25):8.4f} {rom25:9.2f} {mor25:9.2f} | "
              f"{mean(c):10.4f} {mean(g):10.4f} {rom15:9.2f} {mor15:9.2f} | {r2:8.2f}")
    # verifica che total = somma step >0
    for pipe in ("cpu", "gpu"):
        for k in range(1, 6):
            t = D[pipe][k]["timings"]
            ssum = sum(v for kk, v in t.items() if kk != "total" and v > 0)
            if abs(ssum - t["total"]) > 1e-3:
                print(f"  !! total mismatch {pipe} r{k}: sum={ssum} total={t['total']}")
    # memoria
    print("\n-- memoria (peak per repeat) --")
    for pipe in ("cpu", "gpu"):
        ram = [D[pipe][k]["memory"]["peak_ram_gb"] for k in range(1, 6)]
        vram = [D[pipe][k]["memory"]["peak_vram_gb"] for k in range(1, 6)]
        out[plat][f"{pipe}_ram"] = ram; out[plat][f"{pipe}_vram"] = vram
        print(f"[{pipe}] peak_ram r1-5={ram} mean2-5={mean(ram[1:]):.3f} max={max(ram)} | peak_vram r1-5={vram} mean2-5={mean(vram[1:]):.3f} max={max(vram)}")
    # VRAM baseline (prima del data loading) per GPU
    vb = [D["gpu"][k]["memory"]["detailed"].get("data_loading_vram_before_gb") for k in range(1, 6)]
    print(f"[gpu] data_loading_vram_before_gb r1-5={vb}")
    # quote del tempo
    t = out[plat]
    def m(step, pipe, conv="25"):
        v = t.get(step)
        return 0.0 if v is None else v[f"{pipe}{conv}"]
    for conv in ("25", "15"):
        tc, tg = m("total", "cpu", conv), m("total", "gpu", conv)
        print(f"\n[quote conv r{conv[0]}-{conv[1]}] total CPU={tc:.3f} GPU={tg:.3f}")
        for s in steps:
            if s == "total": continue
            vc, vg = m(s, "cpu", conv), m(s, "gpu", conv)
            # include anche step con -1 come 0
            print(f"   {s:24s} CPU share={100*vc/tc:6.2f}%  GPU share={100*vg/tg:6.2f}%")
    # quote per singola ripetizione per spatial_neighbors e umap su GPU
    for s in ("spatial_neighbors", "umap", "co_occurrence", "ligrec"):
        try:
            sh = [100 * D["gpu"][k]["timings"][s] / D["gpu"][k]["timings"]["total"] for k in range(1, 6)]
            shc = [100 * D["cpu"][k]["timings"][s] / D["cpu"][k]["timings"]["total"] for k in range(1, 6)]
            print(f"   per-repeat share {s}: GPU={['%.2f'%x for x in sh]} CPU={['%.2f'%x for x in shc]}")
        except Exception as e:
            pass

json.dump(out, open(Path(__file__).with_name("b01_timings_out.json"), "w"), indent=1, default=str)
