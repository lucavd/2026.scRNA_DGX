"""Per-repeat spatial totals and mean of r2-r5 vs r1-r5 (sample SD), plus co_occurrence per repeat."""
import json, statistics as st
R = '/tmp/repo/SPATIAL/results'
for plat in ['visium', 'visium_hd_square_008um', 'visium_hd_square_002um']:
    for pipe in ['cpu', 'gpu']:
        tots = []; co = []
        for r in range(1, 6):
            d = json.load(open(f'{R}/spatial_{pipe}_{plat}_r{r}_results.json'))
            tots.append(d['timings']['total']); co.append(d['timings'].get('co_occurrence'))
        print(f'{plat:24s} {pipe}: totals={[round(x,1) for x in tots]} mean_r2-5={st.mean(tots[1:]):.1f} sd={st.stdev(tots[1:]):.1f} mean_r1-5={st.mean(tots):.1f} co_occ={[round(x,1) if x else x for x in co]}')
