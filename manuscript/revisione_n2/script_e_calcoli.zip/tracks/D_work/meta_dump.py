"""Dump metadata of all result JSONs in /tmp/repo/results and SPATIAL/results, grouped by family and distinct values."""
import json, glob, os, collections, sys
SKIP = ('timestamp','repeat_id','input_file','worker_addresses')
def flat(d, p=''):
    out = {}
    if isinstance(d, dict):
        for k, v in d.items():
            out.update(flat(v, f'{p}{k}.'))
    else:
        out[p[:-1]] = d
    return out
roots = sys.argv[1:] or ['/tmp/repo/results', '/tmp/repo/SPATIAL/results']
for root in roots:
    files = sorted(glob.glob(os.path.join(root, '*.json')))
    vals = collections.defaultdict(lambda: collections.defaultdict(set))
    for f in files:
        d = json.load(open(f))
        b = os.path.basename(f)
        if not isinstance(d, dict):
            print('NON-DICT JSON:', b, type(d).__name__, len(d)); continue
        md = d.get('metadata', {})
        fl = flat(md)
        fam = b.split('_')[0]
        if b.startswith('spatial_'):
            fam = '_'.join(b.split('_')[:2])
        if b.startswith('de_'): fam = b
        for k, v in fl.items():
            if any(s in k for s in SKIP): continue
            vals[fam][k].add(json.dumps(v)[:160])
    for fam, kv in vals.items():
        if fam in ('cpu','gpu2','gpu4','concordance'): continue
        print('=====', root, fam)
        for k, s in sorted(kv.items()):
            print(f'  {k}: {sorted(s)[:8]}{" ..." if len(s)>8 else ""}')
