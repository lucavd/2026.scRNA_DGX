"""Mean (r1-r5) and sample SD of per-step timings for cpu, gpu (1 GPU), gpu2/4/8 at each size."""
import json, glob, os, statistics as st
R = '/tmp/repo/results'
sizes = [10000, 50000, 100000, 500000, 1300000]
fams = ['cpu', 'gpu', 'gpu2', 'gpu4', 'gpu8']
steps = ['data_loading','qc_filtering','normalization','hvg_selection','gpu_transfer','scale','pca','neighbors','leiden_0.5','leiden_1.0','leiden_1.5','umap','de_testing','total']
for n in sizes:
    print(f'\n=== N = {n}')
    print('step'.ljust(14) + ''.join(f.rjust(16) for f in fams))
    data = {}
    for f in fams:
        fs = sorted(glob.glob(f'{R}/{f}_{n}_r*_results.json'))
        data[f] = [json.load(open(x))['timings'] for x in fs]
    for s in steps:
        row = s.ljust(14)
        for f in fams:
            v = [t[s] for t in data[f] if s in t]
            row += (f'{st.mean(v):9.2f}±{st.stdev(v):5.2f}' if len(v) > 1 else ('-' if not v else f'{v[0]:9.2f}')).rjust(16)
        print(row)
