"""Timeline of runs with recorded GPU driver version and n_cpus, to test the 'single dedicated node' claim."""
import json, glob, os, collections
R = '/tmp/repo/results'
rows = []
for f in glob.glob(f'{R}/*_results.json'):
    d = json.load(open(f))
    if 'metadata' not in d: continue
    m = d['metadata']
    drv = (m.get('gpu_info') or {}).get('driver_version', '-')
    fam = os.path.basename(f).split('_')[0]
    rows.append((m['timestamp'][:16], fam, os.path.basename(f), drv, m.get('n_cpus')))
rows.sort()
by = collections.defaultdict(list)
for r in rows: by[(r[1], r[3])].append(r[0])
for k, v in sorted(by.items()):
    print(f'{k[0]:10s} driver={k[1]:12s} n={len(v):3d} first={min(v)} last={max(v)}')
