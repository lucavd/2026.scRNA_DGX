"""Spatial JSON: input spots/genes, after-QC spots/genes, HVGs, clusters, skipped steps (-1), n_cpus, driver, per repeat."""
import json, glob, os
R = '/tmp/repo/SPATIAL/results'
for f in sorted(glob.glob(f'{R}/spatial_*_results.json')):
    d = json.load(open(f)); m = d['metadata']; s = d['results_summary']; t = d['timings']
    skipped = [k for k, v in t.items() if v == -1]
    print(f"{os.path.basename(f):52s} in={m['n_spots_input']:>8} genes_in={m['n_genes_input']} qc={s['n_spots_after_qc']:>7} genes_qc={s['n_genes_after_qc']} hvg={s['n_hvgs']} k={s['n_clusters']:>5} svg_m={s['n_svgs_moran_fdr005']} skip={skipped} cpus={m['n_cpus']} drv={(m.get('gpu_info') or {}).get('driver_version','-')} ts={m['timestamp'][:16]}")
