"""Normalisation speedup CPU/1-GPU (mean of r1-r5 each) and per-repeat values, all sizes with 1-GPU data."""
import json, statistics as st
R = '/tmp/repo/results'
for n in (10000, 50000, 100000):
    c = [json.load(open(f'{R}/cpu_{n}_r{r}_results.json'))['timings']['normalization'] for r in range(1, 6)]
    g = [json.load(open(f'{R}/gpu_{n}_r{r}_results.json'))['timings']['normalization'] for r in range(1, 6)]
    print(n, 'cpu', c, 'gpu', g, 'speedup(mean/mean)=%.1f' % (st.mean(c) / st.mean(g)), 'speedup r2-5=%.1f' % (st.mean(c[1:]) / st.mean(g[1:])))
for n in (10000,):
    c = [json.load(open(f'{R}/cpu_{n}_r{r}_results.json'))['timings']['neighbors'] for r in range(1, 6)]
    print('cpu neighbors 10k per repeat', c)
