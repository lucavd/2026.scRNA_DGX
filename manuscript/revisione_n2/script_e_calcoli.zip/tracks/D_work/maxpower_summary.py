"""Summarise maxpower JSONs: target, source, pipeline, clustering, rmm pool, cpu_steps, timings and memory peaks, timestamp."""
import json, glob, os
R = '/tmp/repo/results'
for f in sorted(glob.glob(f'{R}/maxpower_*.json'), key=lambda x: (len(x), x)):
    d = json.load(open(f))
    b = os.path.basename(f)
    if 'metadata' not in d:
        print(b, json.dumps(d)); continue
    m = d['metadata']; c = m['configuration']; t = d['timings']; mem = d['memory']
    print(f"{b}\n  pipe={m['pipeline']} target={m.get('target_cells')} src={m.get('n_cells_source_file')} clust={c.get('clustering_algorithm')} pool={c.get('dask_cluster',{}).get('rmm_pool_size')} pca={c.get('pca_method')} cpu_steps={c.get('cpu_steps')} multi={c.get('multi_gpu_steps')} ts={m['timestamp'][:19]}")
    print(f"  cells_after_qc={d['results_summary']['n_cells_after_qc']} genes_after_qc={d['results_summary']['n_genes_after_qc']} total={t['total']:.0f}s ({t['total']/60:.1f} min) de={t.get('de_testing')} peak_ram={mem['peak_ram_gb']} peak_vram={mem['peak_vram_gb']}")
    print('  timings:', {k: round(v,1) for k,v in t.items()})
    det = mem['detailed']
    print('  ram:', {k.replace('_gb',''): v for k,v in det.items() if 'ram_' in k and 'vram' not in k})
    print('  extra keys:', [k for k in d if k not in ('metadata','timings','memory','results_summary')])
