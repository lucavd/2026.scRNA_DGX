"""VRAM (sum over N GPUs) before/after each step for multi-GPU runs: shows the Dask-startup jump vs the PCA/neighbors deltas."""
import json, glob, os
R = '/tmp/repo/results'
for n in (2, 4, 8):
    for N in (100000, 1300000):
        f = f'{R}/gpu{n}_{N}_r1_results.json'
        d = json.load(open(f)); m = d['memory']['detailed']
        def g(s, w): return m.get(f'{s}_vram_{w}_gb')
        print(f'gpu{n} N={N}: scale after={g("scale","after")}  pca before={g("pca","before")} after={g("pca","after")}  '
              f'neigh before={g("neighbors","before")} after={g("neighbors","after")}  leiden0.5 before={g("leiden_0.5","before")}  peak={d["memory"]["peak_vram_gb"]}')
