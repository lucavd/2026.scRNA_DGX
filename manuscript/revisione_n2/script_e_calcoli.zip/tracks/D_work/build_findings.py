"""Build tracks/D_findings.json (track D, Metodi) from the inventory slice plus new findings.

All numbers quoted in the notes were recomputed by the scripts in this folder:
meta_dump.py, step_timings.py, maxpower_summary.py, driver_timeline.py, multigpu_vram.py,
spatial_meta.py, spatial_totals.py, norm_speedup.py, key_numbers.py.
"""
import json
from pathlib import Path

BASE = Path('/tmp/claude-0/-home-claude/e2229d1f-65c5-5244-af74-f9741477965d/scratchpad/review')
inv = {x['id']: x for x in json.load(open(BASE / 'tracks/inv_D.json'))}
MD = (BASE / 'full_paper_LNBI.md').read_text().splitlines()


def loc_of(i):
    x = inv[i]
    if x.get('kind') == 'table_row':
        return MD[x['line'] - 1][:200]
    return x['text'][:200]


F = []


def add(inv_id, status, severity, claimed, recomputed, source, note, line=None, section=None, locator=None):
    if inv_id is not None:
        x = inv[inv_id]
        line = x['line']
        section = x['section']
        locator = loc_of(inv_id)
    for s in (claimed, recomputed, source, note, locator):
        assert '—' not in s and '–' not in s, s
    F.append({"inv_id": inv_id, "track": "D", "line": line, "section": section, "locator": locator[:200],
              "claimed": claimed, "recomputed": recomputed, "status": status, "severity": severity,
              "source": source, "note": note})


R = '/tmp/repo/results'
W = 'tracks/D_work'

# ---------------------------------------------------------------- dataset
add('A0024', 'MISMATCH', 'critical',
    'Dataset 10x Genomics 1.3M mouse brain E18, h5ad dal repository RAPIDS single-cell examples',
    'Il codice scarica da CZ CELLxGENE Census (versione 2025-11-08) cellule di cervello di topo, is_primary_data, assay 10x 3 v1/v2/v3, e ne campiona 1,300,000 a caso (seed 42); n_genes_after_qc a 1.3M = 39,182 (cpu_1300000_r1), incompatibile con le 27,998 feature del dataset 10x; input_file = brain_1300000.h5ad',
    'scripts/download_data.py righe 25-100 (CENSUS_VERSION, obs_filter, np.random.choice); slurm/download.sh riga 72 (--max-cells 1300000); results/cpu_1300000_r1_results.json results_summary.n_genes_after_qc',
    'Il dataset descritto non e quello analizzato: e un campione casuale multi-studio e multi-donatore di Census, non l E18 10x. Si ripercuote su abstract (1.3-million mouse brain cell dataset), Limitations riga 432 (single dataset E18) e sulla citazione Zheng2017. Il numero 27,998 del dataset 10x non e ricalcolabile dal repo: il punto decisivo e che il codice non scarica mai quel file.')

add('A0025', 'MISMATCH', 'major',
    'Canonical benchmark di circa 1.3 milioni di cellule, 10x Chromium',
    'I dati sono 1,300,000 cellule esatte (n_cells_after_qc 1,299,956) estratte a caso da una selezione Census di 3,436,470 cellule (n_cells_source_file nei JSON maxpower); assay 10x 3 v1/v2/v3, quindi Chromium si, ma non il benchmark canonico',
    'scripts/download_data.py; results/cpu_1300000_r1_results.json; results/maxpower_*_8gpu_results.json metadata.n_cells_source_file',
    'Conseguenza diretta di A0024.')

add('A0026', 'MISMATCH', 'major',
    'Sottocampioni 10k/50k/100k/500k con numpy.random.choice senza reinserimento, NumPy 2.2.6, seed 42, piu il dataset completo 1.3M',
    'Funzione e seed confermati (np.random.seed(42); np.random.choice(n_obs, size, replace=False) in create_subsamples); ma il 1.3M non e un dataset completo: e a sua volta un campione casuale (seed 42) del 37.8% di 3,436,470 cellule Census. La versione NumPy usata al momento del sottocampionamento non e registrata nei file (2.2.6 e quella registrata a runtime nei benchmark)',
    'scripts/download_data.py righe 80-83 e 107-136',
    'Nota di riproducibilita: il target make download-data usa --max-cells 100000 (Makefile riga 35), quindi non ricrea i file del paper.')

# ---------------------------------------------------------------- pipeline
add('A0027', 'MISMATCH', 'major',
    'CPU e GPU con parametri identici (best practice Scanpy)',
    'Parametri non identici: Leiden CPU flavor igraph con n_iterations=2, Leiden GPU rsc.tl.leiden senza n_iterations (default 100 nella documentazione rsc corrente); PCA CPU sklearn arpack (default Scanpy su denso), GPU cuML PCA (svd_solver auto); vicini CPU Scanpy, GPU default algorithm brute',
    'scripts/benchmark_cpu.py righe 236-240; scripts/benchmark_gpu.py righe 306-308; rapids-singlecell v0.14.1 _pca.py (GitHub tag) e pagina API tl.leiden; scanpy.readthedocs.io stable pp.pca (1.12.4)',
    'La differenza di n_iterations incide direttamente su ARI/NMI CPU vs GPU, che il paper attribuisce alla stocasticita tra implementazioni. Le citazioni Luecken2019/Heumos2023 non sono state lette in questa sessione.')

add('A0028', 'PASS', 'info',
    'Scanpy 1.12, NumPy 2.2.6, igraph 1.0.0; rsc 0.14.1, CuPy 13.6.0, RMM 26.2.0, cuGraph',
    'metadata.software_versions: scanpy 1.12, numpy 2.2.6, igraph 1.0.0, leidenalg 0.11.0 (cpu_*); rapids_singlecell 0.14.1, cupy 13.6.0, rmm 26.2.0 (gpu*, maxpower); leiden_backend cugraph (stringa fissa nel codice, versione cuGraph non registrata)',
    f'{W}/meta_dump.py su {R}',
    'Versioni coerenti in tutti i JSON scRNA.')

add('A0029', 'PASS', 'info', 'AnnData come formato condiviso', 'Entrambe le pipeline leggono h5ad con sc.read_h5ad e lavorano su AnnData; versione anndata non registrata',
    'scripts/benchmark_cpu.py riga 159; scripts/benchmark_gpu.py righe 237-240', 'Citazione Virshup2024 non verificata in questa sessione.')

add('A0030', 'MISMATCH', 'minor',
    'Dieci step, ciascuno cronometrato indipendentemente con time.perf_counter()',
    'Chiavi di timing: data_loading, qc_filtering, normalization, hvg_selection, pca, neighbors, leiden_0.5, leiden_1.0, leiden_1.5, umap, de_testing (11). Scaling non e cronometrato a parte (sc.pp.scale / rsc.pp.scale dentro lo step pca); adata.raw = adata.copy() e il subset HVG non sono cronometrati; total = somma degli step, non wall clock',
    'scripts/benchmark_cpu.py righe 207-218 e 272; scripts/benchmark_gpu.py righe 283-291 e 347',
    'Nel percorso multi-GPU compaiono anche gpu_transfer e scale separati; avvio e chiusura del cluster Dask restano fuori dal timing.')

add('A0031', 'MISMATCH', 'minor', 'Parametri identici salvo dove indicato',
    'Differenze non indicate in tabella: n_iterations Leiden (2 vs default GPU), solver PCA, algoritmo kNN', 'come A0027', 'Vedi A0027 e A0040.')

add('A0032', 'PASS', 'info', 'Intestazione Tabella 1', 'Nessuna asserzione verificabile', 'n/a', '')

add('A0033', 'PASS', 'minor', 'Step 1: read_h5ad() da disco',
    'CPU: sc.read_h5ad. GPU singola: lo step data_loading include anche rsc.get.anndata_to_GPU (trasferimento host-device). Multi-GPU: lettura su CPU e trasferimento in uno step gpu_transfer separato',
    'scripts/benchmark_gpu.py righe 237-244; scripts/benchmark_multigpu.py righe 283-334',
    'Lo step non e omogeneo tra configurazioni; utile dichiararlo.')

add('A0034', 'PASS', 'minor', 'min_genes 200, min_cells 3, prefisso mt-',
    'filter_cells(min_genes=200), filter_genes(min_cells=3), mt = startswith(("MT-","mt-")); nessuna soglia su pct_counts_mt: la percentuale mitocondriale e solo calcolata',
    'scripts/benchmark_cpu.py righe 165-175; benchmark_gpu.py righe 248-256',
    'Non e verificabile dal repo che i var_names del file Census siano simboli genici (con ID Ensembl il prefisso mt- non troverebbe geni); comunque non c e filtro mt.')

add('A0035', 'PASS', 'info', 'target_sum 10,000 + log1p', 'normalize_total(target_sum=1e4) e log1p in CPU, GPU, multi-GPU, stress test',
    'scripts/benchmark_cpu.py righe 183-185; benchmark_gpu.py 264-266', '')

add('A0036', 'PASS', 'info', 'n_top_genes 2000, metodo Seurat v1 su dati log-normalizzati',
    'highly_variable_genes(n_top_genes=2000) senza flavor: default seurat in Scanpy e in rsc (pagina API rsc pp.highly_variable_genes: flavor=seurat)',
    'scripts/benchmark_cpu.py righe 196-199; benchmark_gpu.py 271-273; rapids-singlecell.scverse.org API highly_variable_genes',
    'La variante chunked dello stress test usa invece una HVG riscritta a mano (bin per percentili sulla media in log, statistiche sui dati log): non e la stessa procedura (benchmark_maxpower_chunked.py righe 210-300).')

add('A0037', 'PASS', 'minor', 'max_value 10, denso float32, centratura e varianza unitaria',
    'CPU: toarray() poi sc.pp.scale(max_value=10); GPU: rsc.pp.scale(max_value=10) su CSR con zero_center di default. Il dtype float32 non e registrato nei JSON',
    'scripts/benchmark_cpu.py righe 213-215; benchmark_gpu.py riga 288',
    'Nel percorso multi-GPU lo scaling gira su GPU 0, nello stress test su CPU.')

add('A0038', 'MISMATCH', 'minor', 'PCA 50 componenti, seed 42, Truncated SVD',
    'n_comps=50 e random_state=42 confermati. Solver: CPU sc.tl.pca su matrice densa = sklearn PCA con arpack (doc Scanpy 1.12.4); GPU rsc.pp.pca su CuPy denso = cuML PCA, svd_solver None mappato ad auto (sorgente rsc v0.14.1); stress test = eigendecomposizione della covarianza fatta a mano',
    'scripts/benchmark_cpu.py riga 216; benchmark_gpu.py riga 289; github.com/scverse/rapids_singlecell/blob/v0.14.1/src/rapids_singlecell/preprocessing/_pca.py; scanpy.readthedocs.io/en/stable/api/scanpy.pp.pca.html',
    'Truncated SVD non descrive nessuna delle tre implementazioni in modo esatto.')

add('A0039', 'PASS', 'minor', 'k 15, 50 PC, seed 42',
    'neighbors(n_neighbors=15, n_pcs=50, random_state=42) in CPU e GPU',
    'scripts/benchmark_cpu.py riga 223; benchmark_gpu.py riga 296',
    'GPU usa algorithm brute (default rsc 0.14.1, esatto); CPU usa il default Scanpy: algoritmi diversi non dichiarati.')

add('A0040', 'MISMATCH', 'major', 'Leiden r in {0.5,1.0,1.5}, seed 42, igraph (CPU) / cuGraph (GPU)',
    'Risoluzioni, seed e backend confermati; CPU passa n_iterations=2 (commento: required by igraph flavor), GPU usa il default di rsc.tl.leiden (n_iterations=100 nella firma documentata, numero massimo di iterazioni)',
    'scripts/benchmark_cpu.py righe 236-240; benchmark_gpu.py righe 306-308; rapids-singlecell.scverse.org API tl.leiden',
    'Parametro che cambia le partizioni e quindi ARI/NMI; va dichiarato. La firma rsc letta e quella della documentazione corrente, non quella della 0.14.1.')

add('A0041', 'PASS', 'info', 'UMAP 2 componenti, seed 42', 'sc.tl.umap / rsc.tl.umap con random_state=42 e n_components di default',
    'scripts/benchmark_cpu.py riga 254; benchmark_gpu.py riga 325', 'Default di n_components in rsc non letto in documentazione.')

add('A0042', 'PASS', 'info', 'Wilcoxon one-vs-rest, use_raw True, su Leiden r 1.0',
    'rank_genes_groups(groupby="leiden_1.0", method="wilcoxon", use_raw=True); raw contiene tutti i geni log-normalizzati (impostato dopo log1p)',
    'scripts/benchmark_cpu.py righe 259-267; benchmark_gpu.py 330-338', '')

add('A0043', 'PASS', 'major', 'OMP/MKL/OPENBLAS/NUMBA_NUM_THREADS = 100 prima di importare librerie numeriche (100 = core utilizzabili)',
    'threading_vars = 100 in tutti i 25 cpu_*; n_cpus 100; variabili impostate prima di import numpy. Ma il nodo espone 224 CPU logiche (n_cpus 224 nei JSON GPU) e gpu_8.sh chiede --cpus-per-task=200 su un nodo da 112 core: le CPU SLURM sono quindi thread hardware, e 100 CPU SLURM non sono necessariamente 100 core fisici',
    'scripts/benchmark_cpu.py righe 27-59; slurm/cpu_benchmark.sh righe 13 e 95; slurm/gpu_8.sh riga 13; results/*json metadata.n_cpus',
    'La parte su env var e PASS; l equivalenza 100 = core utilizzabili e non verificabile (configurazione SLURM e log assenti) e probabilmente falsa: con hyperthreading 100 CPU possono essere circa 50 core fisici. Tocca anche abstract (100 cores).')

# ---------------------------------------------------------------- multi-GPU
add('A0044', 'MISMATCH', 'major', 'Pipeline ibrida multi-GPU con Dask-CUDA per i dataset oltre la VRAM di una GPU (500k e 1.3M)',
    'gpu2/gpu4/gpu8 eseguiti a tutte le taglie 10k-1.3M (25 JSON per configurazione); il LocalCUDACluster viene avviato ma nessun dato viene convertito in array Dask, quindi nessuno step usa Dask',
    'scripts/benchmark_multigpu.py righe 349-372; slurm/gpu_2.sh, gpu_4.sh, gpu_8.sh (SIZES)', 'Vedi A0047.')

add('A0045', 'MISMATCH', 'critical',
    'Solo PCA e grafo dei vicini avevano implementazioni GPU distribuite usabili nel percorso Dask-CUDA; la GPU singola superava 80 GB a 500k e 1.3M',
    'rapids-singlecell v0.14.1 ha rami Dask per calculate_qc_metrics, normalize_total, log1p, scale e pca (sorgente al tag v0.14.1); il notebook ufficiale out-of-core esegue QC, normalize_total, log1p, highly_variable_genes, scale e pca su AnnData Dask; neighbors 0.14.1 offre mg_ivfflat/mg_ivfpq. Il codice del paper non usa nessun ramo Dask, nemmeno per PCA e vicini. L OOM della GPU singola a 500k/1.3M non ha alcun artefatto nel repo (nessun JSON gpu_500000/gpu_1300000, log esclusi da .gitignore)',
    'github.com/scverse/rapids_singlecell/blob/v0.14.1/src/rapids_singlecell/preprocessing/_normalize.py, _scale.py, _qc.py, _pca.py; raw.githubusercontent.com/.../v0.14.1/.../_neighbors/__init__.py; rapids-singlecell.scverse.org/en/latest/notebooks/06_out-of-core.html; scripts/benchmark_multigpu.py righe 277-372',
    'Il preprocessing su CPU e una scelta di implementazione, non un limite dello stack. Inoltre la RMM pool della GPU singola riserva il 50% della VRAM senza che CuPy la usi (nessun set_allocator), possibile concausa dell OOM non documentata. Tesi centrale (abstract, Discussion righe 418, Limitations riga 432).')

add('A0046', 'MISMATCH', 'major',
    'Il vincolo e dello stack software; su GPU singola la normalizzazione e 329x piu veloce della CPU',
    '329.3x riprodotto come rapporto delle medie r1-r5 a 10k (CPU 0.4281 s, GPU 0.0013 s), ma la media CPU e dominata dalla ripetizione 1 (1.749 s contro 0.098 s, compilazione JIT): escludendo r1 il rapporto e 115.1x (10k), 134.2x (50k), 137.4x (100k). La premessa sullo stack e smentita (vedi A0045)',
    f'{W}/norm_speedup.py su {R}/cpu_*_r*_results.json e gpu_*_r*_results.json timings.normalization',
    'Il valore 329x misura soprattutto il costo di warmup della CPU alla prima ripetizione.')

add('A0047', 'MISMATCH', 'critical',
    'PCA e grafo dei vicini distribuiti su N GPU (2, 4, 8) tramite worker Dask, ciascuno con pool RMM 10 GB / 70 GB',
    'Pool 10GB/70GB confermati (dask_cluster in metadata). Ma rsc.pp.pca e rsc.pp.neighbors ricevono un array CuPy su GPU 0: il ramo Dask non viene mai attivato e i worker restano inattivi. Prove: a 1.3M PCA 0.80/0.60/0.61 s e vicini 16.43/16.39/16.40 s con 2/4/8 GPU; a 100k PCA 0.12-0.13 s con 1, 2, 4 e 8 GPU; il salto di VRAM aggregata all avvio del cluster (+19.6, +39.3, +78.6 GB con 2/4/8 GPU a 1.3M) coincide con N x 10 GB di pool vuote, mentre PCA aggiunge 0.35 GB e i vicini 0.14 GB a ogni N',
    f'{W}/step_timings.py, {W}/multigpu_vram.py, {W}/key_numbers.py su {R}/gpu{{2,4,8}}_*; scripts/benchmark_multigpu.py righe 331-372; sorgente rsc v0.14.1 _pca.py (ramo Dask solo per isinstance(X, DaskArray))',
    'La configurazione 8 GPU e di fatto GPU singola piu preprocessing su CPU. Invalida le affermazioni di scaling multi-GPU (abstract, Results, Discussion riga 418) e la prova di distribuzione di riga 252 (134.2 GB = media dei picchi 93.71, 135.31, 144.23, 150.92, 146.71, gonfiata dalle pool inattive e dall accumulo tra ripetizioni).')

add('A0048', 'PASS', 'minor', 'Scaling, Leiden, UMAP e DE su GPU 0',
    'single_gpu_steps = gpu_transfer, scale, leiden, umap, de_testing (metadata gpu2/4/8); codice coerente',
    'scripts/benchmark_multigpu.py righe 336-422; metadata.configuration',
    'La motivazione (operano sull embedding PCA) non vale per scaling (matrice HVG) ne per DE (raw con tutti i geni). Contraddice la frase precedente della stessa sezione che colloca lo scaling su CPU (finding nuovo riga 88).')

# ---------------------------------------------------------------- concordance
add('A0049', 'PASS', 'info', 'Sei metriche, una per stadio', 'compare_results.py calcola HVG Jaccard, PCA |rho|, kNN Jaccard, ARI, NMI, DE logFC rho',
    'scripts/compare_results.py; results/concordance_10000_r1.json chiavi', 'Calcolate solo su 10k, ripetizione 1.')
add('A0050', 'UNVERIFIABLE', 'info', 'Panel coerente con Tian2019, Duo2020, Luecken2022', 'Fonti non lette in questa sessione', 'n/a', 'Demandato al track delle citazioni.')
add('A0051', 'PASS', 'info', 'Didascalia Tabella 2', 'n/a', 'n/a', '')
add('A0052', 'PASS', 'info', 'Intestazione Tabella 2', 'n/a', 'n/a', '')
add('A0053', 'PASS', 'info', 'HVG Jaccard su 2000 HVG', 'compare_hvgs: |intersezione|/|unione| delle liste HVG CPU e GPU', 'scripts/compare_results.py righe 97-121', '')
add('A0054', 'PASS', 'info', 'Media di |rho| Spearman sui primi 10 PC, segni gestiti', 'compare_pca: spearmanr per PC1-PC10, valore assoluto, media', 'scripts/compare_results.py righe 126-160', '')
add('A0055', 'PASS', 'minor', 'Jaccard medio per cellula dei kNN (k 15)',
    'compare_knn usa gli indici non nulli della matrice obsp distances per riga: in Scanpy la matrice esclude la cellula stessa, quindi gli insiemi hanno al piu k-1 = 14 vicini',
    'scripts/benchmark_cpu.py righe 400-411; compare_results.py righe 279-314', 'k nominale 15, insiemi effettivi da 14: dettaglio da dichiarare. Citazione Luecken2022 non letta.')
add('A0056', 'PASS', 'info', 'ARI delle assegnazioni Leiden', 'sklearn adjusted_rand_score per risoluzione', 'scripts/compare_results.py righe 59-95', 'Hubert1985 non letto.')
add('A0057', 'PASS', 'info', 'NMI', 'sklearn normalized_mutual_info_score (media aritmetica di default)', 'scripts/compare_results.py righe 59-95', 'Vinh2010 non letto.')
add('A0058', 'PASS', 'info', 'Spearman dei logFC dei top 100 geni DE per cluster dopo matching ungherese',
    'linear_sum_assignment sulla contingenza leiden_1.0; per ogni coppia top 100 geni CPU intersecati con la lista GPU, Spearman dei logfoldchanges, media sulle coppie',
    'scripts/compare_results.py righe 164-276', 'Top 100 definiti dal ranking CPU.')

# ---------------------------------------------------------------- stress test
add('A0059', 'PASS', 'info', 'Variante memory-optimised per la capacita massima', 'scripts/benchmark_maxpower.py (pipeline maxpower_8gpu)', 'scripts/benchmark_maxpower.py', '')

add('A0060', 'MISMATCH', 'minor',
    '(i) scaling su CPU; (ii) PCA a covarianza distribuita su 8 GPU, matematicamente equivalente; (iii) lean transfer; (iv) pool RMM 2 GB per worker',
    '(i) sc.pp.scale su CPU: confermato; (ii) confermato lo schema scatter, X_i.T @ X_i, somma ed eigh su GPU 0, proiezione locale, ma senza ricentrare dopo il clipping a max_value=10 (colonne non piu a media zero) e con accumulo float32, quindi non esattamente la PCA standard; lo scatter usa contesti CuPy del processo padre, non Dask; (iii) adata.X sostituito da CSR vuota: confermato; (iv) DASK_RMM_POOL_SIZE = 2GB confermato (rmm_pool_size 2GB nei JSON da 3.4M in su), ma i worker Dask non eseguono alcun calcolo',
    'scripts/benchmark_maxpower.py righe 346-461, 616-667; results/maxpower_*_8gpu_results.json configuration',
    'Il cluster Dask nello stress test e solo un costo (VRAM e processi) senza funzione.')

add('A0061', 'PASS', 'info', 'Ricerca binaria da 3.4M a 13.7M',
    'Coarse: 3,436,470 x k fino a 13,745,880; fine a passi di 100k: la sequenza teorica 12.0M fail, 11.1M, 11.5M, 11.7M, 11.8M, 11.9M ok coincide con i JSON presenti e con maxpower_limit_8gpu.json (max_cells 11,900,000, first_oom_at 12,000,000)',
    'scripts/benchmark_maxpower.py righe 1092-1200; results/maxpower_limit_8gpu.json',
    'Il fallimento a 13.7M non ha artefatti nel repo. Le taglie oltre 3,436,470 sono ottenute replicando il dataset (finding nuovo riga 111).')

# ---------------------------------------------------------------- DE
add('A0062', 'MISMATCH', 'major',
    'raw count matrix (adata.raw.X) di circa 121 GB a 3.4M x 41,000 geni; DE GPU naive impossibile',
    'adata.raw viene assegnato dopo normalize_total e log1p: raw.X contiene valori log-normalizzati, non conteggi. 3,399,892 cellule e 41,321 geni confermati (de_benchmark_*.json); 121 GB non ricalcolabile (nnz non salvato). maxpower_3400000_8gpu_results.json registra de_testing = 209.9 s a 3.4M cellule entro la pipeline (versione del codice non committata; la prima versione committata usava rsc.tl.rank_genes_groups su raw), e le note di rilascio rsc 0.14.1 citano rank_genes_groups su input SciPy sparse',
    'scripts/test_de_benchmark.py righe 130-140; results/de_benchmark_pseudobulk.json; results/maxpower_3400000_8gpu_results.json timings.de_testing; git show 763387c:scripts/benchmark_maxpower.py; rapids-singlecell.scverse.org release notes 0.14.1',
    'impossible non e supportato dai dati del repo stesso.')

add('A0063', 'MISMATCH', 'major',
    'Sette strategie DE in disegno fattoriale test (Wilcoxon, t-test, pseudo-bulk) x strategia GPU (nessuna, scatter 8 GPU, chunk 1 GPU)',
    'Il codice definisce 8 test; i JSON contengono 7 risultati: pseudobulk, ttest_cpu, ttest_scatter, ttest_scatter_clean, ttest_chunk, wilcoxon_scatter, wilcoxon_chunk; wilcoxon_cpu non misurato; pseudo-bulk solo CPU. 3 x 3 = 9 celle, 6 coperte: non e un fattoriale completo. Lo scatter elabora i chunk in sequenza in un solo thread alternando il device (ci % n_gpus), senza concorrenza',
    'scripts/test_de_benchmark.py righe 387-616 e 815-824; results/de_benchmark_*.json',
    'Spiega perche scatter e chunk hanno tempi uguali (826 vs 831 s; 1655 vs 1649 s): non c e parallelismo tra GPU.')

add('A0064', 'PASS', 'info', 'Chunk da 500 geni, 500 x 3.4M x 4 byte circa 6.8 GB',
    'GENE_CHUNK_SIZE 500 e gene_chunk_size 500 nei JSON; 500 x 3,399,892 x 4 = 6.80e9 byte (6.33 GiB)',
    f'scripts/test_de_benchmark.py riga 41; {W}/key_numbers.py',
    'Il picco reale per chunk e maggiore: argsort int64 (13.6 GB) piu ranghi float32, sempre sotto 80 GB.')

add('A0065', 'MISMATCH', 'major',
    'Pseudo-bulk: somma dei conteggi grezzi per donatore x cluster, CPM, log, Wilcoxon',
    'Il codice somma adata.raw.X, che e gia log1p(normalize_total) (A0062), poi applica normalize_total(1e6) e un secondo log1p: somme di valori log-normalizzati, doppio log. Donatori = colonna donor_id di Census (202 donatori da piu studi, non embrioni E18); gruppi con meno di 5 cellule scartati; 2,431 pseudo-campioni su 81 cluster (30.0 per cluster)',
    'scripts/test_de_benchmark.py righe 619-739; results/de_benchmark_pseudobulk.json (n_donors 202, n_pseudobulk_samples 2431)',
    'Se donor_id mancasse il codice creerebbe 20 donatori casuali: qui non e accaduto (202). Il riferimento a Squair2021 non e stato letto. Results riga 321 (a few hundred pseudo-samples per cluster) non torna con 30 per cluster.')

# ---------------------------------------------------------------- spatial
add('A0066', 'MISMATCH', 'major', 'Due dataset 10x pubblici scaricati programmaticamente dal portale 10x',
    'Visium v1: V1_Mouse_Brain_Sagittal_Anterior da cf.10xgenomics.com (Space Ranger 1.1.0). Visium HD: lo script scarica Visium_HD_Tiny_3prime_Dataset (Space Ranger 4.0.1), che la pagina 10x descrive come dataset 3 di cervello di topo ridotto a un angolo del tessuto, 297 MB, non adatto a conclusioni biologiche; i JSON riportano invece 393,543 bin a 8 um, 6,296,688 a 2 um e 19,059 geni',
    'SPATIAL/scripts/download_spatial_data.py righe 26-52 e 202-232; 10xgenomics.com/support/software/space-ranger/4.0/resources/visium-hd-example-data',
    'Il download presente nel repo non sembra produrre il dataset analizzato ne quello descritto (CytAssist, FFPE).')

add('A0067', 'PASS', 'info', 'Visium v1 Sagittal Anterior, 2,695 spot, circa 32,285 geni',
    'n_spots_input 2695, n_genes_input 32285 in tutti i 10 JSON visium', f'{W}/spatial_meta.py', '55 um non verificabile dai dati.')

add('A0068', 'MISMATCH', 'minor', 'Visium HD (CytAssist, FFPE): 8 um 393,543 bin; 2 um sottocampionato da 6.3M a 389,492; 19,059 geni',
    '393,543 e 19,059 confermati; 2 um: n_spots_input 6,296,688, sottocampione di 400,000 bin, 389,492 e il numero dopo QC (min_genes 1) e non la dimensione del sottocampione',
    f'{W}/spatial_meta.py su SPATIAL/results/spatial_*_visium_hd_*',
    'Identita del dataset (CytAssist, FFPE) non verificabile: vedi A0066.')

add('A0069', 'PASS', 'minor', 'Sottocampionamento a circa 400,000 bin con --max-spots per stare nei 24 GB',
    'run_all_benchmarks.sh passa --max-spots 400000 a CPU e GPU; np.random.seed(42), choice senza reinserimento prima del QC',
    'SPATIAL/run_all_benchmarks.sh righe 61-71; SPATIAL/scripts/benchmark_spatial_cpu.py righe 251-256',
    'La motivazione VRAM e il requisito DGX per 6.3M bin non sono verificabili. Effetto metodologico non dichiarato: vedi finding nuovo sul diradamento casuale.')

add('A0070', 'PASS', 'info', 'Due fasi: espressione e statistiche spaziali', 'Phase A e Phase B nel codice', 'SPATIAL/scripts/benchmark_spatial_cpu.py righe 228-428', '')
add('A0071', 'PASS', 'minor', 'Step 1-8 come Tabella 1 salvo min_genes 1 per HD',
    'min_genes = 1 se platform == visium_hd, altrimenti 200; min_cells 3; n_top_genes min(2000, n_vars)',
    'SPATIAL/scripts/benchmark_spatial_cpu.py righe 259-293',
    'Differisce anche la risoluzione Leiden (indicata nella riga 1-8) e Moran/Geary sono calcolati sui soli HVG.')
add('A0072', 'PASS', 'info', 'Intestazione Tabella 3', 'n/a', 'n/a', '')
add('A0073', 'PASS', 'info', 'Leiden r 1.0 per Visium, 0.1 per HD',
    'leiden_res = 0.1 se n_after_qc > 100,000 (HD 8 um 393,543; HD 2 um 389,492), altrimenti 1.0; chiave salvata sempre come leiden_1.0',
    'SPATIAL/scripts/benchmark_spatial_cpu.py righe 325-338; benchmark_spatial_gpu.py righe 375-393',
    'Cluster ottenuti: Visium 16 CPU / 15 GPU; HD 8 um 7 / 3; HD 2 um 2,559 / 538 (534 in r3).')
add('A0074', 'PASS', 'info', 'Vicini spaziali solo CPU, Delaunay', 'sq.gr.spatial_neighbors(coord_type="generic", delaunay=True) in entrambe le pipeline', 'SPATIAL/scripts/benchmark_spatial_gpu.py righe 417-421', 'Uso di scipy.spatial interno a Squidpy non letto nel sorgente.')
add('A0075', 'PASS', 'minor', "Moran's I su GPU, per gene", 'rsc.gr.spatial_autocorr(mode="moran"); calcolato solo sui 2000 HVG (dati gia sottoinsiemati)', 'SPATIAL/scripts/benchmark_spatial_gpu.py righe 444-447; spatial_concordance_*.json n_common_genes 2000', '')
add('A0076', 'PASS', 'minor', "Geary's C su GPU, per gene", 'rsc.gr.spatial_autocorr(mode="geary") sui 2000 HVG', 'SPATIAL/scripts/benchmark_spatial_gpu.py righe 455-458', '')
add('A0077', 'PASS', 'info', 'Co-occurrence su GPU', 'rsc.gr.co_occurrence(cluster_key="leiden_1.0")', 'SPATIAL/scripts/benchmark_spatial_gpu.py righe 466-475', '')
add('A0078', 'PASS', 'info', 'Neighbourhood enrichment solo CPU', 'sq.gr.nhood_enrichment in entrambe', 'SPATIAL/scripts/benchmark_spatial_gpu.py righe 478-486', '')
add('A0079', 'PASS', 'minor', 'Ligand-receptor solo CPU', 'sq.gr.ligrec con n_perms=100, senza seed', 'SPATIAL/scripts/benchmark_spatial_cpu.py righe 409-422', 'Permutazioni non seminate, in contrasto con A0096.')
add('A0080', 'PASS', 'info', 'CPU: Scanpy 1.12 e Squidpy 1.8.1', 'software_versions scanpy 1.12, squidpy 1.8.1 in tutti i spatial_cpu', f'{W}/meta_dump.py', 'Palla2022 non letto.')
add('A0081', 'PASS', 'info', 'GPU: rsc 0.14.1 per espressione e Moran, Geary, co-occurrence', 'rapids_singlecell 0.14.1; spatial_gpu_coverage conferma i passi GPU', f'{W}/meta_dump.py', '')
add('A0082', 'PASS', 'minor', 'Co-occurrence e nhood enrichment saltati oltre 500 cluster',
    'Condizione n_clusters <= 500 nel codice; HD 2 um (2,559 CPU, 538 GPU) saltati in tutte le ripetizioni (timing -1)',
    f'SPATIAL/scripts/benchmark_spatial_cpu.py righe 385-405; {W}/spatial_meta.py',
    'La soglia scatta anche per la GPU (538); motivazione O(k^2) non verificata.')
add('A0083', 'PASS', 'minor', 'Ligrec saltato oltre 100,000 spot', 'Condizione n_after_qc <= 100,000 and n_clusters <= 500; HD saltato (timing -1), Visium v1 eseguito', 'SPATIAL/scripts/benchmark_spatial_cpu.py righe 407-428', 'Seconda condizione (cluster) non dichiarata.')
add('A0084', 'PASS', 'minor', 'Jaccard SVG top-N (50, 100, 200) per Moran e insieme FDR < 0.05',
    'compare_autocorr: nlargest I per top 50/100/200, insieme pval_norm_fdr_bh < 0.05; sempre entro i 2000 HVG (n_common_genes 2000)',
    'SPATIAL/scripts/compare_spatial_results.py righe 142-167; SPATIAL/results/spatial_concordance_*.json',
    'Il complete set of genes e limitato agli HVG.')

# ---------------------------------------------------------------- hardware
add('A0085', 'MISMATCH', 'major', 'Un singolo nodo DGX H100: 8 H100 80 GB SXM, NVLink 4.0, 2 Xeon 8480C (112 core), 2 TB DDR5',
    'GPU: 8 x NVIDIA H100 80GB HBM3, 79.6 GB (gpu8, maxpower). Nodo singolo smentito: gpu, gpu2, gpu4 registrano driver 535.247.01, gpu8 e maxpower 535.183.01, con esecuzioni sovrapposte nel tempo (gpu1/2/4 tra 21:53 e 23:03, gpu8 tra 21:54 e 23:00 del 2026-03-15). n_cpus 224 logiche, coerente con 112 core ma modello CPU, NVLink e RAM non registrati',
    f'{W}/driver_timeline.py e {W}/meta_dump.py su {R}',
    'Almeno due nodi diversi; NVLink 4.0, Xeon 8480C e 2 TB non verificabili (il valore 2048 nel codice maxpower e una costante, non una misura).')
add('A0086', 'PASS', 'info', 'Container Singularity da nvcr.io/nvidia/rapidsai/base:26.02-cuda12-py3.12',
    'Dockerfile FROM nvcr.io/nvidia/rapidsai/base:26.02-cuda12-py3.12; SLURM eseguono sc-benchmark.sif con singularity 4.2.0', 'Dockerfile riga 3; slurm/*.sh', 'Vale per scRNA, non per lo spatial (Docker).')
add('A0087', 'PASS', 'info', 'Scanpy 1.12, rsc 0.14.1, CuPy 13.6.0, Dask 2026.1.1, Dask-CUDA 26.2.0, Python 3.12.12',
    'Valori identici nei metadata gpu2/4/8 e maxpower', f'{W}/meta_dump.py', 'constraints.txt pinna invece dask 2024.5.1 e numpy 1.26.4: vedi A0095.')
add('A0088', 'MISMATCH', 'major', 'Job SLURM su un nodo DGX H100 dedicato (poddgx02)',
    '--nodelist=poddgx02 solo in maxpower*, de_benchmark, download_full, test_memopt; assente in cpu_benchmark.sh e gpu_1/2/4/8.sh. Due versioni di driver nei JSON (A0085); gpu_1, gpu_2, gpu_4 girano in contemporanea (16, 32, 56 CPU e 256/512/1024 GB richiesti), quindi il nodo non era dedicato a un job alla volta. Hostname non registrato nei JSON (solo nei log, esclusi dal repo)',
    'slurm/*.sh righe SBATCH; results metadata gpu_info.driver_version e timestamp',
    'I benchmark principali (Table 4, Fig. 1-2) non sono legati a poddgx02 da alcun artefatto.')
add('A0089', 'MISMATCH', 'major', 'Workstation: RTX 4090 24 GB, 100 core, 256 GB DDR5, driver 550.x',
    'RTX 4090 24.0 GB confermata; driver registrato 580.126.09 in tutti i 15 spatial_gpu; n_cpus 128 (os.cpu_count) e, non passando --n-cpus, le variabili di threading valgono 128, non 100; RAM non registrata',
    f'{W}/spatial_meta.py; SPATIAL/run_all_benchmarks.sh (nessun --n-cpus); SPATIAL/scripts/benchmark_spatial_cpu.py righe 26-46',
    'Il 550.x sembra ripreso dal commento di Dockerfile.spatial (driver 550+), non dalla misura.')
add('A0090', 'PASS', 'minor', 'Container spatial sulla stessa base con Squidpy 1.8.1 e spatialdata',
    'Dockerfile.spatial FROM stessa immagine; installa squidpy, spatialdata, spatialdata-io senza versione; squidpy 1.8.1 registrato; versione spatialdata non registrata',
    'SPATIAL/Dockerfile.spatial; requirements-squidpy.txt (spatialdata==0.3.0, non referenziato dal Dockerfile)', '')
add('A0091', 'UNVERIFIABLE', 'major', 'scRNA eseguito via forward-compatibility; componenti GPU spatial falliti sul driver 535.183.01, che limita il runtime a CUDA 12.2',
    'Nessun log del fallimento nel repo; SPATIAL.md dice solo blocked, needs driver 570+. Il ramo 535 corrisponde a CUDA 12.2 (CUDA 12.2 richiede >= 535.54.03) ma la minor version compatibility consente runtime 12.x da >= 525.60.13; parte dei job scRNA girava su 535.247.01, non su 535.183.01',
    'SPATIAL/SPATIAL.md riga 263; docs.nvidia.com/cuda/archive/12.2.2/cuda-toolkit-release-notes/index.html; results metadata driver_version',
    'Caps CUDA runtime at 12.2 e impreciso; il meccanismo (forward vs minor version compatibility) non e documentato.')
add('A0092', 'MISMATCH', 'major', 'Tentato downgrade a RAPIDS 25.02, dipendenze non risolvibili',
    'Nel repo il downgrade documentato e verso RAPIDS 24.06 (constraints.txt: Pin RAPIDS 24.06 base packages; Dockerfile.spatial riga 4; SPATIAL.md riga 265: rapidsai/base:24.06-cuda12.2-py3.11, tested: CuPy/RMM/rsc all pass on driver 535); nessuna traccia di 25.02 per lo spatial',
    'constraints.txt; SPATIAL/Dockerfile.spatial; SPATIAL/SPATIAL.md righe 263-265',
    'Le note del progetto riportano l esito opposto (stack funzionante su 535 con 24.06).')
add('A0093', 'MISMATCH', 'critical', 'Spatial: ripetizione 1 = warmup JIT esclusa; media delle ripetizioni 2-5',
    'Le medie r2-5 riproducono i numeri del paper (Visium 10.0/6.0 s, HD 8 um 4068.4/78.8 s = 51.6x, HD 2 um 1042.0/96.7 s = 10.8x), ma per HD 8 um la ripetizione 1 CPU e la piu veloce, non la piu lenta: total 584.6 s contro 4062-4080 s, co-occurrence 73.5 s contro 3573.2 s di media. Con la sola r1 lo speedup e 6.4x (584.6/91.4) e la co-occurrence 29.3x invece di circa 3,280x. Nessuno script calcola le medie: generate_spatial_figures.py contiene i numeri scritti a mano',
    f'{W}/spatial_totals.py e {W}/key_numbers.py su SPATIAL/results/spatial_*_r*_results.json; figures/generate_spatial_figures.py righe 48-52',
    'Il criterio di esclusione e contraddetto dai dati e decide i numeri dell abstract (51.6x, 3,272x). In scRNA, invece, la r1 resta nelle medie (vedi finding nuovo riga 165).')

# ---------------------------------------------------------------- reproducibility
add('A0094', 'MISMATCH', 'minor', 'Codice, Dockerfile, script SLURM e JSON disponibili nel repo',
    'Presenti: script, Dockerfile e Dockerfile.spatial, 16 script SLURM, 142 JSON scRNA, 33 JSON spatial (30 run e 3 di concordanza) e 30 file .npy, licenza MIT. Assenti per .gitignore: CSV di cluster, HVG, DE, kNN, loadings PCA e Moran/Geary (le metriche di concordanza non sono ricalcolabili), log SLURM (nessuna prova dei fallimenti OOM a 12M, 13.7M, 14M, 15M e della GPU singola). Il codice HEAD non e quello che ha prodotto alcuni risultati: chunked 12M (JSON 2026-03-24T03:13Z, script modificato il 2026-03-24 09:16 e il 2026-03-25 con raw per riferimento e niente tocsc completo), maxpower 1.7M e 3.4M (versioni intermedie mai committate); nei JSON non c e hash git',
    '.gitignore righe 127-135; git log scripts/benchmark_maxpower_chunked.py; git show 46d78f2 e a54da19',
    'Make download-data usa --max-cells 100000 e non ricrea i dati del paper.')
add('A0095', 'MISMATCH', 'major', 'Tutti i benchmark in Singularity da lucavd/sc-benchmark:latest, che pinna l ambiente (Scanpy 1.12, rsc 0.14.1, CuPy 13.6.0, RMM 26.2.0, NumPy 2.2.6, igraph 1.0.0)',
    'Lo spatial gira con docker run su lucavd/sc-benchmark-spatial:latest. Il Dockerfile non pinna nulla (pip install --no-deps rapids-singlecell e scanpy, numpy, igraph senza versione) e il tag latest e mutabile; constraints.txt (dask 2024.5.1, numpy 1.26.4, scipy 1.14.0) non e usato dal Dockerfile e contraddice le versioni registrate (numpy 2.2.6, dask 2026.1.1)',
    'Dockerfile righe 19-38; SPATIAL/run_all_benchmarks.sh righe 6-7; constraints.txt; metadata software_versions',
    'Le versioni sono documentate dai JSON, non garantite dall immagine; senza digest dell immagine l ambiente non e ricostruibile.')
add('A0096', 'PASS', 'minor', 'Seed 42 per sottocampionamento, PCA, Leiden, UMAP',
    'RANDOM_SEED = 42 passato a choice, pca, neighbors, leiden, umap in tutti gli script, e a resize_dataset e cuML KMeans',
    'scripts/*.py; SPATIAL/scripts/*.py', 'Eccezione: sq.gr.ligrec senza seed (A0079).')
add('A0097', 'PASS', 'info', 'Non determinismo GPU da riduzioni non associative [Shanmugavelu2024; Collange2015]',
    'Collange et al. 2015 (Parallel Computing 49:83-97), abstract: reductions may become non-deterministic mainly due to the non-associativity of floating-point operations; Shanmugavelu et al. SC24-W: variability caused by floating-point non-associativity coupled with asynchronous parallel operations such as reductions',
    '/tmp/repo/manuscript/bibliography/1-s2.0-S0167819115001155-main.pdf p.1; Impacts_of_floating-point_non-associativity...pdf p.1', 'Metadati bib coerenti con i PDF.')

# ================================================================ new findings
SEC_MG = 'Data and Methods > Single-cell RNA-seq > Multi-GPU pipeline'
SEC_AP = 'Data and Methods > Single-cell RNA-seq > Analysis pipeline'
SEC_ST = 'Data and Methods > Single-cell RNA-seq > Stress test: maximum capacity'
SEC_HW = 'Data and Methods > Hardware and software environment'

add(None, 'MISMATCH', 'major', 'Nella pipeline ibrida lo scaling gira su CPU',
    'Lo scaling e rsc.pp.scale su GPU 0 dopo anndata_to_GPU; metadata.cpu_steps = data_loading, qc_filtering, normalization, hvg_selection (senza scale) e single_gpu_steps include scale',
    'scripts/benchmark_multigpu.py righe 330-340; results/gpu{2,4,8}_* metadata.configuration',
    'Contraddizione interna con riga 90 (A0048). Testo riscritto il 2 settembre.',
    line=88, section=SEC_MG, locator=MD[87][:200])

add(None, 'MISMATCH', 'major', 'RMM pool pre-riserva VRAM e ammortizza le allocazioni; warmup assorbe l inizializzazione CUDA',
    'rmm.reinitialize(pool_allocator=True) senza cupy.cuda.set_allocator(rmm_cupy_allocator): le allocazioni CuPy (gran parte di rsc) non passano dalla pool, che riserva il 50% della VRAM (initial_pool 50% nei metadata gpu_*) per cuML/cuGraph. Il warmup e un prodotto 100x100: la r1 GPU resta piu lenta (es. normalizzazione 10k 0.0031 s contro 0.0009 s, qc 10k sd 0.11 su media 0.12)',
    'scripts/benchmark_gpu.py righe 159-207; grep set_allocator su /tmp/repo (nessun risultato); docs.nvidia.com/rmm/latest/user_guide/guide (CuPy richiede set_allocator); sorgente rsc v0.14.1 __init__.py (nessun set_allocator)',
    'La pool inutilizzata riduce la VRAM disponibile a CuPy e puo aver contribuito all OOM della GPU singola a 500k e 1.3M (non verificabile).',
    line=83, section=SEC_AP, locator=MD[82][:200])

add(None, 'UNVERIFIABLE', 'minor', 'Nell immagine RAPIDS NumPy e linkato a OpenBLAS',
    'Il campo registrato a runtime numpy_blas_backend vale "blas" in tutti i 25 cpu_*, non openblas',
    'results/cpu_*_results.json metadata.configuration.numpy_blas_backend; scripts/benchmark_cpu.py righe 124-131',
    'Il nome generico blas di conda-forge non identifica l implementazione.',
    line=82, section=SEC_AP, locator=MD[81][MD[81].find('Only the pool'):][:200])

add(None, 'MISMATCH', 'major', 'RSS del solo processo padre, campionato prima e dopo ogni step, preceduto da garbage collection; picco = massimo dei campioni post-step',
    'RSS via psutil e picco = max dei *_ram_after_gb confermati; gc.collect() precede solo il campione pre-step. La replica del dataset (resize_dataset, anndata.concat di copie intere) avviene tra data_loading e qc fuori da ogni step: a 11.9M il salto e 426.10 - 123.76 = 302.34 GB, il presunto aumento non attribuito di Results riga 262 e Table 6. Il picco transitorio della concatenazione (copie piu risultato) non viene mai campionato. La VRAM e NVML used per device sommata su tutte le GPU (include pool dei worker e altri processi)',
    f'scripts/benchmark_maxpower.py righe 103-151 e 468-524, 577-582; {W}/key_numbers.py su {R}/maxpower_11900000_8gpu_results.json',
    'L aumento di 302 GB e attribuibile dal codice. Testo riscritto il 2 settembre.',
    line=111, section=SEC_ST, locator=MD[110][MD[110].find('CPU memory'):][:200])

add(None, 'MISMATCH', 'major', 'Stress test descritto come pipeline memory-optimised su dataset fino a 11.9M cellule',
    'Non dichiarato nei Metodi: sorgente = Census brain_full_3436470 (non il dataset 1.3M); le taglie oltre 3,436,470 sono copie intere replicate con obs_names rinominati (6.9M = 2 copie, 10.3M = 3, 11.9M = 3 copie piu 1,590,590 cellule campionate). Effetti sui risultati: geni dopo QC 41,344 (3.44M), 42,394 (6.87M), 44,158 (da 10.3M in su) perche min_cells=3 viene superato dalle copie; cellule duplicate nel kNN. Binary search con --skip-de; righe 3.4M, 6.9M, 10.3M con cuML KMeans k = 50/100/200',
    'scripts/benchmark_maxpower.py righe 468-524, 682-712, 1070; results/maxpower_*_8gpu_results.json results_summary.n_genes_after_qc e configuration.clustering_algorithm',
    'Un revisore chiederebbe se 11.9M cellule replicate equivalgono a 11.9M cellule reali (grafo, Leiden, memoria).',
    line=109, section=SEC_ST, locator=MD[108][:200])

add(None, 'MISMATCH', 'major', 'Strategie DE GPU (scatter, chunk-and-stream) confrontate con la CPU',
    'I test GPU non usano rsc.tl.rank_genes_groups ma kernel CuPy scritti a mano: Wilcoxon con ranghi ordinali da argsort (nessuna media sui pareggi, frequentissimi nei dati sparsi), nessun p-value ne correzione multipla; t-test di Welch ricalcola le somme totali per ogni gruppo. I tempi GPU partono dopo la conversione tocsc() di raw.X, inclusa invece nei tempi CPU di Scanpy',
    'scripts/test_de_benchmark.py righe 169-313, 403-421, 468-482',
    'Scelte che cambiano sia i risultati statistici sia i tempi della Table 7 e non sono descritte nei Metodi.',
    line=115, section='Data and Methods > Single-cell RNA-seq > Differential expression at scale', locator=MD[114][MD[114].find('We evaluated'):][:200])

add(None, 'MISMATCH', 'major', "Concordanza spaziale: Spearman dei Moran's I (e Geary's C) per gene su tutti i geni; co-occurrence confrontata sulle matrici complete",
    "Moran e Geary sono calcolati solo sui 2000 HVG (n_common_genes 2000 nei JSON di concordanza). La co-occurrence non e confrontabile a HD 8 um: status shape_mismatch (CPU 7 x 7 x 49, GPU 3 x 3 x 49) perche CPU e GPU trovano 7 e 3 cluster; a HD 2 um e saltata",
    'SPATIAL/scripts/benchmark_spatial_cpu.py righe 361-367; SPATIAL/results/spatial_concordance_visium_hd_square_008um.json (r1)',
    'Riga non inventariata. across all genes va corretto in across the 2,000 HVGs.',
    line=149, section='Data and Methods > Spatial transcriptomics > Spatial concordance metrics', locator=MD[148][MD[148].find('Spatial autocorrelation concordance'):][:200])

add(None, 'MISMATCH', 'major', 'Benchmark Visium HD a 2 um',
    'Il sottocampione casuale tiene il 6.35% dei bin (400,000/6,296,688): la distanza media tra bin passa da 2 um a circa 7.9 um (fattore 1/sqrt(0.0635) = 3.97), quindi grafo di Delaunay, Moran e co-occurrence non descrivono la risoluzione 2 um',
    f'{W}/key_numbers.py; SPATIAL/scripts/benchmark_spatial_cpu.py righe 251-256',
    'Il confronto 8 um contro 2 um (Results riga 367 e Fig. 7) e confuso dal diradamento; serve un sottocampione spaziale contiguo (ritaglio) o il dataset completo.',
    line=122, section='Data and Methods > Spatial transcriptomics > Datasets', locator=MD[121][MD[121].find('The Visium HD 2 um dataset'):][:200])

add(None, 'MISMATCH', 'major', 'Ogni configurazione ripetuta cinque volte; media +/- SD',
    'scRNA: media su r1-r5 con SD campionaria (ddof=1 in generate_figures.py), r1 inclusa anche se contiene JIT (CPU neighbors 10k r1 19.90 s contro circa 1.12 s; normalizzazione 10k 1.749 contro 0.098 s); spatial: r1 esclusa. Stress test, DE e varianti chunked hanno una sola esecuzione; concordanza solo r1 a 10k. Le ripetizioni girano nello stesso processo: VRAM di gpu8 1.3M sale da 93.71 GB (r1) a 135-151 GB (r2-r5)',
    f'scripts/generate_figures.py righe 144-146; {W}/norm_speedup.py; {W}/key_numbers.py; results/maxpower_*, de_benchmark_*',
    'Convenzioni diverse tra modalita, non dichiarate; five independent repeats dell abstract non regge.',
    line=165, section=SEC_HW, locator=MD[164][:200])

add(None, 'MISMATCH', 'major', 'Miglioramento del 12% da 2 a 8 GPU a 1.3M dovuto alla struttura della pipeline (Amdahl)',
    'Totali medi 493.29 s (2 GPU) e 435.18 s (8 GPU), riduzione 11.8%; la differenza (58.11 s) coincide con quella del caricamento dati da disco su CPU (148.99 contro 90.61 s, 58.38 s), mentre PCA e vicini sono identici. Le corse 8 GPU girano su un nodo con driver diverso (535.183.01) dalle 2 e 4 GPU (535.247.01), in parallelo ad esse',
    f'{W}/key_numbers.py e {W}/driver_timeline.py su {R}/gpu{{2,8}}_1300000_r*',
    'Fuori fetta (Discussion), ma deriva dai Metodi multi-GPU: il 12% e un effetto di I/O e di nodo, non di scaling GPU.',
    line=418, section='Discussion', locator=MD[417][MD[417].find('The relatively modest'):][:200])

add(None, 'MISMATCH', 'major', 'Variante chunked: 12.0M cellule, 862 GB RAM, 10 GB VRAM, 156 min',
    'maxpower_chunked_12000000_8gpu_results.json: total 7891.2 s = 131.5 min, peak_ram 861.7 GB, peak_vram 9.6 GB. 156 min (9,363 s) compare solo in CLAUDE.md',
    f'{W}/key_numbers.py',
    'Fuori fetta (Results); il JSON e stato prodotto da una versione dello script diversa da HEAD (A0094).',
    line=267, section='Results > Single-cell RNA-seq > Stress test', locator=MD[266][MD[266].find('This variant succeeded'):][:200])

add(None, 'MISMATCH', 'minor', 'Pseudo-bulk 128 s, 43.7x rispetto al t-test CPU (5,598 s); qualche centinaio di pseudo-campioni per cluster',
    'time 127.47 s (arrotonda a 127); 5,597.79/127.47 = 43.9x; 2,431 pseudo-campioni su 81 cluster = 30.0 per cluster',
    f'{W}/key_numbers.py su {R}/de_benchmark_pseudobulk.json e de_benchmark_ttest_cpu.json',
    'Fuori fetta (Results riga 308-321, abstract 44x).',
    line=321, section='Results > Single-cell RNA-seq > Differential expression', locator=MD[320][:200])

out = BASE / 'tracks/D_findings.json'
json.dump(F, open(out, 'w'), indent=1, ensure_ascii=False)
ids = [f['inv_id'] for f in F if f['inv_id']]
missing = set(inv) - set(ids)
assert not missing, missing
from collections import Counter
print(len(F), 'findings;', Counter(f['status'] for f in F), Counter((f['status'], f['severity']) for f in F if f['status'] == 'MISMATCH'))
