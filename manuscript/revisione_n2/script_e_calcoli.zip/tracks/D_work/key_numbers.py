"""Key numbers cited in D_findings.json, recomputed from repo JSONs."""
import json, statistics as st, math
R = '/tmp/repo/results'; S = '/tmp/repo/SPATIAL/results'
J = lambda p: json.load(open(p))
# multi-GPU 1.3M: totals and data loading, mean r1-r5
for n in (2, 4, 8):
    rs = [J(f'{R}/gpu{n}_1300000_r{r}_results.json')['timings'] for r in range(1, 6)]
    print(f'gpu{n} 1.3M total={st.mean(t["total"] for t in rs):.2f} load={st.mean(t["data_loading"] for t in rs):.2f} pca={st.mean(t["pca"] for t in rs):.2f} neigh={st.mean(t["neighbors"] for t in rs):.2f}')
t2 = st.mean(J(f'{R}/gpu2_1300000_r{r}_results.json')['timings']['total'] for r in range(1, 6))
t8 = st.mean(J(f'{R}/gpu8_1300000_r{r}_results.json')['timings']['total'] for r in range(1, 6))
print('reduction 2->8 = %.1f%%' % (100 * (t2 - t8) / t2))
# peak VRAM 8 GPU 1.3M per repeat and mean
pk = [J(f'{R}/gpu8_1300000_r{r}_results.json')['memory']['peak_vram_gb'] for r in range(1, 6)]
print('gpu8 1.3M peak VRAM per repeat', pk, 'mean %.2f' % st.mean(pk))
# 11.9M stress: jump between data_loading_after and qc_before
m = J(f'{R}/maxpower_11900000_8gpu_results.json')['memory']['detailed']
print('11.9M jump load->qc = %.2f GB' % (m['qc_filtering_ram_before_gb'] - m['data_loading_ram_after_gb']))
# chunked 12M total
c = J(f'{R}/maxpower_chunked_12000000_8gpu_results.json')
print('chunked 12M total = %.1f s = %.1f min, peak RAM %.1f, peak VRAM %.1f' % (c['timings']['total'], c['timings']['total'] / 60, c['memory']['peak_ram_gb'], c['memory']['peak_vram_gb']))
# DE pseudobulk
pb = J(f'{R}/de_benchmark_pseudobulk.json')['results']['pseudobulk']; tc = J(f'{R}/de_benchmark_ttest_cpu.json')['results']['ttest_cpu']['time']
print('pseudobulk time %.2f s, samples %d, donors %d, clusters %d, per-cluster %.1f, speedup vs ttest_cpu %.1f' % (pb['time'], pb['n_pseudobulk_samples'], pb['n_donors'], pb['n_clusters'], pb['n_pseudobulk_samples'] / pb['n_clusters'], tc / pb['time']))
print('chunk bytes 500 x 3399892 x 4 = %.2f GB (1e9) = %.2f GiB' % (500 * 3399892 * 4 / 1e9, 500 * 3399892 * 4 / 2**30))
# spatial 2um thinning
f = 400000 / 6296688
print('HD2um sampling fraction %.4f, mean spacing factor %.2f -> %.1f um' % (f, 1 / math.sqrt(f), 2 / math.sqrt(f)))
# spatial r1 vs r2-5
for p in ('cpu', 'gpu'):
    ts = [J(f'{S}/spatial_{p}_visium_hd_square_008um_r{r}_results.json')['timings'] for r in range(1, 6)]
    print(p, 'HD8 total r1 %.1f, mean r2-5 %.1f; co_occ r1 %.2f mean r2-5 %.2f' % (ts[0]['total'], st.mean(t['total'] for t in ts[1:]), ts[0]['co_occurrence'], st.mean(t['co_occurrence'] for t in ts[1:])))
