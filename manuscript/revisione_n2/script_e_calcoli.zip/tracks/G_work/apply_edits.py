"""Apply tier 1 and tier 2 style edits to a copy of full_paper_LNBI.md.

Each edit: (loc, tier, old, new, reason[, was_disp, now_disp]).
old must occur exactly once in the current text. Original line numbers are
computed against the untouched original and reported in the change table.
"""
import json, sys

ORIG = "/tmp/claude-0/-home-claude/e2229d1f-65c5-5244-af74-f9741477965d/scratchpad/review/full_paper_LNBI.md"
OUT = "/tmp/claude-0/-home-claude/e2229d1f-65c5-5244-af74-f9741477965d/scratchpad/review/tracks/G_work/full_paper_LNBI_style.md"
LOG = "/tmp/claude-0/-home-claude/e2229d1f-65c5-5244-af74-f9741477965d/scratchpad/review/tracks/G_work/edit_log.json"

orig = open(ORIG, encoding="utf-8").read()
text = orig
log = []

def oline(s):
    i = orig.find(s)
    return orig.count("\n", 0, i) + 1 if i >= 0 else None

def E(loc, tier, old, new, reason, anchor=None, group=None):
    global text
    n = text.count(old)
    if n != 1:
        sys.exit(f"EDIT FAILED ({n} matches) at {loc}: {old[:80]!r}")
    ln = oline(anchor if anchor else old)
    text = text.replace(old, new, 1)
    log.append({"loc": loc, "line": ln, "tier": tier, "was": old, "now": new,
                "reason": reason, "group": group})

# ---------------------------------------------------------------- Tier 1
# Table cells '---' render as em dashes under pandoc smart typography.
E("Table 1", 1, "| 1 | Data loading | --- |", "| 1 | Data loading | none |",
  "Cell rendered as em dash", group="emdash")
import re as _re
_rows = _re.findall(r"\| CPU \(Scanpy\) \| [0-9.kM]+ \| 0 \| [^\n]*\| --- \|", text)
for r in _rows:
    E("Table 4", 1, r, r[:-5] + "n.a. |", "Cell rendered as em dash", group="emdash")
for r in ["| 12.0M | --- | --- | --- | Leiden | Fail (Leiden OOM) |",
          "| 13.7M | --- | --- | --- | Leiden | Fail (scale OOM) |"]:
    E("Table 5", 1, r, r.replace("---", "n.a."), "Cell rendered as em dash", group="emdash")

E("Table 2", 1, "| PCA loading |rho| |", "| PCA loading \\|rho\\| |",
  "Unescaped pipes split row; definition lost")

E("Introduction", 1, "neighbourhood graph construction, Leiden",
  "neighbour graph construction, Leiden", "Term unified: neighbour graph", group="ngraph")

E("Methods, CPU threading", 1, "is actually active at runtime", "is active at runtime",
  "'actually' as emphasis removed", group="actually")

E("Results, spatial Fig. 9", 1,
  "at high granularity.](../figures/fig9_spatial_concordance.png)\nMoran's I",
  "at high granularity.](../figures/fig9_spatial_concordance.png)\n\nMoran's I",
  "Blank line restores figure and caption")
E("Fig. 9 caption", 1, "between cugraph and leidenalg", "between cuGraph and leidenalg",
  "Product name capitalisation")
E("Fig. 8 caption", 1, "(spatial_neighbors, nhood_enrichment)",
  "(`spatial_neighbors`, `nhood_enrichment`)", "Function names set as code")

E("Discussion, Limitations", 1, "how the optimization generalises",
  "how the optimisation generalises", "-ise spelling (majority 46:1)")

E("Results, memory", 1, "(1.3M x 2,000 HVGs x 4 bytes approximately  10.4 GB)",
  "(1.3M x 2,000 HVGs x 4 bytes, approximately 10.4 GB)", "Punctuation and double space")

E("Abstract", 1, "reducing a 14.5-hour analysis to 7.3 minutes.",
  "reducing a 14.5-hour analysis to 7.3 min.", "Unit 'min' unified after numerals", group="min")
E("Results, DE", 1, "completing in 128 seconds (2.1 minutes), a 43.7x speedup relative to the cell-level CPU t-test baseline (5,598 s, 93 minutes).",
  "completing in 128 s (2.1 min), a 43.7x speedup relative to the cell-level CPU t-test baseline (5,598 s, 93 min).",
  "Units 's' and 'min' unified after numerals", group="min")
E("Discussion", 1, "to 7.3 minutes) translates", "to 7.3 min) translates",
  "Unit 'min' unified after numerals", group="min")
E("Conclusions", 1, "to 7.3 minutes at 1.3M cells", "to 7.3 min at 1.3M cells",
  "Unit 'min' unified after numerals", group="min")

# ---------------------------------------------------------------- Tier 2
# Abstract
E("Abstract", 2,
  "These results identify CPU-side preprocessing as the primary bottleneck and provide practical guidance for deploying GPU-accelerated workflows at atlas scale.",
  "These results identify CPU-side preprocessing as the primary bottleneck.",
  "Stock closing half-sentence cut")

# Introduction
E("Introduction", 2,
  "neighbourhood enrichment on top of the standard expression analysis workflow.\nAs both single-cell and spatial datasets grow, the need for GPU-accelerated analysis becomes increasingly pressing.\n",
  "neighbourhood enrichment on top of the standard expression analysis workflow.\n",
  "Stock paragraph closer without content cut",
  anchor="As both single-cell and spatial datasets grow")
E("Introduction", 2,
  "Here we present a comprehensive benchmark addressing five questions simultaneously.",
  "Here we present a benchmark that addresses five questions.",
  "Marker word and filler removed")

# Methods
E("Methods, Multi-GPU pipeline", 2,
  "In this hybrid pipeline, data loading, QC, normalisation, HVG selection and scaling executed on the host CPU. This reflects the structure of the available software rather than a design preference: at 500k and 1.3M cells the standard single-GPU pipeline exceeded the 80 GB VRAM of a single H100 (Table 4), so the Dask-CUDA path was the only way to run these dataset sizes at all, and within that path only PCA and neighbour graph construction had distributed GPU implementations usable for the pipeline as configured here. The constraint is therefore one of the current software stack, not a property of the operations themselves: on a single GPU, normalisation is 329x faster than CPU (Fig. 1), and distributing preprocessing across GPUs is precisely the direction we identify for future frameworks (see Discussion).",
  "In this hybrid pipeline, data loading, QC, normalisation, HVG selection and scaling executed on the host CPU; within the Dask-CUDA path, only PCA and neighbour graph construction had distributed GPU implementations usable for the pipeline as configured here.",
  "Argument moved to Limitations; procedure kept")
E("Methods, Concordance metrics", 2,
  "one for each major stage of the analysis pipeline, such that a divergence at any stage would be detected independently of the others (Table 2).",
  "one for each major stage of the analysis pipeline (Table 2).",
  "Redundant justification clause cut")
E("Methods, Stress test", 2, "(leveraging 2 TB system RAM)", "(using the 2 TB system RAM)",
  "Marker word replaced")
E("Methods, Stress test", 2,
  "This instrumentation yields a lower bound on the job's true memory use for two reasons: it cannot observe allocations that are made and released within a single step, and it excludes the resident memory of the eight Dask-CUDA worker processes, which the SLURM cgroup does account for.",
  "This instrumentation yields a lower bound on the job's true memory use (see the Limitations paragraph of the Discussion).",
  "Limitation reasoning moved to Limitations")
E("Methods, DE at scale", 2,
  "Differential expression testing at atlas scale is constrained by hardware, which shaped the factorial design of this benchmark. At 3.4 million cells and 41,000 genes the raw count matrix (`adata.raw.X`) occupies approximately 121 GB in sparse CSR format, exceeding the 80 GB VRAM of any single H100 device; running GPU DE naively is therefore impossible, and the tests we benchmark either scatter genes across multiple GPUs or stream gene chunks through a single GPU.",
  "At 3.4 million cells and 41,000 genes the raw count matrix (`adata.raw.X`) occupies approximately 121 GB in sparse CSR format, exceeding the 80 GB VRAM of any single H100 device; the GPU tests therefore either scattered genes across multiple GPUs or streamed gene chunks through a single GPU.",
  "Argumentative opener cut; procedure in past tense")
E("Methods, DE at scale", 2,
  "giving 500 x 3.4M x 4 bytes approximately 6.8 GB per chunk, well within the 80 GB per-device limit.",
  "giving approximately 6.8 GB per chunk (500 x 3.4M x 4 bytes), below the 80 GB per-device limit.",
  "Arithmetic punctuated; informal register removed")
E("Methods, Hardware", 2,
  "DGX-scale spatial benchmarks were not feasible within the study timeline: although the scRNA pipeline executed successfully on the DGX node via CUDA forward-compatibility, the GPU components of the spatial pipeline failed on the cluster's driver (535.183.01), which caps CUDA runtime at 12.2.",
  "Spatial benchmarks were not run on the DGX node: although the scRNA-seq pipeline executed there via CUDA forward compatibility, the GPU components of the spatial pipeline failed on the cluster's driver (535.183.01), which caps the CUDA runtime at 12.2.",
  "Justification trimmed; term unified (scRNA-seq)")
E("Methods, Hardware", 2,
  "could not be resolved against the older RAPIDS wheels.\nPorting the full spatial pipeline to a driver-compatible RAPIDS release therefore remains future work.\n",
  "could not be resolved against the older RAPIDS wheels.\n",
  "Future work moved to Limitations",
  anchor="Porting the full spatial pipeline")
E("Methods, Reproducibility", 2,
  "We note that GPU floating-point arithmetic is non-deterministic due to non-associative parallel reductions [@Shanmugavelu2024; @Collange2015], and quantify the resulting divergence through the concordance metrics above rather than expecting bit-identical outputs.",
  "GPU floating-point arithmetic is non-deterministic due to non-associative parallel reductions [@Shanmugavelu2024; @Collange2015]; the resulting divergence was quantified through the concordance metrics above.",
  "Reader address and argument removed")

# Results, scRNA-seq
E("Results, end-to-end", 2,
  "and 119.6x at 1.3M (8 GPU), reflecting the GPU's superior arithmetic throughput on larger matrices.",
  "and 119.6x at 1.3M (8 GPU).",
  "Interpretation moved to Discussion")
E("Results, per-step", 2,
  "The per-step speedup heatmap (Fig. 1) and the corresponding absolute wall-time breakdown (Fig. 2) reveal that GPU advantage varies dramatically by operation type, ranging across nearly two orders of magnitude depending on algorithmic structure and data size.",
  "The per-step speedups (Fig. 1) and the corresponding absolute wall times (Fig. 2) varied by operation type and data size, ranging across nearly two orders of magnitude.",
  "Hype and mechanism removed; Discussion covers")
E("Results, per-step", 2,
  "Trivially parallelisable operations achieve the highest speedups: normalisation, which involves only element-wise division and logarithm, reached 329x",
  "Normalisation, which involves only element-wise division and logarithm, showed the highest speedups: 329x",
  "Mechanism framing removed; Discussion covers")
E("Results, per-step", 2,
  "Similarly efficient GPU operations include HVG selection (24-94x speedup), neighbours graph construction (44-88x), UMAP (27-45x), and differential expression testing (16-88x), all reflecting the fine-grained parallelism available on modern GPUs.",
  "HVG selection (24-94x), neighbour graph construction (44-88x), UMAP (27-45x), and differential expression testing (16-88x) also showed large speedups.",
  "Interpretation cut; term unified")
E("Results, per-step", 2,
  "PCA showed a more moderate but still substantial speedup that increased with dataset size, from 4.8x at 10k cells to 36.5x at 100k cells, consistent with the increasing arithmetic intensity of singular value decomposition on larger matrices.",
  "The PCA speedup was smaller and increased with dataset size, from 4.8x at 10k cells to 36.5x at 100k cells.",
  "Interpretation moved to Discussion")
E("Results, per-step", 2,
  "Data loading from disk was actually faster on CPU across all scales (0.76-0.85x GPU/CPU), because the fixed overhead of CUDA context initialisation and RMM pool allocation dominated the short data transfer itself: PCIe Gen5 bandwidth (128 GB/s) is not saturated at these sub-gigabyte dataset sizes, and the transfer completes in milliseconds. We note that our pipeline relies on `h5py`-based readers that route data through CPU RAM, precluding GPU Direct Storage (GDS) optimisations that would bypass the CPU entirely; this remains an avenue for future improvement.",
  "Data loading from disk was faster on CPU across all scales (0.76-0.85x GPU/CPU).",
  "Mechanism, future work moved; Discussion repeats them")
E("Results, per-step", 2,
  "Similarly, Leiden clustering showed a clear dependence on problem size: at 10k cells, CPU was faster (0.36x) due to cuGraph's higher constant-time overhead for graph partitioning operations on small graphs, but GPU performance improved substantially as the graph size increased, with GPU overtaking CPU at 50k cells (1.80x speedup) and achieving 3.58x speedup at 100k cells.",
  "Leiden clustering depended on problem size: at 10k cells, CPU was faster (0.36x), whereas GPU overtook CPU at 50k cells (1.80x speedup) and reached a 3.58x speedup at 100k cells.",
  "Mechanism cut; Discussion already states it")
E("Results, multi-GPU", 2,
  "The timing breakdown (Fig. 4) reveals why: in a representative 8-GPU run at 1.3M cells (total 463.4 s),",
  "In the timing breakdown of a representative 8-GPU run at 1.3M cells (Fig. 4; total 463.4 s),",
  "Interpretive framing removed")
E("Results, multi-GPU", 2,
  "took 97.2 s (21%).\nSince CPU preprocessing is constant regardless of GPU count, and Leiden/UMAP/DE execute on a single GPU, only the PCA and neighbour steps benefit from additional GPUs, a classic instance of Amdahl's law [@Amdahl1967].\n",
  "took 97.2 s (21%).\n",
  "Interpretation cut; Discussion states it with [@Amdahl1967]",
  anchor="Since CPU preprocessing is constant")
E("Results, concordance", 2,
  "Concordance analysis on the 10,000-cell dataset (Fig. 5) demonstrated that the two pipelines yield near-identical biological conclusions, despite computing on different processors and hardware. Upstream analysis steps showed deterministic agreement: HVG selection was perfectly concordant with all 2,000 genes identical between CPU and GPU (Jaccard = 1.000), and PCA loadings were perfectly correlated with mean absolute Spearman rho = 1.000 across all 10 inspected principal components. Neighbourhood graph construction achieved high overlap with mean Jaccard = 0.930 (median = 0.938), though some variation in the k-nearest neighbours across the graph was expected due to floating-point precision differences.",
  "Concordance was assessed on the 10,000-cell dataset (Fig. 5). HVG selection was perfectly concordant, with all 2,000 genes identical between CPU and GPU (Jaccard = 1.000), and PCA loadings were perfectly correlated, with mean absolute Spearman rho = 1.000 across all 10 inspected principal components. Neighbour graph construction achieved a mean Jaccard overlap of 0.930 (median = 0.938).",
  "Interpretation moved to Discussion; term unified")
E("Results, concordance", 2,
  "Clustering concordance showed expected variations due to algorithm stochasticity. Leiden clustering",
  "Leiden clustering",
  "Interpretive opener cut; Discussion covers")
E("Results, concordance", 2,
  "The slightly lower concordance at resolution 1.0, where both pipelines identified 40 clusters, reflects the inherent stochasticity of the Leiden algorithm and minor differences in the underlying graph-partitioning implementations provided by cuGraph (GPU) versus igraph (CPU), rather than indicating any systematic bias. The downstream biological results also aligned well: differential expression log-fold-changes across 40 matched cluster pairs showed mean Spearman correlation of 0.946, with 30 of the 40 pairs exceeding the stringent threshold of rho > 0.97.",
  "At resolution 1.0, both pipelines identified 40 clusters. Differential expression log-fold-changes across 40 matched cluster pairs showed a mean Spearman correlation of 0.946, with 30 of the 40 pairs exceeding rho = 0.97.",
  "Interpretation moved to Discussion; evaluative words cut")
E("Results, concordance", 2,
  "\nThese concordance levels are consistent with the range of inter-method variation reported in mixture-control benchmarks of scRNA-seq analysis pipelines [@Tian2019] and systematic evaluations of clustering algorithm variability [@Duo2020], and support the conclusion that GPU and CPU pipelines are interchangeable for biological interpretation.\n",
  "",
  "Literature comparison moved to Discussion",
  anchor="These concordance levels are consistent")
E("Results, memory", 2, "well below 6% of the 2 TB system memory", "below 6% of the 2 TB system memory",
  "Informal register removed")
E("Results, memory", 2,
  "approximately constant at 40.7 GB across dataset sizes, dominated by the pre-allocated RMM pool.",
  "approximately constant at 40.7 GB across dataset sizes.",
  "Mechanism cut; kept in Fig. 6 caption")
E("Results, memory", 2,
  "(mean 16.8 GB per device, 21% of 80 GB capacity), well below the per-device limit. At these scales, therefore, end-to-end throughput is set by compute and I/O, not memory; CPU RAM becomes the binding constraint only in the extreme stress-test regime discussed in the next subsection.",
  "(mean 16.8 GB per device, 21% of 80 GB capacity).",
  "Redundant clause cut; interpretation moved to Discussion")
E("Results, memory", 2,
  "To verify that distributed computation was actually occurring across all workers (rather than silently collapsing onto a single GPU, as reported for some Dask-CUDA configurations), two independent pieces of evidence support the multi-GPU claim.",
  "To verify that distributed computation was occurring across all workers (rather than silently collapsing onto a single GPU, as reported for some Dask-CUDA configurations), we used two independent pieces of evidence.",
  "Dangling modifier fixed; 'actually' removed")
E("Results, stress test", 2, "To locate the true capacity limit", "To locate the capacity limit",
  "Intensifier removed")
E("Results, stress test", 2,
  "The failure point is counter-intuitive at first reading: the recorded peak RAM at 11.9M was 535 GB (26% of the 2 TB machine, 30% of the 1.8 TB SLURM job allocation), leaving apparent headroom, while recorded peak aggregate VRAM was only 49 GB out of 640 GB (7.6%). Neither figure explains why 12M cells fails, and our instrumentation cannot close the gap. As described in Methods, 535 GB is the largest between-step resident set size of the parent process alone. Two features of the 11.9M trace make the shortfall explicit. First, RAM rises from 124 GB at the end of data loading to 426 GB at the start of quality control, an increase of 302 GB that belongs to no timed step. Second, normalisation and HVG selection each register a between-step delta below 0.1 GB, which is possible only if their working memory is allocated and released inside the call. The step-level trace therefore records the pipeline's resting footprint between operations, not the peaks against which the SLURM cgroup enforces its limit. We report an indicative budget in Table 6 and treat the attribution of the 12M failure to a specific operation as unresolved. What the data do exclude is clustering as the CPU-side culprit: at 11.9M the three Leiden calls together added less than 1 GB of host RAM, because Leiden executes on GPU through cuGraph (aggregate VRAM rose from 28.8 GB to 48.8 GB across those calls).",
  "At 11.9M cells the recorded peak RAM was 535 GB (26% of the 2 TB machine, 30% of the 1.8 TB SLURM job allocation), the largest between-step resident set size of the parent process (Methods), and the recorded peak aggregate VRAM was 49 GB out of 640 GB (7.6%). In the 11.9M trace, RAM rose from 124 GB at the end of data loading to 426 GB at the start of quality control, an increase of 302 GB that belongs to no timed step, and normalisation and HVG selection each registered a between-step delta below 0.1 GB. The three Leiden calls together added less than 1 GB of host RAM, while aggregate VRAM rose from 28.8 GB to 48.8 GB across those calls. Table 6 reports an indicative memory budget.",
  "Inference, limitation, mechanism moved to Discussion")
E("Results, stress test", 2,
  "Similarly, a sparse-scatter optimisation that avoided the CPU-side dense matrix was tested at 14M cells but failed during Scanpy's HVG selection step, confirming that Scanpy's CPU-side preprocessing is the ultimate capacity bottleneck.",
  "A sparse-scatter optimisation that avoided the CPU-side dense matrix was also tested at 14M cells and failed during Scanpy's HVG selection step.",
  "Interpretation cut; Discussion states it")
E("Results, stress test", 2,
  "Scanpy's `highly_variable_genes` was observed to trigger an out-of-memory event from a 629 GB baseline in a variant pipeline at 14M cells, implying internal temporaries in excess of 1,100 GB; it is the largest single transient we have direct evidence for. The resident memory of the eight Dask-CUDA worker processes is charged to the SLURM cgroup but is invisible to parent-process sampling. Either could dominate the budget above.",
  "Scanpy's `highly_variable_genes` triggered an out-of-memory event from a 629 GB baseline in a variant pipeline at 14M cells. The resident memory of the eight Dask-CUDA worker processes is charged to the SLURM cgroup but is invisible to parent-process sampling.",
  "Inference moved to Discussion")
E("Results, DE", 2,
  "The factorial differential expression benchmark at 3.4 million cells across 41,000 genes and 81 Leiden clusters (Table 7) revealed important trade-offs between computational efficiency and statistical rigor. To keep the table tractable we reported all wall times against a single CPU denominator, the t-test (5,598 s): a CPU Wilcoxon baseline at this scale was infeasible to measure (extrapolation from smaller subsamples places it above four hours), and pseudo-bulk operates on a different sample unit (donor x cluster pseudo-samples rather than individual cells), so no strict within-method CPU-to-GPU ratio exists for it. Consequently, the speedup column should be read as \"which approach finishes fastest overall\", not as a within-method GPU acceleration factor; t-test and Wilcoxon are distinct statistical tests with different computational complexity, and any direct runtime comparison between them is descriptive, not inferential.",
  "Table 7 reports the factorial differential expression benchmark at 3.4 million cells across 41,000 genes and 81 Leiden clusters.",
  "Justification and reading guide moved to Discussion")
E("Results, DE", 2, "Pseudo-bulk aggregation emerged as the dominant strategy:",
  "Pseudo-bulk aggregation was the fastest strategy:", "Evaluative verb replaced by measured property")

# Results, spatial
E("Results, spatial heading", 2, "### GPU speedup scales dramatically with platform resolution",
  "### GPU speedup scales with platform resolution", "Hype adverb removed")
E("Results, spatial", 2,
  "to 51.6x on Visium HD 8 um (393,543 bins) (Fig. 7), demonstrating that GPU acceleration becomes increasingly valuable as spatial resolution increases.",
  "to 51.6x on Visium HD 8 um (393,543 bins) (Fig. 7).",
  "Interpretation moved to Discussion")
E("Results, spatial", 2,
  "\nThe CPU implementation computes pairwise cluster co-occurrence across distance intervals with O(n^2) complexity per interval, while the GPU implementation parallelises this computation across all bins and intervals simultaneously.\n",
  "\n",
  "Mechanism cut; Discussion states it",
  anchor="The CPU implementation computes pairwise")
E("Results, spatial", 2,
  "Visium HD 2 um showed a lower overall speedup (10.8x) despite a similar bin count (389,492) because co-occurrence analysis was skipped (>500 clusters exceeded the O(k^2) memory threshold).",
  "Visium HD 2 um showed a lower overall speedup (10.8x) at a similar bin count (389,492); on this platform, co-occurrence analysis was skipped (>500 clusters exceeded the O(k^2) memory threshold).",
  "Causal attribution moved to Discussion")
E("Results, spatial", 2,
  "On Visium v1, the modest 1.7x overall speedup reflects the small dataset size (2,695 spots): GPU kernel launch overhead is not amortised, and CPU-only steps (spatial neighbours, ligand-receptor) dominate.",
  "On Visium v1, CPU-only steps (spatial neighbours, ligand-receptor) dominated.",
  "Mechanism moved to Discussion")
E("Results, spatial concordance", 2,
  "across all three platforms, confirming that GPU-accelerated spatial autocorrelation produces scientifically equivalent results.",
  "across all three platforms.",
  "Interpretation cut; Discussion states it")
E("Results, spatial concordance", 2,
  "concordance was high, consistent with the scRNA-seq results.",
  "concordance was high.",
  "Comparison moved to Discussion")
E("Results, spatial concordance", 2,
  "the CPU pipeline identified 2,559 clusters while the GPU pipeline found 538.\nThis 4.75x difference in cluster granularity arises from algorithmic differences between the leidenalg (CPU) and cuGraph (GPU) Leiden implementations, which are amplified at high resolution where the graph has many near-degenerate partitions.\nSubsampling from 6.3 million to 389,492 bins also disrupts spatial contiguity, compounding the effect.\nThis is a known limitation of comparing stochastic graph-partitioning algorithms across implementations, not a deficiency of GPU computation per se.",
  "the CPU pipeline identified 2,559 clusters while the GPU pipeline found 538, a 4.75x difference in cluster granularity.",
  "Mechanism and caveat moved to Discussion",
  anchor="This 4.75x difference")
E("Results, spatial memory", 2,
  "CPU RAM ranged from 1.3 GB (Visium v1) to 10.8 GB (HD 2 um).\nThese modest requirements suggest that spatial benchmarks at full Visium HD resolution (6.3M bins at 2 um) would fit comfortably within DGX H100 memory.\n",
  "CPU RAM ranged from 1.3 GB (Visium v1) to 10.8 GB (HD 2 um).\n",
  "Extrapolation moved to Discussion",
  anchor="These modest requirements suggest")

# Discussion
E("Discussion, para 1", 2,
  "\nThese results reveal several important insights about GPU-accelerated single-cell analysis that merit detailed discussion.\n",
  "\n",
  "Scaffolding sentence addressing reader cut",
  anchor="These results reveal several important insights")
E("Discussion, operation-specific", 2,
  "The fundamental constraint underlying our results is that GPU speedup is inherently operation-specific and highly dependent on the computational structure of each step.",
  "GPU speedup is operation-specific and depends on the computational structure of each step.",
  "Intensifiers removed")
E("Discussion, operation-specific", 2,
  "are trivially parallelisable across many data elements. In contrast,",
  "are trivially parallelisable across many data elements. The growth of the end-to-end speedup with dataset size reflects the GPU's higher arithmetic throughput on larger matrices, and the growth of the PCA speedup is consistent with the increasing arithmetic intensity of singular value decomposition on larger matrices. In contrast,",
  "Relocated from Results (end-to-end, PCA)")
E("Discussion, operation-specific", 2,
  "rather than via GPU Direct Storage. Leiden",
  "rather than via GPU Direct Storage (GDS). GDS optimisations, which would bypass the CPU entirely, remain an avenue for future improvement. Leiden",
  "Relocated from Results (data loading)")
E("Discussion, operation-specific", 2,
  "This heterogeneous speedup landscape has important practical implications for practitioners: GPU acceleration is most valuable",
  "In practice, GPU acceleration is most valuable",
  "Marker word and filler removed")
E("Discussion, multi-GPU", 2,
  "This is a non-obvious but important takeaway for groups operating shared GPU infrastructure: the capital-intensive DGX platform delivers",
  "For groups operating shared GPU infrastructure, the capital-intensive DGX platform therefore delivers",
  "Self-evaluative framing removed")
E("Discussion, cloud", 2, "Related to this, most of the practical value", "Most of the practical value",
  "Scaffolding opener removed")
E("Discussion, concordance", 2,
  "despite computing on fundamentally different architectures and hardware.",
  "despite computing on different architectures and hardware.",
  "Intensifier removed")
E("Discussion, concordance", 2,
  "given identical numerical inputs. The adjusted Rand",
  "given identical numerical inputs. Some variation in the k-nearest neighbours (mean Jaccard = 0.930) is expected from floating-point precision differences. The adjusted Rand",
  "Relocated from Results (kNN)")
E("Discussion, concordance", 2,
  "in scRNA-seq workflows [@Duo2020]. Floating-point",
  "in scRNA-seq workflows [@Duo2020]. The lower concordance at resolution 1.0, where both pipelines identified 40 clusters, reflects the same stochasticity and implementation differences rather than any systematic bias. These concordance levels are also consistent with the range of inter-method variation reported in mixture-control benchmarks of scRNA-seq analysis pipelines [@Tian2019]. Floating-point",
  "Relocated from Results, with [@Tian2019]")
E("Discussion, concordance", 2,
  "This level of concordance is reassuring for practitioners: it indicates that",
  "This level of concordance indicates that",
  "Evaluative framing removed")
E("Discussion, capacity", 2,
  "Perhaps most importantly, our findings reveal that CPU-side memory pressure",
  "At the scales of the main benchmark (10k to 1.3M cells), end-to-end throughput is set by compute and I/O, not memory. Our findings reveal that CPU-side memory pressure",
  "Scaffold cut; relocated sentence from Results")
E("Discussion, capacity", 2,
  "while stable peak CPU RAM reached 535 GB. Critically, the 12M-cell failure",
  "while stable peak CPU RAM reached 535 GB. Neither figure explains why 12M cells fails. The 11.9M trace records the pipeline's resting footprint between operations, not the peaks against which the SLURM cgroup enforces its limit: the 302 GB rise between data loading and quality control belongs to no timed step, and between-step deltas below 0.1 GB for normalisation and HVG selection are possible only if their working memory is allocated and released inside the call. The attribution of the 12M failure to a specific operation therefore remains unresolved. The data do exclude clustering as the CPU-side culprit: the three Leiden calls added less than 1 GB of host RAM at 11.9M, because Leiden executes on GPU through cuGraph. Either of the two contributions that could not be quantified could dominate the budget in Table 6: the `highly_variable_genes` out-of-memory event at 14M cells implies internal temporaries in excess of 1,100 GB, the largest single transient for which there is direct evidence, and the resident memory of the eight Dask-CUDA workers is invisible to parent-process sampling. The 12M-cell failure",
  "Relocated from Results; 'Critically' cut")
E("Discussion, capacity", 1, "short-lived peaks that the scanpy preprocessing stack",
  "short-lived peaks that the Scanpy preprocessing stack", "Product name capitalisation")
E("Discussion, capacity", 2,
  "is structured to create. Substantial further gains",
  "is structured to create.\n\nSubstantial further gains",
  "Over-long paragraph split")
E("Discussion, capacity", 1, "Our ScaleSC-inspired chunked variant indeed reduced",
  "Our ScaleSC-inspired chunked variant reduced", "Empty filler word deleted")
E("Discussion, DE", 2,
  "reducing runtime by 44x relative to cell-level t-test. GPU acceleration",
  "reducing runtime by 44x relative to cell-level t-test. All DE speedups in Table 7 share a single CPU denominator, the t-test (5,598 s): a CPU Wilcoxon baseline at this scale was infeasible to measure (extrapolation from smaller subsamples places it above four hours), and pseudo-bulk operates on a different sample unit (donor x cluster pseudo-samples rather than individual cells), so no strict within-method CPU-to-GPU ratio exists for it. The speedup column therefore indicates which approach finishes fastest overall, not a within-method GPU acceleration factor; t-test and Wilcoxon are distinct statistical tests with different computational complexity, and any direct runtime comparison between them is descriptive, not inferential. GPU acceleration",
  "Relocated from Results (Table 7 reading)")
E("Discussion, DE", 1, "the Wilcoxon rank-sum test actually outperformed",
  "the Wilcoxon rank-sum test outperformed", "'actually' as emphasis removed", group="actually")
E("Discussion, spatial", 2,
  "GPU acceleration becomes increasingly impactful for computationally intensive spatial statistics.",
  "GPU acceleration becomes increasingly beneficial for computationally intensive spatial statistics. End-to-end, GPU acceleration becomes increasingly valuable as spatial resolution increases (Fig. 7). On Visium v1, the modest 1.7x speedup reflects the small dataset size: GPU kernel launch overhead is not amortised. On Visium HD 2 um, the overall speedup is lower (10.8x) because co-occurrence analysis was skipped.",
  "Buzzword replaced; relocated from Results (spatial)")
E("Discussion, spatial", 2, "achieved similarly impressive speedups of 162-170x",
  "achieved speedups of 162-170x", "Hype removed")
E("Discussion, spatial", 2,
  "likely harbour substantial additional speedup potential.",
  "likely harbour substantial additional speedup potential. The modest spatial memory requirements (Table 8) suggest that spatial benchmarks at full Visium HD resolution (6.3M bins at 2 um) would fit comfortably within DGX H100 memory.",
  "Relocated from Results (spatial memory)")
E("Discussion, spatial clustering", 2,
  "A notable finding from spatial analysis concerns clustering at extreme resolution. The dramatic divergence at Visium HD 2 um (ARI = 0.080) is not specific to GPU versus CPU comparison; rather, it reflects the fundamental sensitivity of stochastic graph-partitioning algorithms to implementation details when the solution landscape contains many near-degenerate partitions.",
  "Clustering concordance on Visium v1 and HD 8 um is consistent with the scRNA-seq results. The divergence at Visium HD 2 um (ARI = 0.080) is not specific to GPU versus CPU comparison; rather, it reflects the sensitivity of stochastic graph-partitioning algorithms to implementation details when the solution space contains many near-degenerate partitions.",
  "Scaffold, hype, marker word removed; relocated sentence")
E("Discussion, spatial clustering", 2,
  "implementations explore this landscape through different vertex orderings and local heuristics.",
  "implementations explore this space through different vertex orderings and local heuristics. Subsampling from 6.3 million to 389,492 bins also disrupts spatial contiguity, compounding the effect.",
  "Marker word replaced; relocated from Results")

# Limitations
E("Discussion, Limitations", 2,
  "Our study contains several limitations that should be considered when generalising these findings.",
  "This study has several limitations.",
  "Stock opener shortened")
E("Discussion, Limitations", 2,
  "A conservative driver policy on shared production hardware is reasonable, since driver upgrades routinely break unrelated Python environments for every other user of the node, but it is itself a practical constraint on deploying GPU spatial pipelines, and one that the current software stack makes harder to work around than it should be.",
  "A conservative driver policy on shared production hardware is itself a practical constraint on deploying GPU spatial pipelines, and porting the full spatial pipeline to a driver-compatible RAPIDS release remains future work.",
  "Editorial aside cut; future work from Methods")
E("Discussion, Limitations", 2,
  "interconnected by InfiniBand) because the near-flat wall time observed from 2 to 8 GPUs already indicates",
  "interconnected by InfiniBand). The near-flat wall time observed from 2 to 8 GPUs already indicates",
  "Over-long sentence split")
E("Discussion, Limitations", 2,
  "would be further penalised by inter-node communication latency. A further limitation",
  "would be further penalised by inter-node communication latency.\n\nA further limitation",
  "Over-long paragraph split")
E("Discussion, Limitations", 2,
  "Because the standard single-GPU pipeline exceeded 80 GB VRAM at 500k and 1.3M cells, those dataset sizes",
  "Because the standard single-GPU pipeline exceeded 80 GB VRAM at 500k and 1.3M cells (Table 4), those dataset sizes",
  "Table reference moved from Methods")
E("Discussion, Limitations", 2,
  "rather than an intrinsic limit of GPU acceleration, and it should be expected",
  "rather than an intrinsic limit of GPU acceleration (on a single GPU, normalisation is 329x faster than on CPU; Fig. 1), and it should be expected",
  "Evidence relocated from Methods")
E("Discussion, Limitations", 2,
  "A second limitation concerns the memory instrumentation of the stress test itself: CPU memory was sampled between pipeline steps and for the parent process only, so the reported peaks are lower bounds and the attribution in Table 6 is indicative rather than measured.",
  "Another limitation concerns the memory instrumentation of the stress test itself: CPU memory was sampled between pipeline steps and for the parent process only, so the reported peaks are lower bounds. The sampling cannot observe allocations that are made and released within a single step, and it excludes the resident memory of the eight Dask-CUDA worker processes, which the SLURM cgroup does account for; the attribution in Table 6 is therefore indicative rather than measured.",
  "Numbering fixed; reasons relocated from Methods")

open(OUT, "w", encoding="utf-8").write(text)
json.dump(log, open(LOG, "w"), indent=1, ensure_ascii=False)
print("edits applied:", len(log))
from collections import Counter
print(Counter(e["tier"] for e in log))
