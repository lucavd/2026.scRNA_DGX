import sys, json, re
sys.path.insert(0, '.')
from kload import K
t=open(sys.argv[1]).read()
L=t.split('\n')
def sec(a,b): return '\n'.join(L[a-1:b])
meth=sec(47,174); res=sec(176,408)
for name,txt,off in [('METHODS',meth,47),('RESULTS',res,176)]:
    r=K.results_scan(txt)
    for k,v in r.items():
        for h in v:
            ln=txt.count('\n',0,h['start'])+off
            print(name,k,ln,repr(h['match']),'|',h['context'][:100])
print(json.dumps(K.sentence_stats(t),indent=0))
for name,(a,b) in {'abstract':(14,14),'intro':(20,45),'methods':(47,174),'results':(176,408),'discussion':(410,433),'concl':(434,442)}.items():
    s=K.sentence_stats(sec(a,b)); print(name, s['n_sentences'], s['median_words'], s['p90_words'], s['max_words'], 'we=',s['first_person_plural'])
