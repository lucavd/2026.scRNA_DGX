import re, sys, json
from collections import Counter
sys.path.insert(0,'.')
from kload import K
o=open('../../full_paper_LNBI.md').read(); c=open('full_paper_LNBI_style.md').read()
num=lambda t: Counter(re.findall(r'\d[\d,]*(?:\.\d+)?', t))
no,nc=num(o),num(c)
print("numbers new in copy (not in original):", {k:v for k,v in (nc-no).items()})
print("numbers with fewer occurrences in copy:", dict(no-nc))
cit=lambda t: Counter(re.findall(r'@[A-Za-z0-9_]+', t))
co,cc=cit(o),cit(c)
print("citation keys lost:", dict(co-cc), " gained:", dict(cc-co))
print("keys absent from copy:", [k for k in co if k not in cc])
lab=lambda t: sorted(re.findall(r'\{#tbl:[^}]+\}', t)); print("labels equal:", lab(o)==lab(c), len(lab(c)))
fig=lambda t: sorted(re.findall(r'\]\(([^)]+\.png)\)', t)); print("figure paths equal:", fig(o)==fig(c), len(fig(c)))
def tables(t):
    rows=[l for l in t.split('\n') if l.startswith('|')]
    return [(l.count('|')-l.count('\\|')) for l in rows]
print("table rows:", len(tables(o)), len(tables(c)), "pipe-count profile equal (escapes aside):", tables(o)==tables(c))
heads=lambda t: re.findall(r'(?m)^#+ .*', t)
ho,hc=heads(o),heads(c); print("headings changed:", [(a,b) for a,b in zip(ho,hc) if a!=b], len(ho)==len(hc))
print("ORPHAN (kernel):", K.orphan_citations(o,c))
