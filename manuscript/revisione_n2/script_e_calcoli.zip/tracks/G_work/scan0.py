import sys, json
sys.path.insert(0, '.')
from kload import K
t=open(sys.argv[1]).read()
lines=t.split('\n')
def lineno(off): return t.count('\n',0,off)+1
r=K.style_scan(t)
print("COUNTS", r['counts']); print("SPELL", r['spelling_variants'])
for k in ['em_dash','en_dash','marker_words','scaffold_openers','stock_phrases','reader_address','informal','bold_miniheading','numerals','interference']:
    for h in r[k]:
        print(k, lineno(h['start']), repr(h['match']), '|', h['context'][:110], h.get('suggest',''))
