: **Table 2.** Concordance metrics used to compare CPU and GPU pipeline outputs. {#tbl:concordance}

| Metric | Definition | Scope |
|:-------|:-----------|:------|
| HVG Jaccard | size of intersection divided by size of union of the CPU and GPU gene sets for 2,000 HVGs | Feature selection |
| PCA loading |rho| | Mean absolute Spearman rho across first 10 PC loadings, accounting for sign flips | Dimensionality reduction |
| kNN Jaccard | Mean per-cell Jaccard overlap of k-nearest-neighbour sets (k = 15) [@Luecken2022] | Graph structure |
| ARI | Adjusted Rand Index of Leiden cluster assignments, adjusted for chance [@Hubert1985] | Clustering |
| NMI | Normalised Mutual Information of cluster assignments [@Vinh2010] | Clustering |
| DE logFC rho | Spearman rho of log-fold-changes for top 100 DE genes per cluster, after Hungarian matching [@Soneson2018] | Differential expression |
| Pipeline | Cells | GPUs | Total time (s) | SD (s) | Peak RAM (GB) | Peak VRAM (GB) |
|:---------|------:|-----:|---------------:|-------:|---------------:|---------------:|
| CPU (Scanpy) | 10k | 0 | 39.5 | 10.2 | 1.2 | --- |
| GPU (rapids) | 10k | 1 | 3.3 | 1.7 | 2.4 | 40.7 |
