"""Build change_table.md, flagged.md and ../G_findings.json for track G."""
import json, re

BASE = "/tmp/claude-0/-home-claude/e2229d1f-65c5-5244-af74-f9741477965d/scratchpad/review"
ORIG = f"{BASE}/full_paper_LNBI.md"
W = f"{BASE}/tracks/G_work"
orig = open(ORIG, encoding="utf-8").read()
log = json.load(open(f"{W}/edit_log.json"))

# ------------------------------------------------------------------ change table
def esc(s):
    s = s.replace("\n", " / ").replace("|", "\\|")
    return s

def abbrev(s, n=260):
    s = s.strip("\n")
    if len(s) <= n:
        return s
    return s[:150].rstrip() + " [...] " + s[-90:].lstrip()

rows, groups = [], {}
for e in log:
    if e["group"] in ("emdash", "min"):
        groups.setdefault(e["group"], []).append(e)
        continue
    was = abbrev(e["was"]) if e["was"].strip() else "(nothing)"
    now = abbrev(e["now"]) if e["now"].strip() else "(deleted)"
    if e["reason"].startswith("Blank line"):
        was, now = "Fig. 9 image line followed directly by 'Moran's I ...'", "Blank line inserted after the image line"
    rows.append((f"{e['loc']}, l. {e['line']}", e["tier"], was, now, e["reason"]))

g = groups["emdash"]
rows.insert(0, ("Tables 1, 4, 5, ll. 71, 191-210, 278-279", 1,
                "`---` (12 cells)", "`none` (Table 1, 1 cell); `n.a.` (Tables 4-5, 11 cells)",
                "Cells rendered as em dashes (12 cells)"))
g = groups["min"]
rows.insert(1, ("Abstract l. 14; Results l. 321; Discussion l. 420; Conclusions l. 436", 1,
                "7.3 minutes (x3); 128 seconds; 2.1 minutes; 93 minutes",
                "7.3 min (x3); 128 s; 2.1 min; 93 min",
                "Units after numerals unified (6 instances)"))

n1 = sum(1 for e in log if e["tier"] == 1)
n2 = sum(1 for e in log if e["tier"] == 2)
ins = [e for e in log if e["tier"] == 2 and e["loc"].startswith("Discussion")
       and ("elocated" in e["reason"] or "from Methods" in e["reason"] or "from Results" in e["reason"])]
with open(f"{W}/change_table.md", "w", encoding="utf-8") as f:
    f.write("# Track G: change table (tier 1 and tier 2)\n\n")
    f.write(f"Source: `full_paper_LNBI.md` (md5 4587032be8d2905007687e0bb50d848e). Edited copy: "
            f"`tracks/G_work/full_paper_LNBI_style.md`. Line numbers refer to the original.\n\n")
    f.write(f"Edit operations: tier 1 = {n1}, tier 2 = {n2} (of which {len(ins)} are insertions in the "
            f"Discussion that receive text relocated out of Methods or Results). Grouped mechanical fixes "
            f"appear as one row with a count. Word count 9715 -> "
            f"{len(open(W + '/full_paper_LNBI_style.md').read().split())}.\n\n")
    f.write("| Location | Tier | Was | Now | Reason |\n|:--|:--:|:--|:--|:--|\n")
    for r in rows:
        f.write(f"| {esc(r[0])} | {r[1]} | {esc(r[2])} | {esc(r[3])} | {esc(r[4])} |\n")
print("change rows", len(rows), "tier1 ops", n1, "tier2 ops", n2, "discussion insertions", len(ins))

# ------------------------------------------------------------------ tier 3 flags
def L(loc):
    assert loc in orig, f"locator not found: {loc[:70]}"
    assert len(loc) <= 200, f"locator too long ({len(loc)}): {loc[:60]}"
    return orig.count("\n", 0, orig.find(loc)) + 1

F = []
def flag(fid, section, locator, claimed, recomputed, status, severity, source, note, para):
    F.append(dict(fid=fid, section=section, locator=locator, line=L(locator), claimed=claimed,
                  recomputed=recomputed, status=status, severity=severity, source=source,
                  note=note, para=para))

MS = "full_paper_LNBI.md"

# ---- A. contradictions and numbers
flag("G01", "Results, Stress test / Table 5 / Table 6 / Discussion / Abstract",
     "What the data do exclude is clustering as the CPU-side culprit",
     "Table 5 e l. 260: fallimento a 12.0M = 'Leiden OOM'; l. 262: i dati escludono il clustering; l. 424: il fallimento e' avvenuto per picchi transitori del preprocessing; abstract: 'CPU RAM as the binding constraint'",
     "Quattro attribuzioni non compatibili: il kill avviene durante lo step Leiden (dopo il preprocessing), la Table 6 stima ~50 GB per strutture Leiden mentre la riga stessa riporta delta host < 1 GB, la Discussione afferma la causa come fatto ('it occurred because transient memory spikes during individual preprocessing operations') pur dichiarandola non stabilita. Il commento in scripts/benchmark_maxpower.py (riga 714) attribuisce l'OOM a Leiden ('OOMs above ~12M cells').",
     "MISMATCH", "major",
     f"{MS} ll. 14, 260, 262, 278, 300, 424; /tmp/repo/scripts/benchmark_maxpower.py:714",
     "Tocca la tesi centrale (abstract, conclusioni). Va resa una sola attribuzione, coerente fra Table 5, Table 6, Risultati e Discussione.",
     "Stress-test failure at 12M: four incompatible attributions. Table 5 and the Results label the 12.0M failure 'Leiden OOM' ('failed at 12.0 million cells (Leiden out-of-memory, SLURM signal 9)'); the Results then state 'What the data do exclude is clustering as the CPU-side culprit'; Table 6 assigns '~50' GB to 'Leiden internal structures (executes on GPU; host delta at 11.9M < 1 GB)', contradicting its own row label; the Discussion states the cause as fact ('it occurred because transient memory spikes during individual preprocessing operations briefly multiplied the working set') although the kill happened during the Leiden step, after preprocessing had completed, and although the Results call the attribution unresolved. The abstract ('with CPU RAM as the binding constraint') and the Conclusions ('The principal scalability bottleneck is CPU-side preprocessing') rest on this attribution. The project script `scripts/benchmark_maxpower.py` (line 714) comments 'Leiden via cugraph (GPU), OOMs above ~12M cells'.")
flag("G02", "Results, Spatial",
     "Without this step, UMAP dominated the GPU pipeline time (92x speedup, but consuming 92% of the 97 s total GPU time).",
     "UMAP = 92% dei 97 s GPU (HD 2 um); spatial neighbours = 57-73% del tempo GPU sulle piattaforme HD; ~55 s su tutte le HD",
     "0.92 x 97 = 89.2 s di UMAP + ~55 s di spatial neighbours = 144 s > 97 s; spatial neighbours su HD 2 um = 55/97 = 56.7% (57.4/97 = 59.2%). Con speedup 92x, UMAP CPU sarebbe 89.2 x 92 = 8210 s, oltre il totale CPU di 1042 s (Table 8).",
     "MISMATCH", "major", f"{MS} ll. 336, 368, 372-373; calcolo sulle cifre del testo",
     "Aritmetica impossibile: almeno una delle due percentuali e' sbagliata (forse 92% del tempo CPU o altro denominatore).",
     "Spatial time shares that cannot both hold. 'UMAP dominated the GPU pipeline time (92x speedup, but consuming 92% of the 97 s total GPU time)' and 'Spatial neighbours alone represented 57-73% of total GPU pipeline time on HD platforms' (with '~55 s on all HD platforms'). On HD 2 um, 0.92 x 97 = 89.2 s plus about 55 s exceeds the 97 s total; a 92x speedup on 89.2 s of GPU time implies about 8210 s of CPU UMAP, more than the 1042 s CPU total in Table 8.")
flag("G03", "Methods, Multi-GPU pipeline / Results, Multi-GPU",
     "Scaling, Leiden clustering, UMAP, and DE testing executed on a single GPU (device 0), as they operate on the reduced PCA embedding or require global graph access.",
     "l. 88: scaling eseguito su CPU host; l. 90: scaling su GPU singola (device 0); l. 231: 'single-GPU operations (transfer + scale + Leiden + UMAP + DE)'",
     "Due collocazioni opposte per lo stesso step nella stessa sottosezione; inoltre lo scaling (step 5) precede la PCA (step 6, Table 1) e non puo' 'operate on the reduced PCA embedding'.",
     "MISMATCH", "major", f"{MS} ll. 88, 90, 231; Table 1 l. 75-76",
     "Frase lasciata invariata nella copia (tier 3). La modifica del 2 settembre ha introdotto l. 88 in conflitto con l. 90.",
     "Where scaling ran in the multi-GPU pipeline. Line 88 lists scaling among the host-CPU steps ('data loading, QC, normalisation, HVG selection and scaling executed on the host CPU'); line 90 states 'Scaling, Leiden clustering, UMAP, and DE testing executed on a single GPU (device 0), as they operate on the reduced PCA embedding', and the Results breakdown lists 'transfer + scale + Leiden + UMAP + DE' as single-GPU operations. Scaling (step 5) precedes PCA (step 6), so it cannot operate on the PCA embedding.")
flag("G04", "Methods, Analysis pipeline / Results, Per-step / Discussion",
     "a GPU warmup step was then executed to absorb CUDA context initialisation overhead before timing.",
     "Methods: warmup assorbe l'inizializzazione del contesto CUDA prima del timing (e il pool RMM e' pre-allocato); Results l. 223 e Discussion l. 416: data loading piu' lento su GPU per 'the fixed overhead of CUDA context initialisation and RMM pool allocation'",
     "Se contesto CUDA e pool RMM sono inizializzati prima del timing, non possono dominare lo step di data loading cronometrato.",
     "MISMATCH", "major", f"{MS} ll. 83, 223, 416",
     "Spiegazione meccanicistica in contraddizione con la procedura dichiarata.",
     "Data-loading mechanism contradicts the stated procedure. Methods: 'the RMM pool allocator was initialised to pre-reserve GPU VRAM ... a GPU warmup step was then executed to absorb CUDA context initialisation overhead before timing.' Results (line 223) and Discussion (line 416) attribute the slower GPU data loading to 'the fixed overhead of CUDA context initialisation and RMM pool allocation'.")
flag("G05", "Results, End-to-end speedup",
     "The speedup increased monotonically with dataset size: 33.6x at 50k, 43.7x at 100k, 34.9x at 500k (2 GPU), and 119.6x at 1.3M (8 GPU)",
     "speedup monotono crescente con la dimensione",
     "Sequenza riportata: 11.97 (10k), 33.6, 43.7, 34.9, 119.6: cala da 100k a 500k. Inoltre confronta configurazioni diverse (1, 1, 1, 2, 8 GPU).",
     "MISMATCH", "major", f"{MS} l. 185; Table 4: 282.5/8.4 = 33.6, 646.7/14.8 = 43.7, 4346.7/124.5 = 34.9, 52056.2/435.2 = 119.6",
     "Affermazione smentita dai numeri nella stessa frase.",
     "Non-monotonic sequence described as monotonic: 'The speedup increased monotonically with dataset size: 33.6x at 50k, 43.7x at 100k, 34.9x at 500k (2 GPU), and 119.6x at 1.3M (8 GPU)'. The value falls from 100k to 500k, and the sequence mixes 1-, 2- and 8-GPU configurations.")
flag("G06", "Discussion, operation-specific speedup",
     "Normalisation and neighbour graph construction represent ideal GPU workloads, achieving speedups of 88-329x and 44-88x respectively, because they involve high arithmetic intensity",
     "Normalisation 88-329x; motivo: alta intensita' aritmetica",
     "Results l. 217 e Fig. 1: normalisation 173-329x (10k-100k). I Risultati descrivono la normalisation come 'only element-wise division and logarithm' (bassa intensita' aritmetica, memory-bound), e la stessa Discussione usa la bassa intensita' aritmetica (roofline) per spiegare lo scarso speedup di Leiden.",
     "MISMATCH", "major", f"{MS} ll. 217, 219, 416",
     "Numero e meccanismo non coerenti con i Risultati.",
     "Normalisation range and mechanism. Discussion: 'achieving speedups of 88-329x and 44-88x respectively, because they involve high arithmetic intensity'. Results report normalisation at 329x, 206x and 173x (10k-100k), and describe it as 'only element-wise division and logarithm', an operation of low arithmetic intensity; the same paragraph then explains the Leiden result through low arithmetic intensity and the roofline model.")
flag("G07", "Results, Memory / Fig. 6",
     "CPU RAM usage scaled approximately linearly with cell count, from 1.2 GB at 10k to 107.4 GB at 1.3M cells",
     "testo: crescita 'approximately linearly'; didascalia Fig. 6: 'CPU RAM grows super-linearly'",
     "Da Table 4: 10k->1.3M celle x130, RAM x89.5 (sublineare); 500k->1.3M celle x2.6, RAM x3.6 (superlineare). Testo e didascalia si contraddicono.",
     "MISMATCH", "major", f"{MS} ll. 250, 254; Table 4 righe CPU",
     "Una delle due descrizioni va corretta.",
     "Text and caption disagree on CPU RAM growth: 'CPU RAM usage scaled approximately linearly with cell count' against the Fig. 6 caption 'CPU RAM grows super-linearly'. Table 4 gives a 89.5-fold RAM increase for a 130-fold cell increase overall, and a 3.6-fold increase for 2.6-fold more cells between 500k and 1.3M.")
flag("G08", "Results, Memory (multi-GPU evidence)",
     "the aggregate peak VRAM at 1.3M cells with 8 GPUs (134.2 GB) exceeds the 80 GB capacity of any single H100 device; this working set could not have fit on one GPU alone",
     "VRAM aggregata > 80 GB prova che i dati erano distribuiti",
     "Table 4: a 10k celle con 8 GPU la VRAM aggregata e' gia' 106.5 GB (con 2 GPU 52.4 GB), con dati trascurabili: l'aggregato riflette i pool RMM pre-allocati (10 GB iniziali per worker, Methods l. 89), non il working set. 'as reported for some Dask-CUDA configurations' senza citazione; UMAP e' in cuML, non in cuGraph.",
     "UNSUPPORTED", "major", f"{MS} ll. 89, 193-195, 252",
     "Inferenza non valida; il paragrafo e' anche procedura (verifica, bug fix) collocata nei Risultati. Non riscritto.",
     "Evidence for distributed execution. 'the aggregate peak VRAM at 1.3M cells with 8 GPUs (134.2 GB) exceeds the 80 GB capacity of any single H100 device; this working set could not have fit on one GPU alone'. Table 4 shows 106.5 GB aggregate at 10k cells with 8 GPUs, where the data are a few GB, so the aggregate tracks per-worker RMM pool reservation (Methods: 10 GB initial per worker) rather than the working set. 'as reported for some Dask-CUDA configurations' carries no citation. UMAP is described as 'implemented as single-GPU operations in cuGraph 26.2'. The paragraph also reports procedure (scheduler queries, a bug fix) inside Results.")
flag("G09", "Results, Stress test (KMeans rows)",
     "the failure point at scale is identical (13.7M, CPU-side scale step), so the KMeans rows are included here as valid ascending points on the runtime/memory curves",
     "punto di fallimento identico (13.7M) per KMeans e Leiden; footprint identico 'see Section Stress test: maximum capacity'",
     "Per Leiden il fallimento e' a 12.0M (Table 5); se KMeans fallisce a 13.7M, i due non hanno lo stesso punto di fallimento. La sezione Methods citata non menziona KMeans ne' il footprint. Runtime KMeans vs Leiden non confrontati.",
     "MISMATCH", "major", f"{MS} ll. 109-111, 264, 277-279, 281",
     "Giustificazione metodologica dentro i Risultati, non spostata perche' contiene queste affermazioni da verificare.",
     "Two 'failure points' and a broken cross-reference. 'the failure point was identical (13.7M)' (line 264) and 'the failure point at scale is identical (13.7M, CPU-side scale step), so the KMeans rows are included here as valid ascending points on the runtime/memory curves' (line 281), while Table 5 places the Leiden failure at 12.0M. The cited Methods section ('see Section \"Stress test: maximum capacity\"') does not mention KMeans or its footprint. This justification paragraph sits in Results; it was left in place because of these issues.")
flag("G10", "Discussion, capacity",
     "Our ScaleSC-inspired chunked variant indeed reduced aggregate VRAM by a factor of five (49 GB to 10 GB) without improving the cell limit",
     "la variante chunked non migliora il limite di celle",
     "Results l. 267: la variante chunked 'succeeded at 12.0 million cells', dove la pipeline memory-optimised falliva (Table 5). Il limite superiore e' quindi almeno 12.0M (fallimento a 15.0M; intervallo 12.0-15.0M non testato). Abstract, Table 5 e Conclusioni indicano 11.9M come massimo.",
     "MISMATCH", "major", f"{MS} ll. 267, 277-278, 424, 437",
     "Contraddizione fra Risultati e Discussione; il massimo dichiarato va qualificato per pipeline.",
     "Chunked variant and the cell limit. Discussion: 'Our ScaleSC-inspired chunked variant ... reduced aggregate VRAM by a factor of five (49 GB to 10 GB) without improving the cell limit'. Results: 'This variant succeeded at 12.0 million cells (862 GB peak RAM, 10 GB aggregate VRAM, 156 min)', a size at which the memory-optimised pipeline failed. Abstract, Table 5 and Conclusions give 11.9M as the maximum.")
flag("G11", "Discussion, capacity (HVG extrapolation)",
     "with 2,000 HVGs this suggests 20M cells at 1,000 HVGs and 4M cells at 5,000 HVGs as linear-extrapolation operating points",
     "20M celle a 1000 HVG e 4M a 5000 HVG per estrapolazione lineare",
     "Da 11.9M a 2000 HVG: 11.9 x 2000/1000 = 23.8M e 11.9 x 2000/5000 = 4.76M; i valori del testo implicano una base di 10M. Inoltre Table 6 attribuisce alla matrice densa 96 GB su 535 GB, quindi il limite non scala in proporzione inversa agli HVG.",
     "MISMATCH", "major", f"{MS} ll. 290-292, 424; calcolo lineare",
     "Aritmetica e premessa non coerenti con Table 6.",
     "HVG extrapolation. 'with 2,000 HVGs this suggests 20M cells at 1,000 HVGs and 4M cells at 5,000 HVGs as linear-extrapolation operating points'. Linear scaling from 11.9M cells at 2,000 HVGs gives 23.8M and 4.76M; 20M and 4M correspond to a 10M baseline. Table 6 puts the dense scaled matrix at 96 GB of a 535 GB baseline, so the premise that the limit scales with cells x HVGs is not what the budget shows.")
flag("G12", "Methods, DE at scale / Table 7",
     "We evaluated seven DE strategies in a factorial design crossing test type (Wilcoxon, t-test, pseudo-bulk) with GPU strategy (none, scatter-by-genes across 8 GPUs, chunk-and-stream on 1 GPU).",
     "sette strategie in un disegno fattoriale 3 x 3",
     "factorial_check(7, test_type=3, gpu_strategy=3): prodotto 9, non 7; Table 7 riporta 6 righe (manca Wilcoxon CPU, pseudo-bulk GPU assenti). Nessuna combinazione di livelli dichiarati da' 7.",
     "MISMATCH", "major", f"{MS} ll. 115, 312-319; kernel factorial_check",
     "Il disegno va descritto con le celle effettivamente eseguite.",
     "DE design total does not close. 'We evaluated seven DE strategies in a factorial design crossing test type (Wilcoxon, t-test, pseudo-bulk) with GPU strategy (none, scatter-by-genes across 8 GPUs, chunk-and-stream on 1 GPU).' Three by three levels give 9 cells; Table 7 has 6 rows.")
flag("G13", "Results, DE (moved to Discussion in the copy)",
     "a CPU Wilcoxon baseline at this scale was infeasible to measure (extrapolation from smaller subsamples places it above four hours)",
     "baseline Wilcoxon CPU 'infeasible' (> 4 h)",
     "La pipeline CPU a 1.3M e' stata eseguita 5 volte da 14.5 h ciascuna (52056 s); 4 h = 14400 s non e' un vincolo di fattibilita' dimostrato. Metodo di estrapolazione non descritto.",
     "UNSUPPORTED", "major", f"{MS} ll. 183, 308",
     "Giustificazione spostata in Discussione nella copia senza alterarne il contenuto.",
     "Infeasibility of the CPU Wilcoxon baseline. 'a CPU Wilcoxon baseline at this scale was infeasible to measure (extrapolation from smaller subsamples places it above four hours)'. The same study ran the 1.3M CPU pipeline five times at about 14.5 h each; the extrapolation method is not described.")
flag("G14", "Methods / Results, DE and Stress test (data provenance)",
     "Pseudo-bulk aggregation summed raw counts by donor x cluster, normalised to counts per million, log-transformed, and applied the Wilcoxon test on the aggregated matrix [@Squair2021].",
     "pseudo-bulk per 'donor x cluster'; 'a few hundred pseudo-samples per cluster'; dataset da 3.4M a 15M celle",
     "Methods descrivono solo il dataset da 1.3M (E18) e i suoi sottocampioni: non e' detto come sono costruiti i dataset da 3.4M-15M, ne' cosa sia un 'donor'. Numero di geni 39,182 a 1.3M (l. 250) contro 41,000 a 3.4M (ll. 115, 308, Table 7). 'a few hundred pseudo-samples per cluster' implica centinaia di donatori.",
     "UNSUPPORTED", "major", f"{MS} ll. 53-57, 115, 250, 308, 321",
     "Provenienza dei dati oltre 1.3M e unita' 'donor' da definire nei Metodi.",
     "Data provenance above 1.3M cells and the 'donor' unit. Methods describe only the 1.3M E18 dataset and its subsamples; the construction of the 3.4M-15M datasets is not stated, nor what a 'donor' is in 'summed raw counts by donor x cluster'. Gene counts differ ('1.3M x 39,182 genes' against '3.4 million cells and 41,000 genes'). Results state that aggregation 'reduced the analysis from 3.4 million individual cells to a few hundred pseudo-samples per cluster'.")
flag("G15", "Results heading / Discussion / Conclusions, DE",
     "### Differential expression: pseudo-bulk is fastest and most correct",
     "pseudo-bulk 'most correct', 'optimal balance', 'most statistically rigorous'",
     "Il benchmark misura solo tempi; nessuna valutazione di correttezza (FDR, potenza, ground truth). Il pseudo-bulk eseguito e' Wilcoxon su CPM log-trasformati, non i modelli di conteggio (DESeq2, edgeR) che la Discussione indica come gold standard.",
     "UNSUPPORTED", "major", f"{MS} ll. 115, 306, 426, 439",
     "Affermazione piu' forte del disegno.",
     "Correctness claims without a correctness measurement. Heading 'pseudo-bulk is fastest and most correct'; Discussion 'represents the optimal balance between computational efficiency and statistical rigour'; Conclusions 'simultaneously the fastest (44x vs t-test) and most statistically rigorous approach'. Only run time was measured, and the benchmarked pseudo-bulk applies a Wilcoxon test to log-CPM (Methods), whereas the Discussion names count-based models (DESeq2, edgeR) as the 'gold standard'.")
flag("G16", "Results, Spatial heading / Discussion",
     "### GPU speedup scales dramatically with platform resolution",
     "lo speedup cresce con la risoluzione della piattaforma",
     "Table 8: HD 2 um (risoluzione piu' alta) 10.8x < HD 8 um 51.6x. La crescita vale tra v1 e HD 8 um, non con la risoluzione.",
     "MISMATCH", "major", f"{MS} ll. 326, 334-338",
     "Nella copia tolto solo 'dramatically'; la frase interpretativa e' stata spostata in Discussione senza alterarla.",
     "Speedup and resolution. Heading 'GPU speedup scales dramatically with platform resolution' and 'demonstrating that GPU acceleration becomes increasingly valuable as spatial resolution increases'. Table 8: HD 2 um, the highest resolution, has 10.8x against 51.6x at HD 8 um.")
flag("G17", "Results, Spatial memory / Methods, Datasets",
     "Peak GPU VRAM was 12.9 GB on Visium v1 and plateaued at 22.6 GB for both HD platforms (Table 8), well within the RTX 4090's 24 GB capacity.",
     "VRAM 'well within' 24 GB; requisiti 'modest'; a 6.3M bin 'would fit comfortably within DGX H100 memory'",
     "22.6/24 = 94.2% della capacita'. Methods l. 122 e Fig. 7: HD 2 um sottocampionato proprio per stare nei 24 GB. Estrapolazione a 6.3M bin (16x) non testata; Methods l. 122 afferma invece che serve 'DGX-class resources'.",
     "UNSUPPORTED", "major", f"{MS} ll. 122, 340, 403-407",
     "Titolo e frase in contrasto con la necessita' di sottocampionare.",
     "Spatial memory described as modest. 'plateaued at 22.6 GB for both HD platforms (Table 8), well within the RTX 4090's 24 GB capacity' (94% of capacity) under the heading 'Memory usage is modest across spatial platforms', while Methods and the Fig. 7 caption state that HD 2 um was subsampled 'so that the benchmark would fit within the RTX 4090's 24 GB VRAM'. The extrapolation 'would fit comfortably within DGX H100 memory' at 6.3M bins and the Methods statement 'requires DGX-class resources' were not tested.")
flag("G18", "Discussion, cloud cost",
     "the memory-optimised variant described here extends single-GPU feasibility to 1.3M cells and beyond",
     "fattibilita' su singola GPU fino a 1.3M+; analisi atlas-scale 'well under one dollar' a USD 2-4/h",
     "La variante memory-optimised usa 8 GPU (Methods l. 110); Table 4: 500k e 1.3M non girano su una GPU. I 7.3 min sono su 8 H100: 8 x 435.2 s = 0.97 GPU-h = USD 1.93-3.87 alle tariffe dichiarate; su 1 GPU il tempo non e' misurato. Tariffa senza fonte.",
     "UNSUPPORTED", "major", f"{MS} ll. 110, 187, 420; calcolo 8*435.2/3600*{{2,4}}",
     "Affermazione non supportata e numericamente in contrasto con i dati del lavoro.",
     "Single-GPU and cost claims. 'the memory-optimised variant described here extends single-GPU feasibility to 1.3M cells and beyond' (the variant distributes PCA across all 8 GPUs; Table 4 reports no single-GPU run at 500k or 1.3M) and 'translates to well under one dollar of compute rental' (the 7.3 min were measured on 8 H100s, about 0.97 GPU-hours, USD 1.9-3.9 at the stated USD 2 to 4 per hour). The price range has no source.")
flag("G19", "Discussion, multi-GPU",
     "while the remaining 95% of wall time is spent on inherently sequential CPU preprocessing or single-GPU operations",
     "95% restante; preprocessing 'inherently sequential'; 'fundamental constraint'; 8 worker indipendenti con throughput 'near-linear'",
     "Results l. 231: 75% + 21% = 96.2% (fase multi-GPU 17.5/463.4 = 3.8%). Il preprocessing CPU gira a 100 thread (Methods l. 82) e la Limitazione lo definisce 'a property of the software stack ... rather than an intrinsic limit'. Throughput near-linear con 8 analisi concorrenti non misurato, e 500k-1.3M non entrano in una GPU con la pipeline standard.",
     "MISMATCH", "major", f"{MS} ll. 82, 231, 418, 432",
     "Contraddizione interna fra Discussione e Limitazioni; raccomandazione non testata.",
     "Multi-GPU paragraph. 'the remaining 95% of wall time is spent on inherently sequential CPU preprocessing' (Results: 75% + 21%, i.e. 96.2%, with the multi-GPU phase at 3.8%), described as 'a fundamental constraint imposed by pipeline structure', while the Limitations call the same fraction 'a property of the software stack ... rather than an intrinsic limit' and the CPU steps ran on 100 threads. 'yielding near-linear throughput scaling in the number of concurrent studies' was not measured, and 500k and 1.3M do not fit on one GPU with the standard pipeline.")
flag("G20", "Results / Discussion, scRNA-seq concordance",
     "Floating-point non-associativity in GPU parallel reductions contributes negligibly to observed differences",
     "differenze dovute a stocasticita' di Leiden, nessun bias sistematico, contributo floating-point trascurabile; pipeline 'interchangeable'",
     "La concordanza e' calcolata su una sola ripetizione (/tmp/repo/results/concordance_10000_r1.json) senza baseline intra-implementazione (stessa implementazione, semi diversi): la ripartizione fra stocasticita', implementazione e floating point non e' stimata. kNN Jaccard 0.930 indica che il grafo in ingresso a Leiden differisce per circa il 7% dei vicini. 'entirely consistent' e 'interchangeable' su 10k celle sole.",
     "UNSUPPORTED", "major", f"{MS} ll. 240-244, 422; ls /tmp/repo/results/concordance_*",
     "Attribuzione causale non testata.",
     "Attribution of CPU-GPU clustering differences. Results: 'reflects the inherent stochasticity of the Leiden algorithm ... rather than indicating any systematic bias'; Discussion: 'entirely consistent with the algorithm's inherent stochasticity' and 'Floating-point non-associativity ... contributes negligibly ..., as the dominant source of variation is the Leiden algorithm's non-deterministic vertex ordering', concluding that the pipelines are 'interchangeable'. Concordance comes from one repeat at 10k cells (`results/concordance_10000_r1.json`), with no within-implementation seed baseline, and the kNN graphs fed to Leiden overlap at a mean Jaccard of 0.930.")
flag("G21", "Results / Discussion / Fig. 9, spatial clustering",
     "between the leidenalg (CPU) and cuGraph (GPU) Leiden implementations",
     "backend CPU di Leiden nello spatial = leidenalg; divergenza a HD 2 um 'not specific to GPU versus CPU'",
     "SPATIAL/scripts/benchmark_spatial_cpu.py:333-335 usa sc.tl.leiden(..., flavor=\"igraph\", n_iterations=2), come la pipeline scRNA (Methods l. 62). Il backend spatial non e' dichiarato nei Methods. L'attribuzione della divergenza (ARI 0.080; 2,559 vs 538 cluster) a differenze di implementazione non e' testata.",
     "MISMATCH", "major", f"{MS} ll. 62, 379, 399, 430; /tmp/repo/SPATIAL/scripts/benchmark_spatial_cpu.py:333-335",
     "Nome del backend errato in tre punti; spiegazione non verificata.",
     "Spatial Leiden backend and the 2 um divergence. Fig. 9 caption, Results and Discussion name 'leidenalg (CPU)', whereas `SPATIAL/scripts/benchmark_spatial_cpu.py` (lines 333-335) calls `sc.tl.leiden(..., flavor=\"igraph\", n_iterations=2)`, as in the scRNA-seq pipeline; Methods do not state the spatial backend. 'is not specific to GPU versus CPU comparison; rather, it reflects the fundamental sensitivity of stochastic graph-partitioning algorithms' is not tested by any within-implementation comparison.")
flag("G22", "Discussion, spatial",
     "is, to our knowledge, the largest GPU speedup reported for any spatial transcriptomics operation",
     "il 3,272x e' il piu' grande speedup GPU mai riportato per un'operazione spatial",
     "Nessun confronto con la letteratura ne' citazione a supporto.",
     "UNSUPPORTED", "major", f"{MS} l. 428",
     "Affermazione di priorita' senza supporto.",
     "Priority claim without support: 'is, to our knowledge, the largest GPU speedup reported for any spatial transcriptomics operation'. No comparison or citation is given.")
flag("G23", "Discussion, spatial",
     "achieved similarly impressive speedups of 162-170x",
     "Moran's I e Geary's C 162-170x",
     "Results l. 348, Fig. 8 e Table 9: 162x e 163x (162-163x).",
     "MISMATCH", "minor", f"{MS} ll. 346, 348, 358-359, 428", "Refuso numerico.",
     "Spatial autocorrelation range: Discussion 'speedups of 162-170x' against 162-163x in Results, Fig. 8 and Table 9.")
flag("G24", "Results, Stress test",
     "while recorded peak aggregate VRAM was only 49 GB out of 640 GB (7.6%)",
     "49 GB su 640 GB = 7.6%",
     "49/640 = 7.66% (7.7%); 7.6% corrisponde a 48.8 GB (48.8/640 = 7.63%), valore riportato poco dopo. Lo stesso 7.6% e' in abstract, Discussione e Conclusioni.",
     "MISMATCH", "minor", f"{MS} ll. 14, 262, 424, 437", "Arrotondamento: dichiarare 48.8 GB o 7.7%.",
     "Percentage and its base: '49 GB out of 640 GB (7.6%)'. 49/640 is 7.7%; 7.6% follows from 48.8 GB, the value given later in the same paragraph.")
flag("G25", "Results, Spatial concordance / Conclusions",
     "Moran's I and Geary's C Spearman correlations between CPU and GPU exceeded 0.9995 in all cases.",
     "rho > 0.9995 in tutti i casi; Conclusioni 'exceeding 0.9995'",
     "Table 10: Geary's C HD 8 um = 0.9995 (uguale, non superiore). L'abstract usa correttamente '>= 0.9995'.",
     "MISMATCH", "minor", f"{MS} ll. 14, 380, 389, 440", "Disuguaglianza stretta non vera per un caso.",
     "Strict inequality: 'exceeded 0.9995 in all cases' (Results) and 'exceeding 0.9995' (Conclusions), while Table 10 reports 0.9995 for Geary's C on HD 8 um; the abstract writes '>= 0.9995'.")
flag("G26", "Results, Spatial concordance",
     "the CPU pipeline identified 2,559 clusters while the GPU pipeline found 538",
     "differenza di granularita' 4.75x",
     "2559/538 = 4.757, arrotondato 4.76x.", "MISMATCH", "minor", f"{MS} ll. 398-399", "Arrotondamento.",
     "Ratio rounding: 2,559/538 = 4.76, reported as '4.75x'.")
flag("G27", "Results, Per-step heading",
     "### Per-step speedup varies over two orders of magnitude",
     "titolo: 'over two orders of magnitude'; testo: 'nearly two orders of magnitude'",
     "Il range per-step va da 0.36x (Leiden 10k) a 329x (rapporto ~900, quasi tre ordini); considerando solo gli step accelerati 4.8x-329x (~1.8 ordini). Titolo e testo non concordano.",
     "MISMATCH", "minor", f"{MS} ll. 215, 217, 223", "Incoerenza titolo/testo.",
     "Heading and text disagree: 'varies over two orders of magnitude' against 'ranging across nearly two orders of magnitude'; the reported per-step values run from 0.36x to 329x.")
flag("G28", "Methods, Spatial concordance metrics / Table 10",
     "(with N taking the values 50, 100, and 200)",
     "SVG Jaccard calcolato per top-50, top-100, top-200",
     "Table 10 riporta solo top-50 e FDR < 0.05; la didascalia parla di 'top-N'.", "UNSUPPORTED", "minor",
     f"{MS} ll. 149, 384-391", "Metriche dichiarate e non riportate.",
     "Declared metrics not reported: SVG Jaccard for 'N taking the values 50, 100, and 200', while Table 10 shows only top 50 and FDR < 0.05.")
flag("G29", "Table 9 caption",
     "Per-step wall time and GPU speedup for spatial-specific operations on Visium HD 8 um",
     "tabella di operazioni spatial-specific", "La tabella include PCA, normalisation, UMAP, HVG, expression neighbours, Leiden.",
     "MISMATCH", "minor", f"{MS} ll. 351-365", "Didascalia non corrisponde al contenuto.",
     "Table 9 caption says 'spatial-specific operations' but the table lists expression steps (PCA, normalisation, UMAP, HVG selection, neighbours, Leiden).")
flag("G30", "Methods, Hardware (repeats) / Tables 4-7",
     "Each benchmark configuration was repeated five times; we report mean +/- standard deviation.",
     "ogni configurazione ripetuta 5 volte; media +/- SD",
     "In /tmp/repo/results stress test (maxpower_*), DE (de_benchmark_*) e concordanza (concordance_10000_r1) hanno un solo file per configurazione; Tables 5, 7 non riportano SD. Non e' dichiarato se la SD sia campionaria o di popolazione, ne' se 'Peak RAM/VRAM' in Table 4 siano medie o massimi sulle ripetizioni.",
     "MISMATCH", "minor", f"{MS} ll. 165, 187-213, 269-279, 310-319; ls /tmp/repo/results",
     "Convenzioni da dichiarare.",
     "Repeats and dispersion conventions. 'Each benchmark configuration was repeated five times; we report mean +/- standard deviation.' The stress test, DE benchmark and concordance analysis have one result file per configuration in `results/`, and Tables 5 and 7 carry no SD. The SD type (sample or population) and whether the Table 4 peak-memory columns are means or maxima over repeats are not stated.")
flag("G31", "Methods, CPU threading",
     "Only the pool corresponding to the BLAS library that NumPy was linked against at build time is actually active at runtime; the other variables are harmlessly ignored.",
     "solo il pool BLAS e' attivo; le altre variabili sono ignorate",
     "La frase precedente dice che OpenMP serve 'several sklearn inner loops' e Numba e' 'the JIT backend of umap-learn': pool attivi indipendentemente dalla libreria BLAS. Il paragrafo argomenta (portabilita') invece di descrivere.",
     "MISMATCH", "minor", f"{MS} l. 82", "Non riscritto perche' contiene questa contraddizione.",
     "Thread-pool paragraph in Methods argues and contradicts itself: 'Only the pool corresponding to the BLAS library ... is actually active at runtime; the other variables are harmlessly ignored', after naming OpenMP (scikit-learn loops) and Numba (umap-learn) as backends that do not depend on the BLAS choice.")
flag("G32", "Methods, Concordance metrics",
     "we selected six concordance metrics, one for each major stage of the analysis pipeline",
     "sei metriche, una per stadio",
     "Table 2: sei metriche su cinque ambiti (ARI e NMI entrambe 'Clustering').", "MISMATCH", "minor",
     f"{MS} ll. 94, 98-105", "Conteggio non coerente con Table 2.",
     "'six concordance metrics, one for each major stage of the analysis pipeline': Table 2 assigns ARI and NMI to the same stage (Clustering), giving five stages.")
flag("G33", "Methods, Stress test",
     "We conducted a binary search from 3.4M to 13.7M cells to identify the failure point.",
     "ricerca binaria 3.4M-13.7M",
     "Table 5 riporta 7 punti (3.4, 6.9, 10.3, 11.5, 11.9, 12.0, 13.7M); /tmp/repo/results contiene anche 1.7M, 8.5M, 9.4M, 9.8M, 10.0M, 10.1M, 10.2M, 11.1M, 11.7M, 11.8M. La tabella e' una selezione non dichiarata e 13.7M e' detto 'a separate test' (l. 260).",
     "UNSUPPORTED", "minor", f"{MS} ll. 111, 260, 271-279; ls /tmp/repo/results/maxpower_*",
     "Criterio di selezione delle righe di Table 5 non dichiarato.",
     "Binary search and Table 5. 'We conducted a binary search from 3.4M to 13.7M cells', while Table 5 lists seven sizes, `results/` holds further sizes (1.7M, 8.5M, 9.4M, 9.8M, 10.0M to 11.8M), and 13.7M is called 'a separate test'. The selection rule for the table is not stated.")
flag("G34", "Methods, Reproducibility / Introduction",
     "inside a Singularity container built from the Docker image `lucavd/sc-benchmark:latest`",
     "immagine che 'pins the full package environment'; Introduzione: 'full reproducibility'",
     "Il tag 'latest' e' mutabile e non identifica un'immagine; manca digest o tag di versione.", "UNSUPPORTED", "minor",
     f"{MS} ll. 44, 171", "Affermazione di riproducibilita' piu' forte di quanto il riferimento garantisca.",
     "Reproducibility claim and a mutable tag: 'Docker image `lucavd/sc-benchmark:latest` ..., which pins the full package environment', and 'provide all code and containers for full reproducibility'. A `latest` tag does not identify an image.")
flag("G35", "Results, Multi-GPU",
     "The timing breakdown (Fig. 4) reveals why: in a representative 8-GPU run at 1.3M cells (total 463.4 s)",
     "run 'representative' di 463.4 s",
     "La media 8 GPU a 1.3M e' 435.2 +/- 16.2 s (Table 4); 463.4 s e' 1.7 SD sopra la media. Criterio di scelta non dichiarato.",
     "UNSUPPORTED", "minor", f"{MS} ll. 213, 231", "Definire quale ripetizione e perche'.",
     "'a representative 8-GPU run at 1.3M cells (total 463.4 s)': Table 4 gives 435.2 +/- 16.2 s; the selection criterion is not stated.")
flag("G36", "Results, Concordance",
     "with 30 of the 40 pairs exceeding the stringent threshold of rho > 0.97",
     "soglia rho > 0.97", "Soglia non definita nei Methods (Table 2) e non giustificata.", "UNSUPPORTED", "minor",
     f"{MS} ll. 98-105, 242", "Soglia da dichiarare come regola nei Methods.",
     "Threshold introduced in Results only: 'exceeding the stringent threshold of rho > 0.97'. Table 2 and the Methods define no threshold.")
flag("G37", "Results, Stress test (variants)",
     "Inspired by the chunked-preprocessing strategy of ScaleSC [@Hu2025], we also implemented a third variant",
     "due varianti (sparse-scatter, chunked) descritte solo nei Risultati",
     "Methods descrivono solo la pipeline memory-optimised; sparse-scatter (l. 265) e chunked (l. 267) e la 'variant pipeline at 14M cells' (l. 304) non hanno descrizione metodologica.",
     "UNSUPPORTED", "minor", f"{MS} ll. 107-111, 265, 267, 304", "Metodo nei Risultati.",
     "Method described in Results: the sparse-scatter optimisation (line 265), the ScaleSC-inspired chunked variant ('we also implemented a third variant that performs HVG selection on per-gene running statistics') and the 'variant pipeline at 14M cells' have no Methods description.")
flag("G38", "Abstract / Conclusions, spatial",
     "We extended the benchmark to spatial transcriptomics on three 10x Visium platforms",
     "tre piattaforme Visium; Conclusioni: '51.6x end-to-end speedup on Visium HD'",
     "Methods l. 122: due dataset (Visium v1, Visium HD) con HD a due bin size. Il 51.6x vale solo per HD 8 um; HD 2 um 10.8x.",
     "MISMATCH", "minor", f"{MS} ll. 14, 122, 336, 440", "Terminologia e generalizzazione.",
     "'three 10x Visium platforms' (abstract, Results) against 'two 10x Genomics public datasets' with Visium HD at two bin sizes (Methods); Conclusions 'delivers 51.6x end-to-end speedup on Visium HD' holds for 8 um only (2 um: 10.8x).")
flag("G39", "Discussion, operation-specific speedup",
     "whereas on small datasets the overhead of GPU operations may outweigh their benefits",
     "su dataset piccoli l'overhead GPU puo' superare i benefici", "A 10k celle (il dataset piu' piccolo) lo speedup end-to-end e' 12x (39.5/3.3 = 11.97).",
     "UNSUPPORTED", "minor", f"{MS} ll. 184, 416", "Generalizzazione non supportata dal dato piu' piccolo.",
     "'on small datasets the overhead of GPU operations may outweigh their benefits': at the smallest size tested, 10k cells, the end-to-end speedup was 12-fold.")
flag("G40", "Discussion, spatial",
     "meaning that scientists can obtain identical rankings of spatially variable genes in seconds rather than minutes",
     "ranking identici degli SVG", "Table 10: Jaccard dei set top-50 = 1.0 (identita' di insiemi, non di ranking); set FDR 98.2-100%.",
     "UNSUPPORTED", "minor", f"{MS} ll. 381-382, 390-391, 428", "Set uguali non implicano ranking uguali.",
     "'identical rankings of spatially variable genes': the data show identical top-50 sets (Jaccard = 1.0) and 98.2-100% overlap at FDR < 0.05, not identical rankings.")
flag("G41", "Discussion, DE",
     "is ultimately limited by the I/O cost of converting sparse matrices to dense gene chunks",
     "limite I/O della conversione sparse-dense; argsort efficiente su dati sparsi",
     "Nessuna profilazione per step del DE GPU e' riportata a supporto di nessuno dei due meccanismi.", "UNSUPPORTED", "minor",
     f"{MS} l. 426", "Meccanismi affermati senza misura.",
     "Mechanisms without measurement: GPU DE 'is ultimately limited by the I/O cost of converting sparse matrices to dense gene chunks' and the Wilcoxon advantage 'reflects the fact that CuPy's `argsort` maps efficiently onto sparse data'. No profiling is reported.")
flag("G42", "Introduction / Methods, uncited generalisations",
     "This dataset is the canonical large-scale single-cell benchmark",
     "'the canonical large-scale single-cell benchmark'; 'most benchmarks report headline speedups'; 'the common intuition'",
     "Generalizzazioni senza citazione.", "UNSUPPORTED", "minor", f"{MS} ll. 34, 54, 424", "Aggiungere fonte o attenuare (decisione dell'autore).",
     "Uncited generalisations: 'This dataset is the canonical large-scale single-cell benchmark' (Methods), 'most benchmarks report headline speedups without systematically examining' (Introduction), 'This challenges the common intuition that GPU memory availability limits GPU-accelerated analysis' (Discussion).")
flag("G43", "Conclusions, closing sentence",
     "These results provide practical guidance for the computational bioinformatics community as single-cell and spatial datasets grow toward the billion-cell and billion-bin scales [@Regev2017].",
     "frase di chiusura con citazione", "Frase di significato generico (stock closer) e ripete la chiusura dell'abstract; la scala 'billion-bin' spatial difficilmente e' sostenuta da una fonte del 2017. Non tagliata perche' porta una citazione da verificare (track citazioni).",
     "UNSUPPORTED", "minor", f"{MS} ll. 14, 441", "Candidata al taglio dopo verifica della citazione.",
     "Stock closing sentence with a citation: 'These results provide practical guidance for the computational bioinformatics community as single-cell and spatial datasets grow toward the billion-cell and billion-bin scales [@Regev2017].' It repeats the abstract's closer; whether a 2017 source supports 'billion-bin' spatial scales needs checking.")
flag("G44", "Affiliations / Funding",
     "^3^ Neuromuscular Unit, Department of Neuroscience, University of Padua, Padua, Italy",
     "University of Padova / University of Padua", "'Padova' alle ll. 8, 154, 451; 'Padua' alle ll. 12, 455.", "MISMATCH", "minor",
     f"{MS} ll. 8, 12, 154, 451, 455", "Forma del nome dell'ateneo da uniformare (scelta dell'autore).",
     "Institution name in two forms: 'University of Padova' (affiliation 1, hardware, acknowledgements) and 'University of Padua, Padua' (affiliation 3, funding).")
flag("G45", "Table 6",
     "The baseline components are a reconstruction that sums to the 535 GB recorded at the last successful run (11.9M cells).",
     "componenti baseline sommano a 535 GB",
     "190 + 190 + 96 + 60 = 536 GB; la matrice densa e' calcolata a 12M (12M x 2000 x 4 = 96 GB) mentre il subtotale e' misurato a 11.9M (95.2 GB).",
     "MISMATCH", "minor", f"{MS} ll. 283, 288-292", "Base delle righe (12M o 11.9M) da uniformare.",
     "Table 6 baseline: 'a reconstruction that sums to the 535 GB recorded at the last successful run (11.9M cells)'; the rows sum to 536 GB and the dense matrix row is computed for 12M cells (96 GB) rather than 11.9M (95.2 GB).")

# ---- B. rendering defects (fixed in the copy, to apply to the original)
flag("G46", "Table 2 (rendering)", "| PCA loading |rho| |",
     "riga di Table 2", "pandoc 3.1.3: le barre non escapate dividono la cella; la riga resa ha 'rho' come definizione e perde definizione e ambito.",
     "MISMATCH", "major", f"{MS} l. 101; pandoc -t html", "Corretto nella copia (tier 1, `\\|rho\\|`); da riportare nell'originale.",
     "Table 2 row breaks in rendering: '| PCA loading |rho| |' splits the cell, so the compiled table shows 'rho' as the definition and drops 'Mean absolute Spearman rho across first 10 PC loadings, accounting for sign flips' and its scope. Fixed in the copy (tier 1).")
flag("G47", "Figure 9 (rendering)",
     "at high granularity.](../figures/fig9_spatial_concordance.png)",
     "Figura 9 con didascalia", "Senza riga vuota dopo l'immagine, pandoc la tratta come immagine inline: niente ambiente figure, didascalia persa (resta solo come alt text).",
     "MISMATCH", "major", f"{MS} ll. 379-380; pandoc -t html", "Corretto nella copia (tier 1); da riportare nell'originale.",
     "Figure 9 is not rendered as a figure: the image line is followed directly by text (line 380), so pandoc treats it as an inline image and the caption is lost. Fixed in the copy (tier 1).")
flag("G48", "Tables 1, 4, 5 (rendering)", "| 1 | Data loading | --- |",
     "celle '---'", "Con smart typography pandoc rende '---' come lineetta em (12 celle).", "MISMATCH", "minor",
     f"{MS} ll. 71, 191-210, 278-279", "Corretto nella copia ('none', 'n.a.').",
     "Twelve table cells contain '---', which pandoc renders as an em dash. Replaced in the copy (tier 1).")

# ---- C. redundancy for LNBI length
red = [
 ("G49", "Abstract / Conclusions",
  "These results identify CPU-side preprocessing as the primary bottleneck and provide practical guidance for deploying GPU-accelerated workflows at atlas scale.",
  "Le Conclusioni (ll. 436-441) ripetono quasi alla lettera i cinque risultati dell'abstract (14.5 h -> 7.3 min, 11.9M e 7.6% VRAM, 44x pseudo-bulk, 51.6x, 3,272x e 0.9995) e chiudono con la stessa formula 'practical guidance'. Il 120x / 14.5 h / 7.3 min compare quattro volte (abstract, l. 183, l. 420, l. 436).",
  "Abstract and Conclusions repeat the same five results almost word for word (14.5 h to 7.3 min; 11.9M cells at 7.6% VRAM; 44x pseudo-bulk; 51.6x and 3,272x; 0.9995) and both close on 'practical guidance'. The 120x / 14.5-hour / 7.3-minute figure appears four times (abstract, Results, Discussion, Conclusions)."),
 ("G50", "Results, Stress test, para 1",
  "This variant moves scaling to CPU (exploiting the 2 TB system RAM), distributes PCA across all 8 GPUs via a covariance-matrix method",
  "Il primo paragrafo della sezione Stress test dei Risultati ripete la descrizione dei Methods (l. 110).",
  "The first Results paragraph on the stress test restates the Methods description of the memory-optimised pipeline ('This variant moves scaling to CPU (exploiting the 2 TB system RAM), distributes PCA across all 8 GPUs ...')."),
 ("G51", "Methods / Results / Table 6 / Discussion, memory instrumentation",
  "the reported peak is the maximum over these post-step samples",
  "Il campionamento della RAM (solo tra step, solo processo padre, limite inferiore) e' spiegato in Methods (l. 111), Results (ll. 262, 304), didascalia Table 6 (l. 283) e Limitazioni (l. 432). Nella copia restano Methods (procedura), didascalia, Discussione e Limitazioni: ancora tre spiegazioni.",
  "The memory instrumentation (between-step, parent process only, lower bound) is explained in Methods, twice in Results, in the Table 6 caption and in the Limitations. After relocation the copy still explains it in the caption, the Discussion and the Limitations."),
 ("G52", "Methods, Hardware / Limitations, DGX driver",
  "We attempted to downgrade the spatial container to an earlier RAPIDS release known to be driver-compatible (RAPIDS 25.02)",
  "La vicenda driver 535.183.01 / CUDA 12.2 / downgrade fallito e' raccontata nei Methods (ll. 161-163) e di nuovo nelle Limitazioni (l. 432).",
  "The DGX driver story (driver 535.183.01, CUDA 12.2 cap, failed downgrade) is told in Methods and again in the Limitations."),
 ("G53", "Discussion, multi-GPU / Limitations / Results",
  "because the marginal speedup of adding GPUs to a single run is only approximately 12%",
  "Il 12% da 2 a 8 GPU compare in Results (l. 229), due volte nello stesso paragrafo della Discussione (l. 418) e nelle Conclusioni; le ultime due frasi del paragrafo (otto worker indipendenti; 'cluster of eight H100 workstations') dicono la stessa cosa. La quota CPU del 75% e il rimedio (preprocessing distribuito) sono sia nel paragrafo multi-GPU della Discussione sia nelle Limitazioni.",
  "The 12% gain from 2 to 8 GPUs appears in Results, twice in one Discussion paragraph, and in the Conclusions; the last two sentences of that paragraph make the same point twice. The 75% CPU fraction and its remedy appear in both the multi-GPU Discussion paragraph and the Limitations."),
 ("G54", "Results, Stress test (13.7M)",
  "A separate test at 13.7 million cells failed earlier, during the CPU-side sparse-to-dense scaling step.",
  "Il fallimento a 13.7M nello scaling e' detto alle ll. 260, 262 (stessa sottosezione), 264 e 281.",
  "The 13.7M failure during scaling is stated four times in the same subsection (lines 260, 262, 264, 281)."),
]
for fid, sec, loc, note, para in red:
    flag(fid, sec, loc, "passaggio ridondante", note, "MISMATCH", "info", f"{MS}",
         "Ridondanza: candidato all'accorciamento per il capitolo LNBI. Non tagliato.", para)

# ---- D. language signals and register (report, never accuse)
flag("G55", "Whole manuscript, language screen",
     "These results reveal several important insights about GPU-accelerated single-cell analysis that merit detailed discussion.",
     "segnali linguistici del testo",
     "Prima della revisione: marker words 5 (comprehensive, leveraging, landscape x3); aperture enfatiche o di impalcatura in Discussione ('Perhaps most importantly', 'Critically', 'Related to this', 'A notable finding', 'This is a non-obvious but important takeaway', frase di rimando al lettore l. 414); iperboli (dramatically x3, impressive, fundamental x4, stringent); 'actually' x4; 'We note that' x2; chiusure formulaiche in abstract, introduzione e conclusioni. Il raggruppamento coincide con fallimenti di verifica (G02, G05, G06, G10, G11, G23). Mediana 26 parole per frase (Discussione 30) contro 16-21 del registro dell'autore. Nella copia restano 0 marker, 0 aperture, 0 interferenze.",
     "MISMATCH", "info", f"{MS}; kernel style_scan, sentence_stats",
     "Proprieta' del testo, non inferenza sull'origine. Springer chiede di documentare l'eventuale uso di LLM nei Methods: valutare la dichiarazione.",
     "Language signals, reported as properties of the text. Before editing: five marker words (comprehensive, leveraging, landscape three times); emphatic or scaffolding openers concentrated in the Discussion ('Perhaps most importantly', 'Critically', 'Related to this', 'A notable finding', 'This is a non-obvious but important takeaway', and a sentence announcing that results 'merit detailed discussion'); intensifiers (dramatically three times, impressive, fundamental four times, stringent); 'actually' four times; 'We note that' twice; formulaic closers in the abstract, the Introduction and the Conclusions. The cluster co-occurs with verification failures (G02, G05, G06, G10, G11, G23). Median sentence length is 26 words (Discussion 30) against the author's 16-21. Springer Nature asks authors to document any use of LLMs in the Methods; the authors may wish to consider that disclosure.")
flag("G56", "Whole manuscript, symbols",
     "achieving up to 51.6x end-to-end speedup (Visium HD 8 um)",
     "trascrizioni ASCII di simboli", "Il .md usa 'um', 'rho', '+/-', '>=', 'x' in modo coerente; full_paper_LNBI_stale.tex li converte in $\\mu$m, $\\rho$, $\\pm$, $\\geq$, $\\times$. Lasciati invariati nella copia.",
     "MISMATCH", "info", f"{MS}; full_paper_LNBI_stale.tex", "Conversione da garantire nella pipeline LaTeX/LNCS.",
     "ASCII stand-ins ('um', 'rho', '+/-', '>=', 'x') are used consistently in the Markdown and converted to symbols in the stale LaTeX; left unchanged in the copy, to be converted at typesetting.")

# write findings JSON
out = []
for f in F:
    out.append({"inv_id": None, "track": "G", "line": f["line"], "section": f["section"],
                "locator": f["locator"], "claimed": f["claimed"], "recomputed": f["recomputed"],
                "status": f["status"], "severity": f["severity"], "source": f["source"],
                "note": f"[{f['fid']}] {f['note']}"})
json.dump(out, open(f"{BASE}/tracks/G_findings.json", "w", encoding="utf-8"), indent=1, ensure_ascii=False)

# write flagged.md
from collections import Counter
with open(f"{W}/flagged.md", "w", encoding="utf-8") as fh:
    fh.write("# Track G: flagged, not changed (tier 3)\n\n")
    fh.write("Line numbers refer to the original `full_paper_LNBI.md`. Each item is also in `tracks/G_findings.json` "
             "under the same identifier. Items G46-G48 were mechanical defects fixed in the copy and are listed so "
             "that they reach the original.\n\n")
    heads = {"G01": "## Contradictions, arithmetic and claims beyond the design\n\n",
             "G46": "## Rendering defects (fixed in the copy)\n\n",
             "G49": "## Redundancy a reviewer would ask to shorten (LNBI chapter)\n\n",
             "G55": "## Language signals and typesetting\n\n"}
    for f in F:
        if f["fid"] in heads:
            fh.write(heads[f["fid"]])
        fh.write(f"**{f['fid']}** ({f['severity']}, line {f['line']}). {f['para']}\n\n")
c = Counter((f["severity"]) for f in F); s = Counter(f["status"] for f in F)
print("flags", len(F), dict(c), dict(s))
