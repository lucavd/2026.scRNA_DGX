import importlib.util
KP="/root/.claude/skills/synced/8ef7b99f-0db6-4f39-9db4-aa2bf2f215a5_4247652b-7a1c-4f7e-b618-83c36434b2dd/manuscript-style-review/kernel.py"
spec=importlib.util.spec_from_file_location("kernel",KP); K=importlib.util.module_from_spec(spec); spec.loader.exec_module(K)
