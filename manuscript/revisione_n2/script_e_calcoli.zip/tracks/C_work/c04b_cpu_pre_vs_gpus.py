"""Scompone la differenza 2 GPU vs 8 GPU a 1.3M per step: da dove viene il 12% (testo righe 229-232)."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from c00_load import load, mean, sd
STEPS = ["data_loading","qc_filtering","normalization","hvg_selection","gpu_transfer","scale","pca","neighbors",
         "leiden_0.5","leiden_1.0","leiden_1.5","umap","de_testing","total"]
for n in [500000, 1300000]:
    print(n)
    d = {g: load(f"gpu{g}")[n] for g in [2, 4, 8]}
    for s in STEPS:
        v = {g: [r["timings"][s] for r in d[g]] for g in d}
        print(f"  {s:14s} " + "  ".join(f"{g}GPU {mean(v[g]):8.2f}+/-{sd(v[g]):6.2f}" for g in d) + f"   diff8-2 {mean(v[8])-mean(v[2]):+8.2f}")
    print("  timestamps 2GPU", [r['metadata']['timestamp'][:16] for r in d[2]])
    print("  timestamps 8GPU", [r['metadata']['timestamp'][:16] for r in d[8]])
