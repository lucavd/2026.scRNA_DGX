"""Figure 9 (fig9_spatial_concordance.png): ricalcola le 15 barre (5 metriche x 3 piattaforme) dai file
SPATIAL/results/spatial_concordance_<platform>.json (lista per ripetizione). Riporta valore per rep, media r1-5
e media r2-5, e confronta con le etichette visibili (0.856, 0.080) e con Table 10."""
import json

PL = {"visium": "Visium v1", "visium_hd_square_008um": "HD 8 um", "visium_hd_square_002um": "HD 2 um"}
MET = [("Moran rho", lambda r: r["moranI"]["I_spearman_rho"]),
       ("Geary rho", lambda r: r["gearyC"]["C_spearman_rho"]),
       ("SVG top-50 (Moran)", lambda r: r["moranI"]["svg_jaccard_top50"]),
       ("SVG FDR<0.05 (Moran)", lambda r: r["moranI"]["svg_jaccard_fdr005"]),
       ("Cluster ARI", lambda r: r["clusters"]["ari"]),
       ("Cluster NMI", lambda r: r["clusters"]["nmi"]),
       ("n clusters CPU/GPU", lambda r: (r["clusters"]["n_clusters_cpu"], r["clusters"]["n_clusters_gpu"])),
       ("SVG FDR<0.05 (Geary)", lambda r: r["gearyC"]["svg_jaccard_fdr005"]),
       ("SVG top-50 (Geary)", lambda r: r["gearyC"]["svg_jaccard_top50"])]
FIG = {"visium": [1.0, 1.0, 1.0, 1.0, 0.856], "visium_hd_square_008um": [0.9999, 0.9995, 1.0, 0.999, 0.974],
       "visium_hd_square_002um": [1.0, 0.9999, 1.0, 0.982, 0.080]}
for p, name in PL.items():
    d = json.load(open(f"/tmp/repo/SPATIAL/results/spatial_concordance_{p}.json"))
    print(f"== {name}: {len(d)} rep, ids {[r['repeat_id'] for r in d]}")
    for i, (m, f) in enumerate(MET):
        vals = [f(r) for r in d]
        if isinstance(vals[0], tuple):
            print(f"   {m:22s} {vals}"); continue
        m15 = sum(vals) / len(vals); m25 = sum(vals[1:]) / len(vals[1:])
        extra = f"  fig/Table10 {FIG[p][i]}" if i < 5 else ""
        print(f"   {m:22s} per rep {vals}  mean1-5 {m15:.4f} mean2-5 {m25:.4f}{extra}")
    # co-occurrence concordance
    print("   co_occurrence:", [r.get("co_occurrence", {}).get("status", r.get("co_occurrence")) if isinstance(r.get("co_occurrence"), dict) else r.get("co_occurrence") for r in d][:2])
