"""Legge dalla PNG di Fig. 7 le altezze delle barre (asse log) e le barre di errore, e le confronta con
i valori ricalcolati (media r2-5, SD ddof=1). Tick maggiori 10^4,10^3,10^2,10^1 a y = 81, 305, 528, 752 px
(trovati con c07 inline: spina x=175)."""
from PIL import Image
import numpy as np, math

im = np.asarray(Image.open('/tmp/repo/figures/fig7_spatial_speedup.png').convert('RGB')).astype(int)
ticks = {4: 81.0, 3: 305.0, 2: 528.0, 1: 752.0}
# regressione lineare y = a + b*log10(v)
xs = np.array(list(ticks.keys()), float); ys = np.array(list(ticks.values()))
b, a = np.polyfit(xs, ys, 1)
val = lambda y: 10 ** ((y - a) / b)

def is_col(px, rgb, tol=40):
    return np.abs(px - np.array(rgb)).sum(axis=-1) < tol

blue = is_col(im, (31, 119, 180)); orange = is_col(im, (255, 127, 14))
res = {}
for name, mask in [('CPU', blue), ('GPU', orange)]:
    colsum = mask.sum(axis=0)
    # segmenti di colonne con barre
    xs_on = np.where(colsum > 20)[0]
    segs = []
    for x in xs_on:
        if segs and x - segs[-1][-1] <= 2: segs[-1].append(x)
        else: segs.append([x])
    segs = [s for s in segs if len(s) > 50]
    out = []
    for s in segs:
        xc = (s[0] + s[-1]) // 2
        ys_on = np.where(mask[:, s[0] + 5:s[-1] - 5].any(axis=1))[0]
        if ys_on.max() < 700:  # patch di legenda, non tocca l'asse x
            continue
        # cima del tratto contiguo che arriva alla base (esclude la patch di legenda sovrapposta)
        top = ys_on.max()
        while top - 1 in set(ys_on.tolist()):
            top -= 1
        # barra di errore: pixel neri sopra/sotto la cima lungo la colonna centrale
        colc = (im[:, xc].sum(axis=1) < 120)
        eb = np.where(colc[max(0, top - 40): top + 40])[0] + max(0, top - 40)
        out.append((round(val(top), 1), (round(val(eb.min()), 1), round(val(eb.max()), 1)) if len(eb) else None, int(top)))
    res[name] = out
    print(name, out)
ref = {'CPU': [(10.03, 0.08), (4068.4, 7.66), (1041.99, 40.54)], 'GPU': [(5.99, 0.08), (78.79, 1.08), (96.73, 1.24)]}
for k in ref:
    for (v, e, _), (m, s) in zip(res[k], ref[k]):
        print(f"{k}: letto {v} (errbar {e}) atteso {m} +/- {s} -> diff {100*(v-m)/m:+.1f}%")
print('risoluzione: 1 px =', round(100 * (10 ** (1 / abs(b)) - 1), 2), '% del valore')
