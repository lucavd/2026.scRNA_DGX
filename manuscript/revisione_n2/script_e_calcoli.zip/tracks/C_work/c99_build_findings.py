"""Costruisce tracks/C_findings.json. Ogni locator viene verificato come sottostringa esatta della riga
indicata di full_paper_LNBI.md (md5 4587032be8d2905007687e0bb50d848e). Controlla assenza di lineette em/en."""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
REV = os.path.dirname(os.path.dirname(HERE))
L = open(os.path.join(REV, "full_paper_LNBI.md"), encoding="utf-8").read().split("\n")
W = "tracks/C_work/"
F = []


def add(inv_id, line, section, locator, claimed, recomputed, status, severity, source, note):
    assert locator in L[line - 1], (line, locator)
    assert len(locator) <= 200, (line, len(locator))
    F.append(dict(inv_id=inv_id, track="C", line=line, section=section, locator=locator, claimed=claimed,
                  recomputed=recomputed, status=status, severity=severity, source=source, note=note))


SC = "Results > Single-cell RNA-seq > "
SP = "Results > Spatial transcriptomics > "

# ---------------------------------------------------------------- righe dell'inventario (18)
add("A0046", 88, "Data and Methods > Single-cell RNA-seq > Multi-GPU pipeline",
    "on a single GPU, normalisation is 329x faster than CPU (Fig. 1)",
    "normalisation 329x piu' veloce su GPU (Fig. 1), senza qualificare la taglia",
    "Fig. 1: 329.3x a 10k, 206.1x a 50k, 173.1x a 100k (rapporto delle medie su 5 rep). Escludendo r1: 115.1x, 134.2x, 137.4x. CPU normalisation 10k r1 = 1.749 s contro 0.097-0.099 s in r2-r5",
    "MISMATCH", "minor",
    "results/cpu_{N}_r{1..5}_results.json e gpu_{N}_r{1..5}: timings.normalization, mean(CPU)/mean(GPU); " + W + "c01_fig1_heatmap.py, c12_misc_checks.py (a)",
    "Il 329x e' il massimo a 10k, gonfiato dal primo run CPU (warmup). L'argomento riguarda 500k e 1.3M, dove il trend della figura scende (173x a 100k). Scrivere 'up to 173-329x (10k-100k)' o usare i valori senza warmup.")

add("A0127", 217, SC + "Per-step speedup varies over two orders of magnitude",
    "reveal that GPU advantage varies dramatically by operation type, ranging across nearly two orders of magnitude",
    "lo speedup per step varia su quasi due ordini di grandezza (Fig. 1, Fig. 2)",
    "Fig. 1: min 0.3648x (Leiden 0.5, 10k), max 329.29x (normalisation, 10k): rapporto 902.7 = 2.96 ordini di grandezza; limitandosi agli step con GPU piu' veloce (min 1.36x) 2.38 ordini",
    "MISMATCH", "minor",
    W + "c01_fig1_heatmap.py (matrice 11x3 di mean CPU / mean GPU)",
    "Il titolo della sezione dice 'over two orders', la frase 'nearly two orders': la figura mostra quasi tre ordini. Rimandi a Fig. 1 e Fig. 2 corretti (heatmap e tempi assoluti).")

add("A0131", 219, SC + "Per-step speedup varies over two orders of magnitude",
    "**Figure 1.** Per-step speedup of single-GPU rapids-singlecell (1xH100 80 GB) relative to CPU Scanpy (100 cores) at 10k, 50k, and 100k cells.",
    "heatmap speedup per step 10k/50k/100k; normalisation fino a 329x; data loading 0.76-0.85x",
    "33/33 annotazioni della heatmap coincidono con mean(CPU, 5 rep)/mean(GPU, 5 rep) arrotondato come nello script (es. 329.3, 206.1, 173.1; data loading 0.85, 0.80, 0.76; Leiden 0.5 0.36, 1.80, 3.58). n = 5+5 per cella. CPU n_cpus = 100",
    "PASS", "info",
    "results/cpu_* e gpu_* (1 GPU) timings.<step>; " + W + "c01_fig1_heatmap.py; figura rigenerata identica in " + W + "repro_scrna/out_main/fig1_speedup_heatmap.png",
    "Valori corretti. La didascalia non dichiara la convenzione (rapporto delle medie su 5 ripetizioni, warmup incluso): vedi finding sul warmup. Etichette in inglese americano (Normalization, Neighbors) contro il testo (normalisation, neighbours). La riga 'PCA' include sc.pp.scale.")

add("A0132", 221, SC + "Per-step speedup varies over two orders of magnitude",
    "On CPU, DE testing and neighbour graph construction dominate; on GPU, all steps complete in seconds.",
    "su CPU dominano DE testing e costruzione del grafo dei vicini",
    "Quote del tempo CPU (media 5 rep): 10k DE 54.9%, UMAP 24.6%, neighbors 12.4%; 50k DE 84.9%, UMAP 7.9%, neighbors 2.3%; 100k DE 86.9%, UMAP 7.5%, neighbors 1.4%. Neighbors e' sempre terzo. Totali impilati 39/282/647 s (CPU), 3/8/15 s (GPU) = etichette della figura; step GPU piu' lungo 6.4 s",
    "MISMATCH", "major",
    "results/cpu_{10000,50000,100000}_r*.json timings; " + W + "c02_fig2_timing_breakdown.py",
    "La didascalia nomina il secondo contributo sbagliato: e' UMAP, non neighbours. Inoltre il file e' fig5_timing_breakdown.png per la Figure 2 e le barre GPU (3-15 s su assi fino a 700 s) sono illeggibili: la scomposizione GPU che la didascalia commenta non si vede.")

add("A0136", 227, SC + "Multi-GPU scaling is sublinear: CPU preprocessing dominates",
    "Adding GPUs beyond two provided diminishing returns (Fig. 3).",
    "oltre due GPU rendimenti decrescenti",
    "Variazione del tempo totale (media 5 rep): 1->2 GPU +48% (10k), +75% (50k), +82% (100k); 2->8 GPU 0.0%, +2.7%, -1.9%, +0.1% (500k), -11.8% (1.3M). Fase multi-GPU (PCA+neighbours) a 1.3M: 17.2 s (2 GPU), 17.0 s (4), 17.0 s (8)",
    "MISMATCH", "major",
    "results/gpu{,2,4,8}_{N}_r*.json timings.total, pca, neighbors; " + W + "c03_fig3_scaling.py, c04b_cpu_pre_vs_gpus.py",
    "'Diminishing returns' presuppone guadagni positivi che calano: la figura mostra rendimento nullo da 2 a 8 GPU (anche nella sola fase distribuita) e peggioramento da 1 a 2 GPU, perche' 1 GPU e 2+ GPU sono due pipeline diverse (tutto su GPU contro preprocessing su CPU). Va detto esplicitamente.")

add("A0139", 231, SC + "Multi-GPU scaling is sublinear: CPU preprocessing dominates",
    "in a representative 8-GPU run at 1.3M cells (total 463.4 s), CPU preprocessing (data loading + QC + normalisation + HVG selection) consumed 348.7 s (75%)",
    "run rappresentativo 8 GPU 1.3M: 463.4 s; CPU prep 348.7 s (75%); multi-GPU 17.5 s (4%); single-GPU 97.2 s (21%)",
    "gpu8_1300000_r1: total 463.4, CPU prep 348.7 (75.2%), PCA+neighbours 17.5 (3.8%), transfer+scale+Leiden+UMAP+DE 97.2 (21.0%): aritmetica corretta. Ma r1 e' il run piu' lento dei 5 (r2-r5: 432.4, 430.4, 427.0, 422.7 s). Fig. 4 mostra la media: 435 s, quote 78.0% / 3.9% / 18.1%",
    "MISMATCH", "minor",
    "results/gpu8_1300000_r{1..5}_results.json timings; " + W + "c04_fig4_multigpu.py",
    "Numeri giusti per r1, ma r1 non e' rappresentativo (e' il piu' lento, single-GPU 97 s contro 66-77 s) e non e' cio' che Fig. 4 disegna. Usare la media su 5 rep (435.2 s, 78/4/18%) per coerenza con la figura e con Table 4.")

add("A0141", 234, SC + "Multi-GPU scaling is sublinear: CPU preprocessing dominates",
    "**Figure 3.** Total pipeline wall time vs number of GPUs (1, 2, 4, 8 H100), one line per dataset size. Error bars: SD over five repeats.",
    "1, 2, 4, 8 H100, una linea per taglia; barre SD su 5 rep; baseline CPU tratteggiate; asse y log; curve piatte = scaling sublineare",
    "Punti e barre coincidono con media e SD campionaria (ddof=1) su 5 rep (es. 10k 1 GPU 3.3 +/- 1.7; 1.3M 8 GPU 435.2 +/- 16.2). A 500k e 1.3M non esistono run a 1 GPU (gpu_500000/gpu_1300000 assenti): quelle due linee partono da 2. La legenda (framealpha 0.9) copre i punti a 8 GPU di 500k (124.6) e 1.3M (435.2). Le baseline CPU hanno alpha 0.3 e spessore 0.7 pt",
    "MISMATCH", "major",
    "results/gpu*_{N}_r*.json timings.total; scripts/generate_figures.py fig_scaling_plot; " + W + "c03_fig3_scaling.py, c03b_legend_overlap.py",
    "La didascalia omette che 1 GPU manca a 500k e 1.3M e che il punto a 1 GPU appartiene a un'altra pipeline (la linea che lo unisce al punto a 2 GPU suggerisce uno scaling che non esiste). Il punto chiave del testo (1.3M, 8 GPU) e' nascosto dalla legenda. 'Flat' non descrive il salto 1->2 GPU (+48-82%).")

add("A0142", 236, SC + "Multi-GPU scaling is sublinear: CPU preprocessing dominates",
    "CPU preprocessing (blue) dominates wall time; the multi-GPU phase (PCA + neighbours, pink) is a small fraction, explaining flat multi-GPU scaling.",
    "preprocessing CPU (blu) domina; fase multi-GPU rosa piccola",
    "Fasi (media 5 rep), 1.3M: 2 GPU 399.5/0.4/17.2/76.2 s; 8 GPU 339.4/0.3/17.0/78.5 s (CPU prep/transfer+scale/multi-GPU/single-GPU). Etichette 4,347/124/125/125 s e 52,056/493/487/435 s corrette. Nella PNG il rosa #EE6677 ha 0 pixel nei pannelli (935 solo in legenda); la barra 8 GPU a 1.3M occupa lo 0.75% dell'asse y, la fase multi-GPU lo 0.03%",
    "MISMATCH", "major",
    "results/gpu{2,4,8}_{500000,1300000}_r*.json; " + W + "c04_fig4_multigpu.py, c04c_fig4_pink_pixels.py",
    "La didascalia descrive un elemento (rosa) che nel pannello non si vede: asse lineare dominato dalla barra CPU (52,056 s). Servono asse log, pannello senza barra CPU o barre GPU normalizzate al 100%.")

add("A0143", 240, SC + "CPU and GPU produce biologically concordant results",
    "Concordance analysis on the 10,000-cell dataset (Fig. 5) demonstrated that the two pipelines yield near-identical biological conclusions",
    "concordanza su 10,000 cellule (Fig. 5)",
    "concordance_10000_r1.json: n_cells 10000; HVG Jaccard 1.0; PCA mean |rho| 1.0; kNN Jaccard 0.930422 (mediana 0.9375, max 0.9375, fraction_perfect 0.0). Timestamp dei run confrontati: CPU 2026-03-11T23:14, GPU 2026-03-11T23:15, mentre i run di benchmark 10k r1 sono del 2026-03-12 (CPU) e 2026-03-15 (GPU)",
    "PASS", "info",
    "results/concordance_10000_r1.json (metadata, *_concordance); results/cpu_10000_r1_results.json e gpu_10000_r1_results.json metadata.timestamp",
    "Rimando corretto. Provenienza: la concordanza e' calcolata su una coppia di run del 11 marzo, non sui run r1 i cui tempi sono in Table 4 e Fig. 1; dichiararlo. Vedi finding separato sul tetto 0.9375 del kNN Jaccard.")

add("A0150", 246, SC + "CPU and GPU produce biologically concordant results",
    "Right: HVG Jaccard (1.000), PCA Spearman |rho| (1.000), and kNN Jaccard (0.930). All metrics indicate near-identical biological outputs.",
    "ARI/NMI a tre risoluzioni; HVG 1.000, PCA 1.000, kNN 0.930",
    "ARI 0.931675/0.907733/0.963095 -> 0.932/0.908/0.963; NMI 0.950564/0.950967/0.970895 -> 0.951/0.951/0.971; HVG 1.0; PCA 1.0; kNN 0.930422 -> 0.930. 9/9 etichette coincidono",
    "PASS", "info",
    "results/concordance_10000_r1.json cluster_concordance, hvg_concordance.jaccard, pca_concordance.mean_abs_spearman_rho, knn_concordance.mean_jaccard; figura rigenerata identica (" + W + "repro_scrna/out_main/fig3_concordance.png)",
    "Valori corretti. Difetti di pannello in finding separato (assi troncati a 0.85, legenda sulle barre, DE logFC rho assente). File fig3_concordance.png per la Figure 5.")

add("A0152", 250, SC + "Memory is not a bottleneck at benchmark scale",
    "CPU RAM usage scaled approximately linearly with cell count, from 1.2 GB at 10k to 107.4 GB at 1.3M cells (Fig. 6, left panel), well below 6% of the 2 TB system memory.",
    "RAM CPU circa lineare, 1.2 GB (10k) -> 107.4 GB (1.3M); < 6% di 2 TB",
    "peak_ram_gb medio CPU: 1.2, 3.6, 6.7, 29.7, 107.4 GB. Pendenza log-log complessiva 0.93 (tratti: 0.68, 0.90, 0.93, 1.35). 107.4/2048 = 5.24%",
    "PASS", "minor",
    "results/cpu_{N}_r*.json memory.peak_ram_gb; " + W + "c05_fig6_memory.py",
    "Numeri corretti e 'approssimativamente lineare' e' difendibile (pendenza 0.93), ma la didascalia di Fig. 6 dice 'super-linearly': contraddizione interna. 5.2% non e' 'well below 6%'.")

add("A0158", 254, SC + "Memory is not a bottleneck at benchmark scale",
    "Left: CPU RAM; right: GPU VRAM (per-device maximum). Dashed red line: H100 80 GB VRAM limit. CPU RAM grows super-linearly;",
    "pannello destro = VRAM massima per device; linea 80 GB; RAM CPU super-lineare",
    "Il pannello destro riporta la VRAM AGGREGATA: benchmark_multigpu.py somma NVML su n_gpus device (get_total_vram_used_gb) e peak_vram_gb = max delle somme. Medie: 2 GPU 52.4-74.9, 4 GPU 65.0-92.7, 8 GPU 106.5-134.2 GB; per device sarebbero 13.3-16.8 GB a 8 GPU. Le linee 4x e 8x superano la linea 80 GB per device. RAM CPU: pendenza log-log 0.93 complessiva",
    "MISMATCH", "major",
    "scripts/benchmark_multigpu.py righe 60-73 e 432-433; results/gpu{2,4,8}_*_r*.json memory.peak_vram_gb; " + W + "c05_fig6_memory.py",
    "Didascalia sbagliata su cosa e' plottato: confrontare valori aggregati con un limite per device suggerisce sforamenti che non esistono. Correggere in 'aggregate VRAM' e togliere la linea o plottare per-device (dato non salvato nei JSON). 'Super-linearly' contraddice il testo (riga 250). Asse x con tick '1000k'.")

add("A0223", 338, SP + "GPU speedup scales dramatically with platform resolution",
    "End-to-end speedup increased from 1.7x on Visium v1 (2,695 spots) to 51.6x on Visium HD 8 um (393,543 bins) (Fig. 7)",
    "speedup end-to-end 1.7x (Visium v1) -> 51.6x (HD 8 um)",
    "Media r2-r5: Visium v1 10.03/5.99 s = 1.67x; HD 8 um 4068.4/78.79 s = 51.64x. Ma per HD 8 um il run CPU r1 escluso come 'warmup' e' il PIU' VELOCE: 584.6 s contro 4062.4-4079.5 s di r2-r5; co_occurrence CPU r1 73.47 s contro 3570.99-3574.25 s in r2-r5 con output identico (array 7x7x49 uguale in tutti i rep). Con r1 come riferimento CPU: 584.6/78.8 = 7.4x; il file di concordanza registra speedup 6.39 per il rep 1",
    "UNSUPPORTED", "critical",
    "SPATIAL/results/spatial_{cpu,gpu}_visium_hd_square_008um_r{1..5}_results.json timings; spatial_concordance_visium_hd_square_008um.json [0].timing.total.speedup; *_co_occurrence.npy; " + W + "c07_fig7_8_spatial.py",
    "Il 51.6x (anche nell'abstract) dipende da un rallentamento anomalo della CPU in r2-r5 (stesso processo Python, stesso calcolo, 49x piu' lento), non da un warmup. La regola 'r1 = JIT warmup' vale per Visium v1 (r1 39.7 s contro 10 s) ma e' invertita per HD 8 um CPU. Va spiegato o rimisurato prima di pubblicare 51.6x.")

add("A0224", 340, SP + "GPU speedup scales dramatically with platform resolution",
    "Error bars: standard deviation across repeats 2-5 (repeat 1 excluded for JIT warmup). HD 2 um was subsampled to 400k bins due to local VRAM constraints.",
    "speedup 1.7x-51.6x; barre = SD r2-5; r1 escluso per JIT warmup; HD 2 um sottocampionato a 400k",
    "Altezze lette dalla PNG (asse log, 1 px = 1.04%): CPU 9.9/4044.7/1028.2 s, GPU 5.9/77.5/95.3 s contro attesi 10.03/4068.4/1042.0 e 5.99/78.79/96.73 (scarto -0.6/-1.6%, entro 1.5 px). Etichette 1.7x, 51.6x, 10.8x corrette (1.67, 51.64, 10.77). SD r2-5 ddof=1: 0.08, 7.66, 40.54 (CPU); 0.08, 1.08, 1.24 (GPU); convenzione ddof non risolvibile dai pixel. HD 2 um: 389,492 bin (n_spots_after_qc), non 400k",
    "MISMATCH", "major",
    "SPATIAL/results/spatial_*_results.json timings.total; " + W + "c07_fig7_8_spatial.py, c07b_fig7_pixels.py",
    "La giustificazione 'repeat 1 excluded for JIT warmup' e' falsa per HD 8 um CPU (r1 7x piu' veloce, vedi A0223). '400k' contro '389,492 bins' scritto nel pannello. Nessuno script del repo genera questa PNG (vedi finding riproducibilita'). Colori CPU/GPU diversi da Fig. 1-6.")

add("A0225", 342, SP + "GPU speedup scales dramatically with platform resolution",
    "co-occurrence analysis, which achieved a 3,272x speedup (from 3,573 s on CPU to 1.09 s on GPU; Fig. 8)",
    "co-occurrence 3,272x (3,573 s -> 1.09 s)",
    "Media r2-5: CPU 3573.20 s, GPU 1.0922 s, rapporto 3271.49 -> 3,271x; Fig. 8 riporta '3,271x'. Con il run CPU r1 (73.47 s, stesso output): 67x; r1 contro r1: 29.3x. CPU calcola 7 cluster (7x7x49), GPU 3 cluster (3x3x49)",
    "MISMATCH", "critical",
    "SPATIAL/results/spatial_{cpu,gpu}_visium_hd_square_008um_r*_results.json timings.co_occurrence e *_co_occurrence.npy (shape); " + W + "c07_fig7_8_spatial.py",
    "Refuso 3,272 contro 3,271 della figura (minore), ma il problema centrale e' critical: il valore e' nell'abstract e dipende da r2-r5 anomali e da un confronto su un numero di cluster diverso (lavoro O(k^2) 49 contro 9 coppie). Vedi finding dedicato.")

add("A0228", 346, SP + "GPU speedup scales dramatically with platform resolution",
    "Co-occurrence analysis achieves a 3,272x speedup (CPU: 3,573 s to GPU: 1.09 s), the single largest acceleration measured in this study.",
    "co-occurrence 3,272x; Moran/Geary 162-163x; spatial_neighbors e nhood_enrichment 1.0x",
    "Etichette della PNG contro media r2-5: co_occurrence 3,271 (3271.49), pca 257 (256.62), normalization 176 (176.29), geary 163 (162.52), moran 162 (162.27), umap 159 (158.84), hvg 76 (75.96), expression_neighbors 20 (19.72), leiden 16 (16.36), spatial_neighbors 1.0 (0.97), nhood_enrichment 1.0 (1.03): 11/11. La didascalia dice 3,272x, la figura 3,271x",
    "MISMATCH", "minor",
    "SPATIAL/results/spatial_*_visium_hd_square_008um_r{2..5}_results.json; " + W + "c07_fig7_8_spatial.py",
    "Didascalia e figura discordano di 1 sul valore simbolo. Il pannello omette data loading (1.00x) e QC (7.48x) senza dirlo; etichette in snake_case del codice (co_occurrence, spatial_autocorr_moran) incoerenti con testo e Table 9; verde/rosso poco distinguibili per daltonici. Validita' del 3,27x: vedi finding critical.")

add("A0249", 377, SP + "Spatial concordance: near-perfect for spatial statistics, divergent for clustering at high resolution",
    "Spatial autocorrelation concordance was near-perfect across all platforms (Table 10, Fig. 9).",
    "concordanza autocorrelazione quasi perfetta su tutte le piattaforme",
    "Spearman rho Moran: 1.0, 0.999877, 0.999982; Geary: 1.0, 0.999526, 0.999912 (identici nei 5 rep)",
    "PASS", "info",
    "SPATIAL/results/spatial_concordance_{visium,visium_hd_square_008um,visium_hd_square_002um}.json moranI.I_spearman_rho, gearyC.C_spearman_rho; " + W + "c09_fig9_concordance.py",
    "Corretto. Su asse 0-1 le differenze non sono leggibili (tutte le barre a 1.0), ma l'affermazione regge.")

add("A0250", 379, SP + "Spatial concordance: near-perfect for spatial statistics, divergent for clustering at high resolution",
    "Cluster concordance (ARI) degrades at HD 2 um resolution (0.080) due to algorithmic differences between cugraph and leidenalg Leiden implementations at high granularity.",
    "rho >= 0.9995; SVG top-50 = 1.0 ovunque; ARI HD 2 um 0.080 per differenze cugraph/leidenalg",
    "15 barre: Moran 1.0/0.9999/1.0, Geary 1.0/0.9995/0.9999, top-50 1.0 x3, FDR<0.05 1.0/0.9986/0.9815, ARI 0.8561/0.9737/0.0805 (medie r1-5; r2-5 0.9738, 0.0795): coincidono con Table 10 e con le etichette 0.856 e 0.080. Il CPU usa sc.tl.leiden flavor='igraph', n_iterations=2, non leidenalg",
    "MISMATCH", "minor",
    "SPATIAL/results/spatial_concordance_*.json; SPATIAL/scripts/benchmark_spatial_cpu.py righe 333-335; " + W + "c09_fig9_concordance.py",
    "Valori corretti. 'leidenalg' e' sbagliato (backend igraph, anche nel testo riga 399), e l'attribuzione a 'algorithmic differences' non e' testata: CPU con n_iterations=2 contro cuGraph con iterazioni di default e' anche una differenza di parametri. L'annotazione 'Algorithmic difference' nel pannello afferma una causa non verificata. Legenda sopra le barre Moran; testo annotazione a filo del bordo.")

# ---------------------------------------------------------------- finding nuovi
add(None, 346, SP + "GPU speedup scales dramatically with platform resolution",
    "Co-occurrence analysis achieves a 3,272x speedup (CPU: 3,573 s to GPU: 1.09 s), the single largest acceleration measured in this study.",
    "3,272x co-occurrence (abstract riga 14, Fig. 8, Table 9) come accelerazione GPU",
    "CPU co_occurrence per rep: 73.47, 3573.47, 3574.09, 3570.99, 3574.25 s; GPU: 2.51, 1.09, 1.09, 1.09, 1.09 s. Output CPU identico in tutti i rep (array 7x7x49 uguale a r1). n_clusters CPU 7 in tutti i rep, GPU 3 in tutti i rep: matrici co-occurrence 7x7x49 contro 3x3x49 (concordanza registrata come shape_mismatch)",
    "UNSUPPORTED", "critical",
    "SPATIAL/results/spatial_{cpu,gpu}_visium_hd_square_008um_r{1..5}_results.json timings.co_occurrence, results_summary.n_clusters; *_co_occurrence.npy; spatial_concordance_visium_hd_square_008um.json co_occurrence.status",
    "Due problemi indipendenti: (1) lo stesso calcolo CPU impiega 73 s nel primo run e 3,573 s nei successivi dello stesso processo: il 3,272x misura questa anomalia, non solo la GPU; (2) CPU e GPU calcolano co-occurrence su partizioni diverse (7 contro 3 cluster), quindi il carico non e' lo stesso. Senza spiegazione o rimisura il valore non puo' stare nell'abstract.")

add(None, 223, SC + "Per-step speedup varies over two orders of magnitude",
    "at 10k cells, CPU was faster (0.36x) due to cuGraph's higher constant-time overhead for graph partitioning operations on small graphs",
    "Fig. 1: celle estreme 329x (normalisation) e 0.36x (Leiden) come proprieta' delle operazioni",
    "Escludendo r1 (warmup): normalisation 115.1x/134.2x/137.4x (non 329/206/173, e il trend con la taglia si inverte); Leiden 0.5 a 10k 1.12x (non 0.36x): GPU r1 1.703 s contro 0.091-0.230 s in r2-r5. Leiden 1.0 e 1.5 a 10k sono gia' 1.36x e 1.60x. PCA 11.7x/44.7x/65.3x invece di 4.8/20.5/36.5",
    "MISMATCH", "major",
    "results/{cpu,gpu}_{10000,50000,100000}_r{1..5}_results.json timings; " + W + "c01_fig1_heatmap.py (colonna excl_r1)",
    "Le celle piu' vistose della heatmap sono dominate dal primo run (JIT/caricamento librerie) sia CPU sia GPU, mentre per lo spatial lo stesso effetto e' escluso (r2-5): convenzioni diverse tra Fig. 1-6 e Fig. 7-9 non dichiarate. Il CPU piu' lento a 10k e' un artefatto della prima chiamata cuGraph, non un overhead per chiamata. Il testo scrive anche '0.76-0.85x GPU/CPU' per un rapporto CPU/GPU.")

add(None, 229, SC + "Multi-GPU scaling is sublinear: CPU preprocessing dominates",
    "At 1.3M cells, 8 GPUs (435.2 s) were only 12% faster than 2 GPUs (493.3 s).",
    "8 GPU 12% piu' veloci di 2 GPU a 1.3M; solo PCA e neighbours beneficiano di piu' GPU (riga 232)",
    "Differenza 8-2 GPU a 1.3M per step: data_loading -58.38 s (149.0 +/- 20.8 contro 90.6 +/- 5.0), totale -58.12 s; PCA -0.19 s, neighbours -0.02 s. I job 2, 4 e 8 GPU girano in contemporanea (timestamp intercalati 22:23-23:03 del 15/3) e con allocazioni diverse: 32/56/200 core, 512/1024/1800 GB",
    "MISMATCH", "major",
    "results/gpu{2,4,8}_1300000_r*.json timings, metadata.timestamp; slurm/gpu_{2,4,8}.sh righe 13-15; " + W + "c04b_cpu_pre_vs_gpus.py",
    "Il 12% (e la pendenza della linea 1.3M in Fig. 3) viene tutto dalla lettura da disco, uno step che non usa GPU, verosimilmente per contesa di I/O o risorse host diverse. La fase distribuita non scala affatto (17.2 contro 17.0 s): la frase 'only the PCA and neighbour steps benefit from additional GPUs' e' contraddetta dai dati. L'asse 'Number of GPUs' confonde GPU, core e RAM allocati.")

add(None, 236, SC + "Multi-GPU scaling is sublinear: CPU preprocessing dominates",
    "**Figure 4.** Multi-GPU hybrid pipeline breakdown at 500k and 1.3M cells.",
    "barra 'CPU (100 cores)' colorata come 'CPU preprocessing'",
    "Lo script somma TUTTI gli step CPU nella fase 'CPU preprocessing' (generate_figures.py righe 553-557). Il vero preprocessing CPU (load+QC+norm+HVG) e' 81.2 s su 4,346.7 s (1.9%) a 500k e 324.7 s su 52,056.2 s (0.6%) a 1.3M; DE testing 3,678.9 s e 48,688.3 s, UMAP 473.4 s e 2,670.2 s",
    "MISMATCH", "major",
    "scripts/generate_figures.py fig_multigpu_breakdown; results/cpu_{500000,1300000}_r*.json timings; " + W + "c04_fig4_multigpu.py",
    "La figura dice al lettore che il preprocessing CPU richiede 14.5 h a 1.3M, mentre e' il 0.6% del tempo CPU (domina DE). Insieme alla didascalia 'CPU preprocessing (blue) dominates wall time' induce una lettura sbagliata. Colorare la barra CPU per step o etichettarla 'CPU pipeline (all steps)'.")

add(None, 88, "Data and Methods > Single-cell RNA-seq > Multi-GPU pipeline",
    "In this hybrid pipeline, data loading, QC, normalisation, HVG selection and scaling executed on the host CPU.",
    "nel pipeline ibrido lo scaling gira su CPU (modifica del 2 settembre)",
    "scripts/benchmark_multigpu.py righe 333-340: rsc.get.anndata_to_GPU poi rsc.pp.scale (GPU); metadata.configuration dei JSON gpu{2,4,8}: cpu_steps = [data_loading, qc_filtering, normalization, hvg_selection], single_gpu_steps = [gpu_transfer, scale, ...]. Fig. 4 legenda 'GPU transfer + scale'; riga 90 'Scaling ... executed on a single GPU'; riga 231 conta scale tra le operazioni single-GPU",
    "MISMATCH", "major",
    "scripts/benchmark_multigpu.py; results/gpu8_1300000_r1_results.json metadata.configuration",
    "La frase aggiunta il 2 settembre contraddice codice, JSON, Fig. 4, riga 90 e riga 231. Togliere 'and scaling' dall'elenco CPU (nel solo stress test maxpower lo scaling e' su CPU).")

add(None, 240, SC + "CPU and GPU produce biologically concordant results",
    "though some variation in the k-nearest neighbours across the graph was expected due to floating-point precision differences",
    "kNN Jaccard 0.930 < 1 per differenze di precisione floating point (Fig. 5 destra)",
    "knn_concordance: max_jaccard 0.9375 = 15/16, median 0.9375, fraction_perfect 0.0 su 10,000 cellule. Con due insiemi di 15 vicini il Jaccard puo' valere solo 1, 14/16 = 0.875, ...: 0.9375 richiede insiemi di dimensione diversa (15 contro 16). Nessuna cellula puo' arrivare a 1; la media 0.9304 e' il 99.2% del tetto e la mediana coincide col tetto",
    "UNSUPPORTED", "major",
    "results/concordance_10000_r1.json knn_concordance; scripts/compare_results.py compare_knn; scripts/benchmark_{cpu,gpu}.py righe 404-411/488-494 (indici da obsp['distances'])",
    "La barra 0.930 di Fig. 5 misura soprattutto una differenza di conteggio dei vicini tra Scanpy e rapids (probabile inclusione del self o k contro k-1), non rumore numerico: piu' di meta' delle cellule ha vicini identici. I file *_knn.npz non sono nel repo, quindi la causa esatta non e' verificabile; il tetto si'. Normalizzare per dimensione o escludere il self.")

add(None, 252, SC + "Memory is not a bottleneck at benchmark scale",
    "First, the aggregate peak VRAM at 1.3M cells with 8 GPUs (134.2 GB) exceeds the 80 GB capacity of any single H100 device;",
    "VRAM aggregata 134.2 GB > 80 GB prova la distribuzione; tracce per device nei JSON",
    "Fig. 6 destra: a 10k cellule 8 GPU l'aggregato e' gia' 106.5 GB (> 80 GB) con un working set minimo: e' la riserva dei pool RMM (10 GB iniziali x 8 worker) piu' i contesti CUDA. Traccia gpu8_10000_r1: 4.99 GB prima di PCA, 83.96 GB dopo. Nei JSON multi-GPU esiste solo la somma (memory.detailed.*_vram_*_gb e peak_vram_gb), nessun campo per device",
    "UNSUPPORTED", "major",
    "scripts/benchmark_multigpu.py get_total_vram_used_gb; results/gpu8_{10000,1300000}_r1_results.json memory.detailed; ricerca chiavi in tutti i gpu{2,4,8}_*.json (" + W + "c05_fig6_memory.py e c12_misc_checks.py (b))",
    "La prova 'non poteva stare su una GPU' confonde memoria riservata e memoria usata; la stessa figura la smentisce a 10k. 'Per-device VRAM traces (available in the benchmark result JSON files)' e' falso: i JSON salvano solo la somma. Fuori dalla fetta C stretta ma legato al pannello destro di Fig. 6.")

add(None, 254, SC + "Memory is not a bottleneck at benchmark scale",
    "**Figure 6.** Peak memory usage across dataset sizes.",
    "punti di Fig. 6 come valore unico per configurazione",
    "peak_vram_gb per rep (8 GPU): 10k 84.09, 123.03, 103.56, 113.29, 108.43; 1.3M 93.71, 135.31, 144.23, 150.92, 146.71 GB. r1 sempre il minimo: tutte le ripetizioni girano nello stesso processo (--n-repeats) e la memoria residua si accumula. La figura mostra solo medie, senza barre",
    "MISMATCH", "minor",
    "results/gpu{2,4,8}_{N}_r*.json memory.peak_vram_gb; slurm/gpu_8.sh (un solo processo per taglia); " + W + "c05_fig6_memory.py",
    "Variabilita' fino a +/-20% e deriva tra ripetizioni nascoste. Il 134.2 GB del testo e' una media che include memoria residua delle ripetizioni precedenti (r1 = 93.7 GB). Aggiungere barre o riportare r1. Nel pannello sinistro la linea 2x GPU e' coperta dalla 4x (60.7 GB entrambe a 1.3M).")

add(None, 368, SP + "GPU speedup scales dramatically with platform resolution",
    "Without this step, UMAP dominated the GPU pipeline time (92x speedup, but consuming 92% of the 97 s total GPU time).",
    "UMAP = 92% dei 97 s GPU su HD 2 um",
    "HD 2 um media r2-5: UMAP GPU 8.96 s su 96.73 s = 9.3%; spatial_neighbors 54.91 s = 56.8%. UMAP CPU 825.3 s su 1042.0 s = 79.2%. Speedup UMAP 92.1x corretto",
    "MISMATCH", "major",
    "SPATIAL/results/spatial_{cpu,gpu}_visium_hd_square_002um_r{2..5}_results.json timings; " + W + "c12_misc_checks.py (c)",
    "Contraddice anche la riga 373 (spatial neighbours 57-73% del tempo GPU). Probabile confusione tra quota GPU e quota CPU. Fuori fetta C, segnalato perche' commenta il pannello HD 2 um di Fig. 7.")

add(None, 219, SC + "Per-step speedup varies over two orders of magnitude",
    "**Figure 1.** Per-step speedup of single-GPU rapids-singlecell (1xH100 80 GB) relative to CPU Scanpy (100 cores) at 10k, 50k, and 100k cells.",
    "heatmap leggibile tramite colore",
    "TwoSlopeNorm(vmin=0.3648, vcenter=1, vmax=329.3) su RdYlBu: valori da 1.36x a 50x cadono in posizioni 0.501-0.575 della colormap, luminanza 240-248 (25 celle su 33 quasi identiche). Colorbar con tick solo 50-300 nella meta' alta; nessun tick a 1 ne' sotto. In scala di grigi 0.36x (Y=54) e 329x (Y=63) sono lo stesso grigio scuro",
    "MISMATCH", "minor",
    "scripts/generate_figures.py fig_speedup_heatmap righe 178-205; " + W + "c11_lncs_print.py",
    "Il colore non comunica nulla salvo i due estremi, che in stampa B/N hanno significato opposto e tono uguale. Usare scala log con centro a 1 e tick espliciti (0.5, 1, 10, 100). La riga 'PCA' include sc.pp.scale (benchmark_cpu.py riga 215, benchmark_gpu.py riga 288) e Table 1 elenca Scaling come step 5 che in Fig. 1-2 non compare: dichiararlo.")

add(None, 246, SC + "CPU and GPU produce biologically concordant results",
    "**Figure 5.** Concordance between CPU and GPU pipelines on 10,000 cells.",
    "pannelli di Fig. 5",
    "Assi y troncati a 0.85 (sinistra 0.85-1.02, destra 0.85-1.05: scale diverse); con base 0.85 la barra ARI 0.908 appare meta' della 0.963 per una differenza del 6%. Legenda sopra le barre res=0.5 (verificato su bbox: ARI 0.932, NMI 0.951). Pannello destro senza etichetta y. DE logFC rho (0.946, sesta metrica di Table 2) assente. In grigio PCA (Y=179) e kNN (Y=177) indistinguibili",
    "MISMATCH", "minor",
    "scripts/generate_figures.py fig_concordance; " + W + "c03b_legend_overlap.py, c11_lncs_print.py",
    "Difetti di presentazione: barre con base non nulla ingigantiscono differenze piccole, la sesta metrica dichiarata in Methods manca. Usare punti (dot plot) su asse 0.8-1 o aggiungere DE rho.")

add(None, 219, "Figure (tutte) > idoneita' LNCS",
    "**Figure 1.** Per-step speedup of single-GPU rapids-singlecell (1xH100 80 GB) relative to CPU Scanpy (100 cores) at 10k, 50k, and 100k cells.",
    "figure pronte per la stampa LNCS (GENERATION_SUMMARY: 'Publication-ready')",
    "Corpo minimo stimato a 0.85\\textwidth (10.37 cm, come nel .tex del repo) / a 12.2 cm: Fig.1 6.6/7.7 pt; Fig.2 (fig5) 2.5/2.9; Fig.3 (fig2) 4.8/5.7; Fig.4 (fig6) 2.7/3.2; Fig.5 (fig3) 3.6/4.2; Fig.6 (fig4) 3.6/4.2; Fig.7 ~5.6/6.6; Fig.8 ~3.5/4.2; Fig.9 ~3.5/4.1 pt. Springer: lettering non sotto 6 pt",
    "MISMATCH", "major",
    "PNG in /tmp/repo/figures (dimensioni px), corpi nominali da generate_figures.py, corpi misurati per fig7-9 (" + W + "c10_text_height.py); llncs.cls riga 55 (\\textwidth 12.2cm); manuscript/lncs_latex/full_paper_LNBI.tex (width=0.85\\textwidth); Springer Instructions for Authors of Proceedings (CS), letto via https://conferences.ncl.ac.uk/media/sites/conferencewebsites/ideas2025/Springer_Instructions_for_Authors_of_Proceedings_CS-2.pdf",
    "7 figure su 9 scendono sotto 6 pt anche a piena larghezza; Fig. 2 e Fig. 4 (larghe 11.4 e 10.4 pollici native con un pannello legenda vuoto) arrivano a 2.5-3 pt. Ridisegnare a 12.2 cm di larghezza finale (figsize 4.8 in) con font 7-9 pt.")

add(None, 219, "Figure (tutte) > idoneita' LNCS",
    "**Figure 1.** Per-step speedup of single-GPU rapids-singlecell (1xH100 80 GB) relative to CPU Scanpy (100 cores) at 10k, 50k, and 100k cells.",
    "PNG 300 dpi adeguate",
    "dpi effettivi a 12.2 cm / a 10.37 cm: Fig.1 291/343; Fig.2 714/840; Fig.3 370/435; Fig.4 650/765; Fig.5 495/583; Fig.6 495/583; Fig.7 370/436; Fig.8 496/583; Fig.9 432/508. Sono tutti grafici (line art). Soglie: brief 600 dpi line art; Springer Proceedings CS: 'Line drawings ... at least 800 dpi (preferably 1200 dpi)', vettoriale preferito",
    "MISMATCH", "major",
    "Image.size delle PNG; " + W + "c11_lncs_print.py; Springer Instructions for Authors of Proceedings (CS) (URL sopra)",
    "Nessuna figura raggiunge 800 dpi a larghezza di stampa; Fig. 1 a 12.2 cm e' sotto anche i 300 dpi (291). Le due che superano 600 dpi lo fanno solo perche' sono troppo larghe (font illeggibili). Esportare in PDF vettoriale (matplotlib savefig .pdf) per fig1-6 e rigenerare fig7-9.")

add(None, 219, "Figure (tutte) > idoneita' LNCS",
    "**Figure 1.** Per-step speedup of single-GPU rapids-singlecell (1xH100 80 GB) relative to CPU Scanpy (100 cores) at 10k, 50k, and 100k cells.",
    "figure leggibili in scala di grigi (volumi stampati Springer in B/N)",
    "Coppie con luminanza quasi uguale: Fig.1 estremi 0.36x/329x Y 54/63; Fig.2 Set3 9 coppie di step con dY<10 (Leiden 0.5/UMAP 1, load/norm 2, HVG/PCA 3); Fig.3 baseline CPU alpha 0.3; Fig.4 CPU prep/single-GPU dY=14; Fig.5 PCA/kNN dY=2; Fig.6 2x/8x GPU dY=2 con stesso marker; Fig.8 GPU-accelerated/CPU-only dY=7; Fig.9 Visium v1/HD 8 um dY=12",
    "MISMATCH", "major",
    "palette da generate_figures.py e colori campionati dalle PNG fig7-9; " + W + "c11_lncs_print.py; montaggio in grigio " + W + "repro_scrna/montage_rest.png e sbs_*.png; Springer Proceedings CS: 'In the printed volumes, illustrations are generally black and white'",
    "In stampa B/N Fig. 2 (11 step pastello), Fig. 6 destra (2x e 8x GPU) e Fig. 1 (estremi) perdono l'informazione. Aggiungere marker/tratteggi/pattern o etichette dirette.")

add(None, 221, "Figure (tutte) > nomi file",
    "![**Figure 2.** Step-level wall time decomposition for CPU vs single-GPU at 10k, 50k, and 100k cells.",
    "file figura con nomi coerenti col manoscritto",
    "Figure 2 = fig5_timing_breakdown.png; Figure 3 = fig2_scaling_plot.png; Figure 4 = fig6_multigpu_breakdown.png; Figure 5 = fig3_concordance.png; Figure 6 = fig4_memory_profile.png. Coerenti solo Figure 1, 7, 8, 9",
    "MISMATCH", "minor",
    "full_paper_LNBI.md righe 219-379 (percorsi ../figures/); manuscript/lncs_latex/full_paper_LNBI.tex includegraphics",
    "Cinque file su nove hanno un numero diverso dalla figura che rappresentano: alto rischio di scambio in fase di upload/produzione. Rinominare fig01...fig09 secondo l'ordine del testo (requisito METEOR come da brief, non verificato su fonte).")

add(None, 340, "Figure (tutte) > coerenza tra figure",
    "**Figure 7.** Total pipeline wall time (CPU vs GPU) for three Visium spatial platforms on a single RTX 4090.",
    "stessi colori e nomi per le stesse configurazioni",
    "CPU = #4477AA in Fig. 4 e 6, #1f77b4 in Fig. 7; #EE6677 = 1x GPU (Fig. 6), fase multi-GPU (Fig. 4), NMI (Fig. 5); #228833 = 2x GPU (Fig. 6), fase single-GPU (Fig. 4), HVG Jaccard (Fig. 5); blu/arancio = CPU/GPU in Fig. 7 ma Visium v1/HD 2 um in Fig. 9. Step: 'Normalization', 'Neighbors', 'Leiden 0.5' (Fig. 1-2), 'leiden' minuscolo (Fig. 4), snake_case 'expression_neighbors', 'co_occurrence', 'spatial_autocorr_moran' (Fig. 8) contro 'normalisation', 'neighbours', 'co-occurrence', 'Moran's I' nel testo e Table 9. Unita': 'seconds' (Fig. 2-4) contro 's' (Fig. 7); tick '1000k' in Fig. 6",
    "MISMATCH", "minor",
    "palette in scripts/generate_figures.py COLORS e fig_multigpu_breakdown/fig_concordance; colori campionati dalle PNG fig7-9 (" + W + "c11_lncs_print.py)",
    "Unificare palette (CPU sempre lo stesso colore, 1/2/4/8 GPU sempre gli stessi), nomi degli step in inglese britannico come nel testo, unita' uniformi.")

add(None, 340, "Figure (tutte) > riproducibilita'",
    "**Figure 7.** Total pipeline wall time (CPU vs GPU) for three Visium spatial platforms on a single RTX 4090.",
    "figure generate da codice nel repo ('All code ... available')",
    "scripts/generate_figures.py sui results/ del commit a4b9b9e si interrompe: KeyError 'metadata' (de_benchmark_results.json) e poi KeyError 1700000 (maxpower_*_results.json). Ristretto ai 116 JSON del benchmark principale rigenera fig1-6 con contenuto identico (dimensioni +/-1-6 px, summary_table.csv identica). figures/generate_spatial_figures.py NON produce le fig7-9 pubblicate: valori scritti a mano, nessuna barra di errore, font serif, etichette 'moran_i', '3272x', legenda in basso a destra, soglia 0.95, riquadro rosso; dimensioni 2959x1761, 3260x2060, 3560x1760 contro 1779x1024, 2381x1175, 2073x1028. Nessun altro script del repo genera fig7-9",
    "UNSUPPORTED", "major",
    W + "repro_scrna/ (esecuzioni e sbs_*.png), " + W + "repro_spatial/ (output dello script spatial e montage_script_output.png); git log -- figures/",
    "Fig. 7-9 (e le barre di errore di Fig. 7) non sono riproducibili dal repository: lo script committato nello stesso commit (334c93e) disegna un'altra figura. GENERATION_SUMMARY.md e SPATIAL_FIGURES_README.txt descrivono quello script, non le PNG. Lo script scRNA va corretto (filtro sui file cpu_/gpu*_).")

add(None, 166, "Data and Methods > Hardware and software environment",
    "For spatial benchmarks, the first repeat served as a JIT/warmup run and was excluded; we report the mean of repeats 2-5.",
    "r1 = warmup per tutti i benchmark spatial; scRNA media su 5 rep",
    "Spatial r1/media r2-5 del totale: Visium v1 CPU 39.70/10.03, GPU 24.54/5.99 (warmup reale); HD 8 um CPU 584.60/4068.40 (r1 7x piu' VELOCE), GPU 91.42/78.79; HD 2 um CPU 1010.14/1041.99 (r1 piu' veloce), GPU 109.12/96.73. scRNA: r1 incluso pur essendo warmup (es. CPU 10k 57.70 contro 34.5-35.2 s)",
    "MISMATCH", "major",
    "SPATIAL/results/spatial_*_r{1..5}_results.json e results/{cpu,gpu}_*_r{1..5}_results.json timings.total; " + W + "c07_fig7_8_spatial.py, c12_misc_checks.py (a)",
    "La regola di esclusione e' applicata alle cieca: per due configurazioni CPU spatial r1 non e' un warmup; per lo scRNA il warmup c'e' ma non viene escluso. Le Fig. 1-6 e 7-9 usano quindi convenzioni opposte senza dichiararlo nelle didascalie.")

# ---------------------------------------------------------------- controlli
for f in F:
    for k, v in f.items():
        if isinstance(v, str):
            assert "–" not in v and "—" not in v, (k, v[:60])
out = os.path.join(REV, "tracks", "C_findings.json")
json.dump(F, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
from collections import Counter
print(len(F), "voci;", Counter(f["status"] for f in F), Counter(f["severity"] for f in F))
inv = json.load(open(os.path.join(REV, "tracks", "inv_C.json")))
missing = {r["id"] for r in inv} - {f["inv_id"] for f in F}
print("righe inventario senza esito:", missing)
