"""Loader comune per il track C: legge i JSON scRNA in /tmp/repo/results (sola lettura)."""
import json
import glob
import os
import statistics as st

RES = "/tmp/repo/results"
SP = "/tmp/repo/SPATIAL/results"
SIZES = [10000, 50000, 100000, 500000, 1300000]


def load(prefix):
    """prefix: 'cpu', 'gpu', 'gpu2', 'gpu4', 'gpu8'. Ritorna {n_cells: [json r1..r5]}"""
    out = {}
    for n in SIZES:
        runs = []
        for k in range(1, 6):
            f = os.path.join(RES, f"{prefix}_{n}_r{k}_results.json")
            if os.path.exists(f):
                runs.append(json.load(open(f)))
        if runs:
            out[n] = runs
    return out


def mean(xs):
    return sum(xs) / len(xs)


def sd(xs):
    return st.stdev(xs) if len(xs) > 1 else 0.0


def psd(xs):
    return st.pstdev(xs)


def load_spatial(kind, platform):
    runs = {}
    for k in range(1, 6):
        f = os.path.join(SP, f"spatial_{kind}_{platform}_r{k}_results.json")
        if os.path.exists(f):
            runs[k] = json.load(open(f))
    return runs
