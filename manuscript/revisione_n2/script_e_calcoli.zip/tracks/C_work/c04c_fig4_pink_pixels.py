"""Conta i pixel dei colori di fase nella PNG di Fig. 4 (fig6_multigpu_breakdown.png), separando l'area
legenda (x > 2450 px) dai pannelli: la fase multi-GPU (rosa #EE6677) e' visibile nei pannelli?"""
from PIL import Image
import numpy as np
im = np.asarray(Image.open('/tmp/repo/figures/fig6_multigpu_breakdown.png').convert('RGB')).astype(int)
cols = {'CPU preprocessing #4477AA': (0x44, 0x77, 0xAA), 'GPU transfer+scale #BBBBBB': (0xBB, 0xBB, 0xBB),
        'Multi-GPU #EE6677': (0xEE, 0x66, 0x77), 'Single-GPU #228833': (0x22, 0x88, 0x33)}
for k, c in cols.items():
    m = np.abs(im - np.array(c)).sum(axis=2) < 30
    pan = m[:, :2450]; leg = m[:, 2450:]
    ys, xs = np.where(pan)
    print(f"{k:28s} pixel nei pannelli {pan.sum():7d}  in legenda {leg.sum():5d}"
          + (f"  altezza max colonna nei pannelli {max(pan[:, x].sum() for x in set(xs.tolist()))} px" if pan.sum() else ""))
print("altezza PNG", im.shape[0], "px; a 0.85 textwidth la figura e' alta", round(10.37 * im.shape[0] / im.shape[1], 2), "cm")
