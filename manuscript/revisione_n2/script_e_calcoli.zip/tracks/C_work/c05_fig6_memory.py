"""Manoscritto Figure 6 = fig4_memory_profile.png. Ricalcola i punti (media su 5 rep di peak_ram_gb e
peak_vram_gb), verifica se la VRAM e' per-device o aggregata (codice benchmark_multigpu.py: somma NVML
su n_gpus device) e la forma della crescita della RAM CPU (lineare / super-lineare)."""
import sys, os, math
sys.path.insert(0, os.path.dirname(__file__))
from c00_load import load, mean, SIZES

cfg = {"cpu": 0, "gpu": 1, "gpu2": 2, "gpu4": 4, "gpu8": 8}
for p, g in cfg.items():
    d = load(p)
    ram = {n: round(mean([r["memory"]["peak_ram_gb"] for r in d[n]]), 1) for n in d}
    vram = {n: round(mean([r["memory"]["peak_vram_gb"] for r in d[n]]), 1) for n in d}
    print(f"{p:5s} RAM {ram}")
    if g:
        print(f"      VRAM {vram}" + (f"  -> per device se diviso per {g}: " + str({n: round(v / g, 1) for n, v in vram.items()}) if g > 1 else ""))
# crescita RAM CPU: pendenza log-log tra taglie consecutive e complessiva
cpu = load("cpu")
r = {n: mean([x["memory"]["peak_ram_gb"] for x in cpu[n]]) for n in SIZES}
for a, b in zip(SIZES[:-1], SIZES[1:]):
    print(f"CPU RAM {a}->{b}: pendenza log-log = {math.log(r[b] / r[a]) / math.log(b / a):.2f}")
print(f"CPU RAM 10k->1.3M complessiva: {math.log(r[1300000] / r[10000]) / math.log(130):.2f}; "
      f"RAM/cell (KB): " + str({n: round(r[n] * 1024 ** 2 / n, 1) for n in SIZES}))
print("quota del 2 TB:", round(100 * r[1300000] / 2048, 2), "%; di 2000 GB:", round(100 * r[1300000] / 2000, 2), "%")
# traccia VRAM aggregata 8 GPU: a 10k cells la somma supera gia' 80 GB?
for n in [10000, 1300000]:
    d = load("gpu8")[n][0]["memory"]["detailed"]
    tr = [(k.replace("_vram_after_gb", ""), v) for k, v in d.items() if k.endswith("_vram_after_gb")]
    print(f"gpu8 {n} r1 VRAM aggregata dopo ogni step:", tr)
# 1 GPU: VRAM costante ~ pool RMM 50% di 79.6 GB
print("RMM initial pool 1 GPU = 50% di 79.6 =", 0.5 * 79.6)
