"""Manoscritto Figure 2 = fig5_timing_breakdown.png. Ricalcola le barre impilate (media su 5 rep per step)
le etichette dei totali e la quota di ciascuno step, per verificare la didascalia
'On CPU, DE testing and neighbour graph construction dominate'."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from c00_load import load, mean, sd

STEPS = ["data_loading", "qc_filtering", "normalization", "hvg_selection", "pca", "neighbors",
         "leiden_0.5", "leiden_1.0", "leiden_1.5", "umap", "de_testing"]
FIG_LABELS = {("cpu", 10000): "39s", ("gpu", 10000): "3s", ("cpu", 50000): "282s", ("gpu", 50000): "8s",
              ("cpu", 100000): "647s", ("gpu", 100000): "15s"}
for pref in ["cpu", "gpu"]:
    d = load(pref)
    for n in [10000, 50000, 100000]:
        means = {s: mean([r["timings"][s] for r in d[n]]) for s in STEPS}
        stack = sum(means.values())
        tot = mean([r["timings"]["total"] for r in d[n]])
        rank = sorted(means.items(), key=lambda kv: -kv[1])
        lab = f"{stack:.0f}s"
        print(f"{pref} {n}: stack={stack:.2f} total_mean={tot:.2f} sd_total={sd([r['timings']['total'] for r in d[n]]):.2f} "
              f"label={lab} fig={FIG_LABELS[(pref, n)]} match={lab == FIG_LABELS[(pref, n)]}")
        print("   top3:", [(k, round(v, 2), f"{100 * v / stack:.1f}%") for k, v in rank[:3]])
        if pref == "cpu":
            print("   neighbors share:", f"{100 * means['neighbors'] / stack:.1f}%", "rank:",
                  [k for k, _ in rank].index("neighbors") + 1)
        # step piu' lungo su GPU in secondi
        if pref == "gpu":
            print("   max step GPU:", rank[0])
