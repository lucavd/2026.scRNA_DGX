"""Idoneita' LNCS: larghezza testo 12.2 cm (llncs.cls riga 55); il .tex in repo include le figure a
0.85\\textwidth = 10.37 cm. Calcola dpi effettivi e corpo minimo dei font. Per fig1-6 i corpi nominali
vengono dallo script (generate_figures.py: rcParams + fontsize espliciti); per fig7-9 dalla misura delle
maiuscole (c10_text_height.py). Poi luminanza (scala di grigi, ITU-R BT.601 come PIL 'L') dei colori
categoriali di ogni figura e minima differenza tra coppie."""
from PIL import Image
import itertools

TW_IN = 12.2 / 2.54; TW85_IN = 0.85 * TW_IN
FIGS = {  # file: (corpo minimo nominale pt, descrizione dell'elemento piu' piccolo)
    'fig1_speedup_heatmap.png': (7.5, 'annotazioni celle 7.5 pt, tick 8 pt'),
    'fig5_timing_breakdown.png': (7.0, 'legenda 7 pt, totali 7 pt, tick 8 pt'),
    'fig2_scaling_plot.png': (7.0, 'legenda 7 pt, tick 8 pt'),
    'fig6_multigpu_breakdown.png': (7.0, 'legenda 7 pt, totali 7 pt, tick 7.5 pt'),
    'fig3_concordance.png': (7.0, 'etichette barre 7 pt, tick 8 pt'),
    'fig4_memory_profile.png': (7.0, 'legenda 7 pt, testo limite VRAM 7 pt'),
    'fig7_spatial_speedup.png': (8.2, 'tick e legenda ~8.2 pt (misurati)'),
    'fig8_spatial_perstep.png': (6.9, 'legenda ~6.9 pt, etichette valori ~8 pt (misurati)'),
    'fig9_spatial_concordance.png': (5.9, 'annotazione 0.856 ~5.9 pt, legenda ~6.6 pt (misurati)'),
}
MS = {'fig1_speedup_heatmap.png': 'Figure 1', 'fig5_timing_breakdown.png': 'Figure 2', 'fig2_scaling_plot.png': 'Figure 3',
      'fig6_multigpu_breakdown.png': 'Figure 4', 'fig3_concordance.png': 'Figure 5', 'fig4_memory_profile.png': 'Figure 6',
      'fig7_spatial_speedup.png': 'Figure 7', 'fig8_spatial_perstep.png': 'Figure 8', 'fig9_spatial_concordance.png': 'Figure 9'}
print(f"{'file':30s} {'ms':9s} {'px':>11s} {'dpi@12.2':>8s} {'dpi@10.37':>9s} {'h@10.37cm':>9s} {'pt_min@12.2':>11s} {'pt_min@10.37':>12s}  nome coerente?")
for f, (pt, desc) in FIGS.items():
    im = Image.open('/tmp/repo/figures/' + f)
    w, h = im.size; nat_in = w / 300
    d1 = w / TW_IN; d2 = w / TW85_IN
    print(f"{f:30s} {MS[f]:9s} {w:5d}x{h:<5d} {d1:8.0f} {d2:9.0f} {10.37*h/w:9.2f} {pt*TW_IN/nat_in:11.1f} {pt*TW85_IN/nat_in:12.1f}  "
          f"{'SI' if f.startswith('fig' + MS[f].split()[1] + '_') else 'NO'}  ({desc})")

def Y(hexc):
    r, g, b = int(hexc[1:3], 16), int(hexc[3:5], 16), int(hexc[5:7], 16)
    return round(0.299 * r + 0.587 * g + 0.114 * b)

PAL = {
    'Fig.6 memoria (COLORS)': {'CPU': '#4477AA', '1xGPU': '#EE6677', '2xGPU': '#228833', '4xGPU': '#CCBB44', '8xGPU': '#AA3377'},
    'Fig.4 fasi': {'CPU prep': '#4477AA', 'transfer+scale': '#BBBBBB', 'multi-GPU': '#EE6677', 'single-GPU': '#228833'},
    'Fig.5 concordanza': {'ARI': '#4477AA', 'NMI': '#EE6677', 'HVG': '#228833', 'PCA': '#CCBB44', 'kNN': '#66CCEE'},
    'Fig.7 spatial': {'CPU': '#1f77b4', 'GPU': '#ff7f0e'},
    'Fig.8 per-step': {'GPU-acc': '#2ecc71', 'extreme': '#e74c3c', 'CPU-only': '#999999'},
    'Fig.9 piattaforme': {'Visium v1': '#1f77b4', 'HD 8': '#2ca02c', 'HD 2': '#ff7f0e'},
}
print()
for k, p in PAL.items():
    ys = {n: Y(c) for n, c in p.items()}
    pairs = sorted(((abs(ys[a] - ys[b]), a, b) for a, b in itertools.combinations(ys, 2)))
    print(f"{k:24s} luminanza {ys}  coppia piu' simile: {pairs[0]}")
# Fig.2 (fig5_timing) palette Set3 a 11 colori
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, numpy as np
cols = plt.cm.Set3(np.linspace(0, 1, 11))
steps = ["load", "QC", "norm", "HVG", "PCA", "neigh", "L0.5", "L1.0", "L1.5", "UMAP", "DE"]
ys = {s: round(0.299 * 255 * c[0] + 0.587 * 255 * c[1] + 0.114 * 255 * c[2]) for s, c in zip(steps, cols)}
pairs = sorted(((abs(ys[a] - ys[b]), a, b) for a, b in itertools.combinations(ys, 2)))
print("Fig.2 Set3 luminanza", ys, "coppie con diff<10:", [p for p in pairs if p[0] < 10])
# Fig.3 viridis 0.15-0.85 a 5 livelli
cm = plt.cm.viridis(np.linspace(0.15, 0.85, 5))
print("Fig.3 viridis luminanza", [round(0.299 * 255 * c[0] + 0.587 * 255 * c[1] + 0.114 * 255 * c[2]) for c in cm],
      "baseline CPU: alpha 0.3, linewidth 0.7 pt")
# Fig.1 RdYlBu agli estremi (0.36x e 329x) con TwoSlopeNorm
cm = plt.cm.RdYlBu
print("Fig.1 RdYlBu luminanza estremo rosso (0.36x)", round(0.299 * 255 * cm(0.0)[0] + 0.587 * 255 * cm(0.0)[1] + 0.114 * 255 * cm(0.0)[2]),
      "estremo blu (329x)", round(0.299 * 255 * cm(1.0)[0] + 0.587 * 255 * cm(1.0)[1] + 0.114 * 255 * cm(1.0)[2]))
from matplotlib.colors import TwoSlopeNorm
n = TwoSlopeNorm(vmin=0.3648, vcenter=1.0, vmax=329.29)
for v in [0.36, 0.85, 1.36, 4.79, 8.78, 23.6, 50, 88.1]:
    c = cm(n(v)); print(f"   valore {v:6.2f} -> posizione colormap {float(n(v)):.3f} luminanza {round(0.299*255*c[0]+0.587*255*c[1]+0.114*255*c[2])}")
