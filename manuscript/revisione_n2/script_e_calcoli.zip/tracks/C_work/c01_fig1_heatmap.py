"""Fig. 1 (fig1_speedup_heatmap.png): ricalcola le 33 annotazioni della heatmap.
Convenzione dello script del repo: rapporto delle medie (mean CPU su 5 rep / mean GPU su 5 rep).
Confronta anche con mediana dei rapporti e con esclusione di r1."""
import sys
sys.path.insert(0, __import__('os').path.dirname(__file__))
from c00_load import load, mean
import statistics as st

STEPS = ["data_loading", "qc_filtering", "normalization", "hvg_selection", "pca", "neighbors",
         "leiden_0.5", "leiden_1.0", "leiden_1.5", "umap", "de_testing"]
# Valori letti dalla PNG (righe=step, colonne=10k,50k,100k)
FIG = {
    "data_loading": [0.85, 0.80, 0.76], "qc_filtering": [8.78, 27.2, 33.4],
    "normalization": [329.3, 206.1, 173.1], "hvg_selection": [23.6, 70.2, 94.2],
    "pca": [4.79, 20.5, 36.5], "neighbors": [88.1, 60.5, 44.3],
    "leiden_0.5": [0.36, 1.80, 3.58], "leiden_1.0": [1.36, 5.46, 8.83],
    "leiden_1.5": [1.60, 5.55, 8.40], "umap": [28.9, 26.9, 45.3], "de_testing": [15.6, 66.9, 87.5],
}
cpu, gpu = load("cpu"), load("gpu")
sizes = [10000, 50000, 100000]
ok = 0; bad = []
print(f"{'step':14s} {'size':>7s} {'ratio_of_means':>14s} {'label':>8s} {'fig':>8s} {'match':>5s} {'excl_r1':>8s} {'med_ratio':>9s}")
for s in STEPS:
    for j, n in enumerate(sizes):
        c = [r["timings"][s] for r in cpu[n]]; g = [r["timings"][s] for r in gpu[n]]
        v = mean(c) / mean(g)
        lab = round(v, 1) if v >= 10 else round(v, 2)
        v2 = mean(c[1:]) / mean(g[1:])
        med = st.median([a / b for a, b in zip(c, g)])
        m = abs(lab - FIG[s][j]) < 1e-9
        ok += m
        if not m:
            bad.append((s, n, v, FIG[s][j]))
        print(f"{s:14s} {n:7d} {v:14.4f} {lab:8} {FIG[s][j]:8} {str(m):>5s} {v2:8.2f} {med:9.2f}")
print("match", ok, "/", len(STEPS) * 3, "mismatch:", bad)
# n per cella
print("n rep CPU", {n: len(cpu[n]) for n in sizes}, "GPU", {n: len(gpu[n]) for n in sizes})
# il testo dice data loading 0.76-0.85x e Leiden 0.36x/1.80x/3.58x
# scaling e' assente dalle chiavi timings?
print("chiavi timings CPU 10k r1:", list(cpu[10000][0]["timings"].keys()))
print("chiavi timings GPU 10k r1:", list(gpu[10000][0]["timings"].keys()))
# range per step citati nel testo
for s in ["hvg_selection", "neighbors", "umap", "de_testing", "pca", "normalization", "qc_filtering"]:
    vals = [mean([r['timings'][s] for r in cpu[n]]) / mean([r['timings'][s] for r in gpu[n]]) for n in sizes]
    print(s, [round(x, 2) for x in vals])
# leiden: ratio della somma delle tre risoluzioni
for n in sizes:
    c = sum(mean([r['timings'][k] for r in cpu[n]]) for k in ["leiden_0.5", "leiden_1.0", "leiden_1.5"])
    g = sum(mean([r['timings'][k] for r in gpu[n]]) for k in ["leiden_0.5", "leiden_1.0", "leiden_1.5"])
    print("leiden somma 3 risoluzioni", n, round(c / g, 2))
# GPU leiden_0.5 per rep (effetto prima chiamata cuGraph?)
for n in sizes:
    print("GPU leiden_0.5 per rep", n, [r['timings']['leiden_0.5'] for r in gpu[n]], "leiden_1.0", [r['timings']['leiden_1.0'] for r in gpu[n]])
