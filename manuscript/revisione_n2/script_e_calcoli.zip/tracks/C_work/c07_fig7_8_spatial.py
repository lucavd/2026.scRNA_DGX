"""Figure 7 (fig7_spatial_speedup.png) e Figure 8 (fig8_spatial_perstep.png).
Convenzione dichiarata: media delle ripetizioni 2-5 (r1 escluso), SD campionaria (ddof=1).
Ricalcola totali, SD (barre di errore), speedup end-to-end e per step, n cluster per ripetizione."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from c00_load import load_spatial, mean, sd, psd

PLAT = {"visium": "Visium v1", "visium_hd_square_008um": "HD 8 um", "visium_hd_square_002um": "HD 2 um"}
for p, name in PLAT.items():
    c = load_spatial("cpu", p); g = load_spatial("gpu", p)
    print(f"== {name}: rep CPU {sorted(c)} GPU {sorted(g)}")
    ct = [c[k]["timings"]["total"] for k in [2, 3, 4, 5]]
    gt = [g[k]["timings"]["total"] for k in [2, 3, 4, 5]]
    print(f"  CPU total r2-5 mean {mean(ct):.2f} SD {sd(ct):.2f} (pop {psd(ct):.2f}); r1 {c[1]['timings']['total']:.2f}")
    print(f"  GPU total r2-5 mean {mean(gt):.2f} SD {sd(gt):.2f} (pop {psd(gt):.2f}); r1 {g[1]['timings']['total']:.2f}")
    print(f"  speedup ratio of means {mean(ct)/mean(gt):.2f}; mean of ratios {mean([a/b for a,b in zip(ct,gt)]):.2f}; incl r1 {mean(ct+[c[1]['timings']['total']])/mean(gt+[g[1]['timings']['total']]):.2f}")
    print(f"  n_spots_input {c[2]['metadata']['n_spots_input']} n_clusters CPU per rep {[c[k]['results_summary'].get('n_clusters') for k in sorted(c)]} GPU {[g[k]['results_summary'].get('n_clusters') for k in sorted(g)]}")
    print(f"  peak RAM CPU {mean([c[k]['memory']['peak_ram_gb'] for k in [2,3,4,5]]):.1f} VRAM GPU {mean([g[k]['memory']['peak_vram_gb'] for k in [2,3,4,5]]):.1f}")
    if p == "visium_hd_square_008um":
        steps = [s for s in c[2]["timings"] if s != "total"]
        print("  per-step (mean r2-5):")
        for s in steps:
            cv = [c[k]["timings"][s] for k in [2, 3, 4, 5]]; gv = [g[k]["timings"][s] for k in [2, 3, 4, 5]]
            if mean(gv) <= 0:
                print(f"    {s:24s} CPU {cv} GPU {gv} (skipped)"); continue
            r = mean(cv) / mean(gv)
            print(f"    {s:24s} CPU {mean(cv):9.3f} GPU {mean(gv):8.4f} speedup {r:9.2f}  label fig '{r:,.0f}x'"
                  f"  r1 CPU {c[1]['timings'][s]:.2f} GPU {g[1]['timings'][s]:.3f}")
        co_c = [c[k]["timings"]["co_occurrence"] for k in range(1, 6)]
        co_g = [g[k]["timings"]["co_occurrence"] for k in range(1, 6)]
        print("  co_occurrence per rep CPU", co_c, "GPU", co_g)
        print("  co_occurrence share of CPU total (r2-5):", f"{100*mean(co_c[1:])/mean(ct):.1f}%")
        sn = mean([g[k]["timings"]["spatial_neighbors"] for k in [2,3,4,5]])
        print("  spatial_neighbors share of GPU total:", f"{100*sn/mean(gt):.1f}%")
    if p == "visium_hd_square_002um":
        sn = mean([g[k]["timings"]["spatial_neighbors"] for k in [2,3,4,5]])
        um = mean([g[k]["timings"]["umap"] for k in [2,3,4,5]])
        print("  HD2: spatial_neighbors share GPU", f"{100*sn/mean(gt):.1f}%", "umap share GPU", f"{100*um/mean(gt):.1f}%",
              "co_occurrence GPU/CPU", [g[k]['timings']['co_occurrence'] for k in [2]], [c[k]['timings']['co_occurrence'] for k in [2]])
