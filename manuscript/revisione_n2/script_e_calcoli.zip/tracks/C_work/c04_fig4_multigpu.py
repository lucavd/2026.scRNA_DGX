"""Manoscritto Figure 4 = fig6_multigpu_breakdown.png. Ricalcola le altezze delle fasi (media su 5 rep),
le etichette dei totali, e la 'representative run' del testo (8 GPU, 1.3M, total 463.4 s).
Verifica anche cosa rappresenta la barra CPU (lo script somma tutti gli step nella fase 'CPU preprocessing')."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from c00_load import load, mean, sd

PH = {"cpu_pre": ["data_loading", "qc_filtering", "normalization", "hvg_selection"],
      "transfer_scale": ["gpu_transfer", "scale"],
      "multi": ["pca", "neighbors"],
      "single": ["leiden_0.5", "leiden_1.0", "leiden_1.5", "umap", "de_testing"]}
STEPS = ["data_loading", "qc_filtering", "normalization", "hvg_selection", "pca", "neighbors",
         "leiden_0.5", "leiden_1.0", "leiden_1.5", "umap", "de_testing"]
FIG = {(500000, 'cpu'): "4,347s", (500000, 2): "124s", (500000, 4): "125s", (500000, 8): "125s",
       (1300000, 'cpu'): "52,056s", (1300000, 2): "493s", (1300000, 4): "487s", (1300000, 8): "435s"}
cpu = load("cpu")
for n in [500000, 1300000]:
    c = cpu[n]
    cm = {s: mean([r["timings"][s] for r in c]) for s in STEPS}
    cpu_pre_only = sum(cm[s] for s in PH["cpu_pre"])
    tot = sum(cm.values())
    lab = f"{tot:,.0f}s"
    print(f"{n} CPU bar: altezza disegnata (tutti gli step, colore 'CPU preprocessing') = {tot:.1f} label {lab} fig {FIG[(n,'cpu')]}"
          f"; vera quota preprocessing (load+QC+norm+HVG) = {cpu_pre_only:.1f} s ({100*cpu_pre_only/tot:.1f}%)")
    print("    CPU step dominanti:", sorted([(k, round(v, 1)) for k, v in cm.items()], key=lambda kv: -kv[1])[:3])
    for g in [2, 4, 8]:
        d = load(f"gpu{g}")[n]
        ph = {k: mean([sum(r["timings"][s] for s in v) for r in d]) for k, v in PH.items()}
        tot = sum(ph.values())
        lab = f"{tot:.0f}s" if tot < 1000 else f"{tot:,.0f}s"
        tmean = mean([r["timings"]["total"] for r in d])
        print(f"  {g} GPU: " + ", ".join(f"{k}={v:.1f} ({100*v/tot:.1f}%)" for k, v in ph.items())
              + f" | stack={tot:.2f} total_mean={tmean:.2f} label={lab} fig={FIG[(n, g)]} match={lab == FIG[(n, g)]}")
# representative run
d8 = load("gpu8")[1300000]
for i, r in enumerate(d8, 1):
    t = r["timings"]
    ph = {k: sum(t[s] for s in v) for k, v in PH.items()}
    print(f"gpu8 1.3M r{i}: total={t['total']:.1f} cpu_pre={ph['cpu_pre']:.1f} ({100*ph['cpu_pre']/t['total']:.0f}%) "
          f"multi={ph['multi']:.1f} ({100*ph['multi']/t['total']:.1f}%) single+transfer+scale={ph['single']+ph['transfer_scale']:.1f} "
          f"({100*(ph['single']+ph['transfer_scale'])/t['total']:.0f}%)")
# altezza in pixel della fase multi-GPU a 1.3M 8GPU nel pannello (asse lineare 0..~58300 s)
ymax = 52056.2 * 1.12
for g in [2, 4, 8]:
    d = load(f"gpu{g}")[1300000]
    m = mean([r["timings"]["pca"] + r["timings"]["neighbors"] for r in d])
    print(f"1.3M {g}GPU multi-GPU phase {m:.1f}s = {100*m/ymax:.3f}% dell'asse y")
d = load("gpu8")[1300000]
tot = mean([r["timings"]["total"] for r in d])
print(f"barra 8GPU 1.3M intera = {100*tot/ymax:.2f}% dell'asse y")
