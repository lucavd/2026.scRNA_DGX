"""Ricostruisce le figure con lo script del repo (copia in repro_scrna/) e misura:
- se la legenda copre punti dati (Fig. 3 = fig2_scaling_plot, Fig. 5 = fig3_concordance);
- dimensione nominale della figura (pollici) per stimare i corpi font a 12.2 cm e a 0.85 textwidth.
Le figure vengono intercettate prima di plt.close."""
import sys, os, importlib.util
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("gf", os.path.join(HERE, "repro_scrna", "generate_figures.py"))
gf = importlib.util.module_from_spec(spec); spec.loader.exec_module(gf)

captured = {}
_orig_close = plt.close
def fake_close(fig=None):
    captured[len(captured)] = fig
plt.close = fake_close

df = gf.load_all_results(Path(HERE) / "repro_scrna" / "results_main")
out = Path(HERE) / "repro_scrna" / "out_probe"; out.mkdir(exist_ok=True)
gf.fig_speedup_heatmap(df, out); gf.fig_scaling_plot(df, out)
conc = gf.load_concordance(Path(HERE) / "repro_scrna" / "results_main")
gf.fig_concordance(conc, out); gf.fig_memory_profile(df, out)
gf.fig_timing_breakdown(df, out); gf.fig_multigpu_breakdown(df, out)
names = ["fig1", "fig2_scaling", "fig3_conc", "fig4_mem", "fig5_timing", "fig6_multigpu"]

def legend_hits(fig):
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    hits = []
    for ax in fig.axes:
        leg = ax.get_legend()
        if leg is None:
            continue
        bb = leg.get_window_extent(r)
        for line in ax.get_lines():
            xy = line.get_xydata()
            if len(xy) == 0:
                continue
            pix = ax.transData.transform(xy)
            for (x, y), (px, py) in zip(xy, pix):
                if bb.x0 <= px <= bb.x1 and bb.y0 <= py <= bb.y1 and line.get_label() and not str(line.get_label()).startswith('_child'):
                    hits.append((line.get_label(), float(x), round(float(y), 1)))
        for p in ax.patches:
            pb = p.get_window_extent(r)
            if pb.width > 0 and pb.height > 0 and pb.overlaps(bb):
                hits.append(("bar", round(p.get_x(), 2), round(p.get_height(), 3)))
    return hits

for i, n in enumerate(names):
    fig = captured[i]
    w, h = fig.get_size_inches()
    print(n, "figsize in", (w, h))
    hits = legend_hits(fig)
    # le linee di errorbar hanno label tipo '_child'; filtro manuale dei punti dati veri
    print("  oggetti sotto la legenda:", hits[:20])
