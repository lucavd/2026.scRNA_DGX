"""Controlli citati nei finding C che erano stati fatti in linea:
(a) tempi per ripetizione scRNA (warmup r1); (b) assenza di VRAM per-device nei JSON multi-GPU;
(c) quote per step HD 2 um (UMAP, spatial_neighbors) su CPU e GPU; (d) totali per rep HD 8 um."""
import sys, os, json, glob
sys.path.insert(0, os.path.dirname(__file__))
from c00_load import load, load_spatial, mean

cpu, gpu = load("cpu"), load("gpu")
for s in ["normalization", "pca", "neighbors", "leiden_0.5", "total"]:
    for n in [10000, 50000, 100000]:
        print("(a)", s, n, "CPU", [r["timings"][s] for r in cpu[n]], "GPU", [r["timings"][s] for r in gpu[n]])

found = [f for f in glob.glob("/tmp/repo/results/gpu[248]_*_results.json")
         if any(k in open(f).read() for k in ("per_device", "device_0", "vram_per"))]
d = json.load(open("/tmp/repo/results/gpu8_1300000_r1_results.json"))
print("(b) file con campi per-device:", found, "| chiavi memory:", list(d["memory"].keys()),
      "| esempio detailed:", [k for k in d["memory"]["detailed"] if "vram" in k][:4])

c = load_spatial("cpu", "visium_hd_square_002um"); g = load_spatial("gpu", "visium_hd_square_002um")
ct = mean([c[k]["timings"]["total"] for k in [2, 3, 4, 5]]); gt = mean([g[k]["timings"]["total"] for k in [2, 3, 4, 5]])
for s in ["umap", "spatial_neighbors", "leiden", "expression_neighbors"]:
    cv = mean([c[k]["timings"][s] for k in [2, 3, 4, 5]]); gv = mean([g[k]["timings"][s] for k in [2, 3, 4, 5]])
    print(f"(c) HD2 {s}: CPU {cv:.2f} s ({100*cv/ct:.1f}% CPU) GPU {gv:.2f} s ({100*gv/gt:.1f}% GPU) speedup {cv/gv:.1f}")

c8 = load_spatial("cpu", "visium_hd_square_008um"); g8 = load_spatial("gpu", "visium_hd_square_008um")
print("(d) HD8 totali CPU", [round(c8[k]["timings"]["total"], 2) for k in range(1, 6)],
      "GPU", [round(g8[k]["timings"]["total"], 2) for k in range(1, 6)],
      "r1 CPU / media GPU r2-5 =", round(c8[1]["timings"]["total"] / mean([g8[k]["timings"]["total"] for k in [2, 3, 4, 5]]), 2),
      "co_occ r1 CPU / media GPU r2-5 =", round(c8[1]["timings"]["co_occurrence"] / mean([g8[k]["timings"]["co_occurrence"] for k in [2, 3, 4, 5]]), 1))
