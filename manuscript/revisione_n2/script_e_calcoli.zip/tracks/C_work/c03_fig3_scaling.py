"""Manoscritto Figure 3 = fig2_scaling_plot.png. Ricalcola punti (media totale su 5 rep), barre di errore
(SD campionaria ddof=1, come _mean_std dello script), baseline CPU e verifica quali configurazioni esistono.
Verifica anche l'affermazione 'Adding GPUs beyond two provided diminishing returns'."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from c00_load import load, mean, sd, psd, SIZES

data = {p: load(p) for p in ["cpu", "gpu", "gpu2", "gpu4", "gpu8"]}
ng = {"gpu": 1, "gpu2": 2, "gpu4": 4, "gpu8": 8}
print("Configurazioni presenti (n rep):")
for p in ["cpu", "gpu", "gpu2", "gpu4", "gpu8"]:
    print(" ", p, {n: len(v) for n, v in data[p].items()})
rows = {}
for n in SIZES:
    line = []
    for p in ["gpu", "gpu2", "gpu4", "gpu8"]:
        if n in data[p]:
            t = [r["timings"]["total"] for r in data[p][n]]
            line.append((ng[p], round(mean(t), 1), round(sd(t), 1), round(psd(t), 1)))
    c = [r["timings"]["total"] for r in data["cpu"][n]]
    rows[n] = line
    print(f"{n:>8d} GPU points (nGPU, mean, SD ddof1, SD ddof0): {line}  CPU baseline {mean(c):.1f} +/- {sd(c):.1f}")
# variazione 1 -> 2 GPU e 2 -> 8 GPU
for n in SIZES:
    d = {k: m for k, m, _, _ in rows[n]}
    s = []
    if 1 in d:
        s.append(f"1->2: {100 * (d[2] - d[1]) / d[1]:+.0f}%")
    s.append(f"2->4: {100 * (d[4] - d[2]) / d[2]:+.1f}%")
    s.append(f"2->8: {100 * (d[8] - d[2]) / d[2]:+.1f}%")
    print(n, "; ".join(s))
# 1.3M: 8 GPU 'only 12% faster than 2 GPUs'
d2 = mean([r["timings"]["total"] for r in data["gpu2"][1300000]])
d8 = mean([r["timings"]["total"] for r in data["gpu8"][1300000]])
print("1.3M 2GPU", round(d2, 1), "8GPU", round(d8, 1), "riduzione", f"{100 * (d2 - d8) / d2:.1f}%",
      "rapporto", round(d2 / d8, 3))
