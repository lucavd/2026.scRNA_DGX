"""Misura l'altezza in pixel delle maiuscole/cifre (cap height) in ritagli di testo delle PNG, per stimare il
corpo in punti: pt_nativo = (cap_px / 0.729) / 300 * 72 (DejaVu Sans: cap height = 0.729 em).
Poi corpo alla larghezza di stampa: pt * (larghezza_target_in / (px_larghezza/300))."""
from PIL import Image
import numpy as np, sys, json

def cap_height(path, box, thr=200):
    im = np.asarray(Image.open(path).convert('L').crop(box)).astype(int)
    rows = np.where((im < thr).any(axis=1))[0]
    return int(rows.max() - rows.min() + 1) if len(rows) else 0, rows.min() if len(rows) else None

# box = (x0, y0, x1, y1) su testo SENZA discendenti (solo maiuscole/cifre)
probes = {
  # fig7: 'Platform' x-label -> usare solo 'Pl' ; tick label '2,695' ha virgola discendente -> usare 'V' di Visium
  'fig7_spatial_speedup.png': {'xtick "V" di Visium v1': (350, 862, 372, 898), 'xlabel "P" di Platform': (875, 950, 897, 992),
                               'legend "CPU"': (298, 58, 345, 92), 'annot "51.6"': (900, 116, 975, 150)},
  'fig8_spatial_perstep.png': {'xlabel "S" di Speedup': (1195, 1095, 1225, 1150), 'tick "3,271" cifre': (2100, 925, 2165, 960),
                               'legend "GPU"': (1820, 55, 1880, 85)},
  'fig9_spatial_concordance.png': {'xtick "M" di Moran': (322, 900, 350, 935), 'ylabel?': (0, 0, 1, 1),
                                   'legend "V" di Visium v1': (278, 740, 300, 770), 'annot "0.856"': (1695, 195, 1770, 222)},
}
if __name__ == '__main__':
    for f, d in probes.items():
        W = Image.open('/tmp/repo/figures/' + f).size[0]
        for k, b in d.items():
            h, y0 = cap_height('/tmp/repo/figures/' + f, b)
            if h == 0: continue
            pt = h / 0.729 / 300 * 72
            print(f"{f:32s} {k:28s} cap={h:3d}px nativo~{pt:4.1f}pt  a 12.2cm~{pt*(4.803/(W/300)):4.1f}pt  a 0.85tw~{pt*(4.083/(W/300)):4.1f}pt")
