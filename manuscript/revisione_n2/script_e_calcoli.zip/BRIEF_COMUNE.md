# Revisione n.2 del full paper LNBI (CIBB 2026): regole comuni a tutti i track

## Contesto
Manoscritto: `full_paper_LNBI.md` (in questa cartella, md5 4587032be8d2905007687e0bb50d848e).
Benchmark GPU (rapids-singlecell 0.14.1, 1-8 NVIDIA H100) contro CPU (Scanpy 1.12, 100 core) su scRNA-seq
(10x 1.3M mouse brain E18, sottocampioni 10k/50k/100k/500k/1.3M, 5 ripetizioni), stress test fino a 11.9M
cellule, benchmark DE a 3.4M, e spatial (Visium v1, Visium HD 8 um e 2 um) su una RTX 4090 locale.
Destinazione: capitolo Springer LNBI (post-proceedings CIBB 2026), formato LNCS, scadenza 10 novembre 2026.
Il 2 settembre il testo e' stato modificato in questi punti (verificali con la stessa severita' del resto):
Methods "Multi-GPU pipeline" (perche' il preprocessing resta su CPU), Methods "Stress test" (come e' misurata
la RAM), Results "Stress test" (paragrafo sul failure point a 12M), Table 6 (budget di memoria indicativo),
Discussion (attribuzione dell'OOM), Limitations (due limiti nuovi: strumentazione memoria, spatial in locale).

## Dati e codice (sola lettura)
- Repo: `/tmp/repo` (clone di github.com/lucavd/2026.scRNA_DGX, commit a4b9b9e).
  - `results/`: JSON scRNA. `cpu_<N>_r<k>_results.json`, `gpu_<N>_r<k>` = 1 GPU (solo N <= 100000),
    `gpu{2,4,8}_<N>_r<k>`, `concordance_10000_r1.json`, `de_benchmark_*.json`, `maxpower_*_8gpu_results.json`,
    `maxpower_limit_8gpu.json`, `maxpower_chunked_12000000_8gpu_results.json`.
    Ogni JSON ha `timings` (per step, con `total`), `memory`, `results_summary`, `metadata`.
  - `SPATIAL/results/`: JSON e .npy spatial (`spatial_{cpu,gpu}_<platform>_r<k>_results.json`,
    `spatial_concordance_<platform>.json`).
  - `scripts/`, `slurm/`, `SPATIAL/scripts/`: codice che ha girato. `Dockerfile`, `constraints.txt`,
    `requirements-squidpy.txt`: ambiente.
  - `figures/` e `SPATIAL/figures/`: figure del paper (il .md le richiama come `../figures/figN_*.png`).
  - `CLAUDE.md`: diario di lavoro del progetto. Utile per provenienza e per capire cosa e' stato fatto,
    MAI fonte di un numero: un numero vale solo se ricalcolato dai JSON.
- Bibliografia: `cibb2026_references.bib` (32 voci, tutte citate). Alcuni PDF di fonti sono in
  `/tmp/repo/manuscript/bibliography/`.
- Short paper gia' pubblicato (camera-ready, stesso lavoro in 6 pagine): `manuscript_short_cameraready.md`.
- Inventario delle asserzioni: `inventario.json`; la tua fetta e' in `tracks/inv_<TRACK>.json`.

## Regole non negoziabili
1. Niente a memoria. Un numero e' PASS solo se lo hai ricalcolato tu dai file grezzi con codice, e riporti
   valore ricalcolato e percorso per riprodurlo. "Risulta corretto" senza valore viene respinto.
2. Una citazione e' verificata solo se hai letto in questa sessione il testo della fonte (almeno l'abstract
   per i metadati; il passaggio pertinente per il contenuto). Altrimenti UNVERIFIABLE.
3. Non modificare il manoscritto ne' il repo. Lavora in `tracks/<TRACK>_work/`; salva li' gli script.
4. Ogni riga della tua fetta di inventario deve avere un esito. Puoi aggiungere finding nuovi (inv_id null).
5. Convenzioni da dichiarare, non da indovinare: media su quali ripetizioni, SD campionaria o di popolazione,
   arrotondamenti. Se il testo usa una convenzione diversa dai dati, e' un finding.
6. Web: usa WebFetch/WebSearch. Se un dominio non e' raggiungibile, non aggirarlo con curl/python: marca
   UNVERIFIABLE e scrivi perche'.
7. Niente lineette em o en nei testi che scrivi. Note in italiano; citazioni dal manoscritto in originale.

## Output (obbligatorio)
Scrivi `tracks/<TRACK>_findings.json`: lista di oggetti con questi campi.
```
{"inv_id": "A0123" | null, "track": "<TRACK>", "line": 245, "section": "...",
 "locator": "frase esatta dal manoscritto, max 200 caratteri",
 "claimed": "valore o affermazione del testo", "recomputed": "valore ricalcolato / cosa dice la fonte",
 "status": "PASS|MISMATCH|UNVERIFIABLE|UNSUPPORTED", "severity": "critical|major|minor|info",
 "source": "file + campo + calcolo (o URL letto)", "note": "breve, in italiano"}
```
Severita': critical = numero o affermazione centrale sbagliata (abstract, titolo, tesi); major = errore che un
revisore segnalerebbe; minor = arrotondamento, refuso numerico, incoerenza di formato; info = osservazione.
Messaggio finale: al massimo 15 righe in italiano con conteggi per esito, i MISMATCH critical e major in elenco,
e il percorso del file JSON. Niente altro.
